<?php

/* embeddedassets/settings */
class __TwigTemplate_e2330443a96f3f8e4ced76a4bbcb2ba011e7886388f921254299bb729e227cd6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "embeddedassets/settings", 1);
        // line 2
        echo "
<div class=\"settings\">

\t";
        // line 5
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("embed.ly API Key", "embeddedassets"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("An {api} key to be used as a fallback data provider.", "embeddedassets", array("api" => "[embed.ly API](http://docs.embed.ly/docs/embedly-api)")), "id" => "embedlyKey", "name" => "embedlyKey", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 12
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 12, $this->source); })()), "embedlyKey", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 13
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 13, $this->source); })()), "getErrors", array(0 => "embedlyKey"), "method")));
        // line 14
        echo "

\t";
        // line 16
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("iFramely API Key", "embeddedassets"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("An {api} key to be used as a fallback data provider.", "embeddedassets", array("api" => "[iFramely API](https://iframely.com/docs/iframely-api)")), "id" => "iframelyKey", "name" => "iframelyKey", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 23
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 23, $this->source); })()), "iframelyKey", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 24
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 24, $this->source); })()), "getErrors", array(0 => "iframelyKey"), "method")));
        // line 25
        echo "

\t";
        // line 27
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Google API Key", "embeddedassets"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("A {api} key to be used as a fallback data provider.", "embeddedassets", array("api" => "[Google API](https://developers.google.com/maps/documentation/embed/guide)")), "id" => "googleKey", "name" => "googleKey", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 34
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 34, $this->source); })()), "googleKey", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 35
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 35, $this->source); })()), "getErrors", array(0 => "googleKey"), "method")));
        // line 36
        echo "

\t";
        // line 38
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("SoundCloud API Key", "embeddedassets"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("A {api} key to be used as a fallback data provider.", "embeddedassets", array("api" => "[SoundCloud API](https://developers.soundcloud.com/docs/api/guide)")), "id" => "soundcloudKey", "name" => "soundcloudKey", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 45
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 45, $this->source); })()), "soundcloudKey", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 46
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 46, $this->source); })()), "getErrors", array(0 => "soundcloudKey"), "method")));
        // line 47
        echo "

\t";
        // line 49
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Facebook Graph API Key", "embeddedassets"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("A {api} key to be used as a fallback data provider.", "embeddedassets", array("api" => "[Facebook Graph API](https://developers.facebook.com/docs/graph-api)")), "id" => "facebookKey", "name" => "facebookKey", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 56
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 56, $this->source); })()), "facebookKey", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 57
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 57, $this->source); })()), "getErrors", array(0 => "facebookKey"), "method")));
        // line 58
        echo "

\t";
        // line 60
        echo $context["forms"]->macro_editableTableField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parameters", "embeddedassets"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("List of extra parameters and their values to be sent when retrieving embed data.", "embeddedassets"), "id" => "parameters", "name" => "parameters", "rows" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 65
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 65, $this->source); })()), "parameters", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 66
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 66, $this->source); })()), "getErrors", array(0 => "parameters"), "method"), "cols" => array("param" => array("type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parameter", "embeddedassets"), "class" => "code"), "value" => array("type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Value", "embeddedassets"), "class" => "code")), "addRowLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Add a parameter", "embeddedassets")));
        // line 72
        echo "

</div>
";
    }

    public function getTemplateName()
    {
        return "embeddedassets/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 72,  72 => 66,  71 => 65,  70 => 60,  66 => 58,  64 => 57,  63 => 56,  62 => 49,  58 => 47,  56 => 46,  55 => 45,  54 => 38,  50 => 36,  48 => 35,  47 => 34,  46 => 27,  42 => 25,  40 => 24,  39 => 23,  38 => 16,  34 => 14,  32 => 13,  31 => 12,  30 => 5,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_includes/forms' as forms %}

<div class=\"settings\">

\t{{ forms.textField({
\t\tlabel: \"embed.ly API Key\"|t('embeddedassets'),
\t\tinstructions: \"An {api} key to be used as a fallback data provider.\"|t('embeddedassets', {
\t\t\tapi: '[embed.ly API](http://docs.embed.ly/docs/embedly-api)',
\t\t}),
\t\tid: 'embedlyKey',
\t\tname: 'embedlyKey',
\t\tvalue: settings.embedlyKey,
\t\terrors: settings.getErrors('embedlyKey'),
\t}) }}

\t{{ forms.textField({
\t\tlabel: \"iFramely API Key\"|t('embeddedassets'),
\t\tinstructions: \"An {api} key to be used as a fallback data provider.\"|t('embeddedassets', {
\t\t\tapi: '[iFramely API](https://iframely.com/docs/iframely-api)',
\t\t}),
\t\tid: 'iframelyKey',
\t\tname: 'iframelyKey',
\t\tvalue: settings.iframelyKey,
\t\terrors: settings.getErrors('iframelyKey'),
\t}) }}

\t{{ forms.textField({
\t\tlabel: \"Google API Key\"|t('embeddedassets'),
\t\tinstructions: \"A {api} key to be used as a fallback data provider.\"|t('embeddedassets', {
\t\t\tapi: '[Google API](https://developers.google.com/maps/documentation/embed/guide)',
\t\t}),
\t\tid: 'googleKey',
\t\tname: 'googleKey',
\t\tvalue: settings.googleKey,
\t\terrors: settings.getErrors('googleKey'),
\t}) }}

\t{{ forms.textField({
\t\tlabel: \"SoundCloud API Key\"|t('embeddedassets'),
\t\tinstructions: \"A {api} key to be used as a fallback data provider.\"|t('embeddedassets', {
\t\t\tapi: '[SoundCloud API](https://developers.soundcloud.com/docs/api/guide)',
\t\t}),
\t\tid: 'soundcloudKey',
\t\tname: 'soundcloudKey',
\t\tvalue: settings.soundcloudKey,
\t\terrors: settings.getErrors('soundcloudKey'),
\t}) }}

\t{{ forms.textField({
\t\tlabel: \"Facebook Graph API Key\"|t('embeddedassets'),
\t\tinstructions: \"A {api} key to be used as a fallback data provider.\"|t('embeddedassets', {
\t\t\tapi: '[Facebook Graph API](https://developers.facebook.com/docs/graph-api)',
\t\t}),
\t\tid: 'facebookKey',
\t\tname: 'facebookKey',
\t\tvalue: settings.facebookKey,
\t\terrors: settings.getErrors('facebookKey'),
\t}) }}

\t{{ forms.editableTableField({
\t\tlabel: \"Parameters\"|t('embeddedassets'),
\t\tinstructions: \"List of extra parameters and their values to be sent when retrieving embed data.\"|t('embeddedassets'),
\t\tid: 'parameters',
\t\tname: 'parameters',
\t\trows: settings.parameters,
\t\terrors: settings.getErrors('parameters'),
\t\tcols: {
\t\t\tparam: { type: 'singleline', heading: \"Parameter\"|t('embeddedassets'), class: 'code' },
\t\t\tvalue: { type: 'singleline', heading: \"Value\"|t('embeddedassets'), class: 'code' },
\t\t},
\t\taddRowLabel: \"Add a parameter\"|t('embeddedassets'),
\t}) }}

</div>
", "embeddedassets/settings", "/app/vendor/benjamminf/craft-embedded-assets/src/templates/settings.twig");
    }
}

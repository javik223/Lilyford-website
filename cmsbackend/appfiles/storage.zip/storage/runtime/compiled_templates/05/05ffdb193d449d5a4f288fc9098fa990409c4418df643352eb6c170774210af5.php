<?php

/* take-action/_entry */
class __TwigTemplate_d55086701bbba72ca5b127df6dbd4d68784cdaff022090afb36af6aca60ee451 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "take-action/_entry", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "take-action/_entry", 2);
        // line 3
        $context["pageBuilder"] = $this->loadTemplate("macros/page-builder", "take-action/_entry", 3);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_main($context, array $blocks = array())
    {
        // line 5
        echo "    ";
        // line 6
        echo "    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 7, $this->source); })()), "title", array()), "html", null, true);
        echo "</h2>
        <h4 class=\"subheader\">";
        // line 8
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 8, $this->source); })()), "introText", array()), "html", null, true);
        echo "</h4>
    </div>
    <div class=\"grid-container\">
        ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 11, $this->source); })()), "pageBuilder", array()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 12
            echo "            ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "type", array()) == "text")) {
                // line 13
                echo "                ";
                echo $context["pageBuilder"]->macro_text($context["item"]);
                echo "
            ";
            }
            // line 15
            echo "            ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "type", array()) == "carousel")) {
                // line 16
                echo "                ";
                echo $context["pageBuilder"]->macro_carousel($context["item"]);
                echo "
            ";
            }
            // line 18
            echo "            ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "type", array()) == "stripCarousel")) {
                // line 19
                echo "                ";
                echo $context["pageBuilder"]->macro_stripCarousel(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "images", array()), "all", array(), "method"), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index", array()));
                echo "
            ";
            }
            // line 21
            echo "
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "take-action/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 23,  99 => 21,  93 => 19,  90 => 18,  84 => 16,  81 => 15,  75 => 13,  72 => 12,  55 => 11,  49 => 8,  45 => 7,  42 => 6,  40 => 5,  37 => 4,  33 => 1,  31 => 3,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% import 'macros/image-helper' as imageHelper %}
{% import 'macros/page-builder' as pageBuilder %}
{% block main %}
    {#<img src=\"{{ entry.heroImage.one().url }}\" alt=\"{{ entry.heroImage.title }}\">#}
    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">{{ entry.title }}</h2>
        <h4 class=\"subheader\">{{ entry.introText }}</h4>
    </div>
    <div class=\"grid-container\">
        {% for item in entry.pageBuilder %}
            {% if item.type == 'text' %}
                {{ pageBuilder.text(item) }}
            {% endif %}
            {% if item.type == 'carousel' %}
                {{ pageBuilder.carousel(item) }}
            {% endif %}
            {% if item.type == 'stripCarousel' %}
                {{ pageBuilder.stripCarousel(item.images.all(), loop.index) }}
            {% endif %}

        {% endfor %}
    </div>
{% endblock %}", "take-action/_entry", "/app/templates/take-action/_entry.twig");
    }
}

<?php

/* field-manager/index */
class __TwigTemplate_7bdf45ae819847d0ddeca015e052a15d4615e72773f13c32d04fac7fba5608f8 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "field-manager/index", 1);
        $this->blocks = array(
            'actionButton' => array($this, 'block_actionButton'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 3
        $context["forms"] = $this->loadTemplate("_includes/forms", "field-manager/index", 3);
        // line 5
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", array(0 => "verbb\\fieldmanager\\assetbundles\\FieldManagerAsset"), "method");
        // line 7
        $context["title"] = "Field Manager";
        // line 9
        $context["tabs"] = array("fields" => array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "field-manager"), "url" => craft\helpers\UrlHelper::url("field-manager")), "import" => array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Import", "field-manager"), "url" => craft\helpers\UrlHelper::url("field-manager/import")));
        // line 14
        $context["groups"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 14, $this->source); })()), "app", array()), "fields", array()), "allGroups", array());
        // line 16
        ob_start();
        // line 17
        echo "    <nav class=\"sidebar-nav\">
        <ul>
            <li class=\"heading\"><span>";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Field Groups", "field-manager"), "html", null, true);
        echo "</span></li>
            <li class=\"active\"><a href=\"#\" data-groupid=\"all\">";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "field-manager"), "html", null, true);
        echo "</a></li>
            ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new Twig_Error_Runtime('Variable "groups" does not exist.', 21, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 22
            echo "                <li><a href=\"#\" data-groupid=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["group"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["group"], "name", array()), "html", null, true);
            echo "</a></li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "        </ul>
    </nav>
";
        $context["sidebar"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 34
        ob_start();
        // line 35
        echo "
<form method=\"POST\" accept-charset=\"UTF-8\">
    <input type=\"hidden\" name=\"action\" value=\"field-manager/base/export\">
    ";
        // line 38
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
        echo "

    <table id=\"fieldmanager\" class=\"data fullwidth collapsible\">
        <thead>
            <th>";
        // line 42
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Group Name", "field-manager"), "html", null, true);
        echo "</th>
            <th>";
        // line 43
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "field-manager"), "html", null, true);
        echo "</th>
            <th>";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Type", "field-manager"), "html", null, true);
        echo "</th>
            <th></th>
            <th></th>
        </thead>
        <tbody>
            ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new Twig_Error_Runtime('Variable "groups" does not exist.', 49, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 50
            echo "                ";
            $context["fields"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 50, $this->source); })()), "app", array()), "fields", array()), "getFieldsByGroupId", array(0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["group"], "id", array())), "method");
            // line 51
            echo "
                <tr class=\"group\" data-groupid=\"";
            // line 52
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["group"], "id", array()), "html", null, true);
            echo "\">
                    <th scope=\"row\">
                        ";
            // line 54
            ob_start();
            // line 55
            echo "                            <span class=\"go\">
                                <a href=\"";
            // line 56
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("settings/fields/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["group"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["group"], "name", array()), "html", null, true);
            echo "</a>
                            </span>
                        ";
            $context["label"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
            // line 59
            echo "
                        ";
            // line 60
            echo $context["forms"]->macro_checkboxField(array("label" =>             // line 61
(isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new Twig_Error_Runtime('Variable "label" does not exist.', 61, $this->source); })())));
            // line 62
            echo "
                    </th>
                    <td></td>
                    <td></td>
                    <td class=\"thin\"><div class=\"btn small clone-btn element\">Clone Group</div></td>
                    <td class=\"thin delete-row\"><a class=\"delete-group icon\" title=\"";
            // line 67
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "field-manager"), "html", null, true);
            echo "\" role=\"button\"></a></td>
                </tr>

                ";
            // line 70
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 70, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 71
                echo "                    <tr class=\"field\" data-id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "id", array()), "html", null, true);
                echo "\" data-groupid=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["group"], "id", array()), "html", null, true);
                echo "\" data-name=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", array()), "html", null, true);
                echo "\">
                        <th scope=\"row\" class=\"name\">
                            ";
                // line 73
                ob_start();
                // line 74
                echo "                                <span class=\"go\">
                                    <a href=\"";
                // line 75
                echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("settings/fields/edit/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", array()), "html", null, true);
                echo "</a>

                                    ";
                // line 77
                if (twig_in_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "id", array()), (isset($context["unusedFieldIds"]) || array_key_exists("unusedFieldIds", $context) ? $context["unusedFieldIds"] : (function () { throw new Twig_Error_Runtime('Variable "unusedFieldIds" does not exist.', 77, $this->source); })()))) {
                    // line 78
                    echo "                                        <span class=\"unused-field\">Unused</span>
                                    ";
                }
                // line 80
                echo "                                </span>
                            ";
                $context["label"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
                // line 82
                echo "
                            ";
                // line 83
                echo $context["forms"]->macro_checkboxField(array("name" => "selectedFields[]", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 85
$context["field"], "id", array()), "label" =>                 // line 86
(isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new Twig_Error_Runtime('Variable "label" does not exist.', 86, $this->source); })())));
                // line 87
                echo "
                        </th>

                        <td><code>";
                // line 90
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "handle", array()), "html", null, true);
                echo "</code></td>

                        ";
                // line 92
                if (call_user_func_array($this->env->getTest('missing')->getCallable(), array($context["field"]))) {
                    // line 93
                    echo "                            <td><span class=\"error\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "expectedType", array()), "html", null, true);
                    echo "</span></td>
                            <td class=\"thin\"></td>
                        ";
                } else {
                    // line 96
                    echo "                            <td>";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "displayName", array(), "method"), "html", null, true);
                    echo "</td>
                            <td class=\"thin\"><div class=\"btn small clone-btn element\">Clone</div></td>
                        ";
                }
                // line 99
                echo "
                        <td class=\"thin delete-row\">
                            <a class=\"delete icon\" title=\"";
                // line 101
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "field-manager"), "html", null, true);
                echo "\" role=\"button\"></a>
                        </td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 105
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 106
        echo "        </tbody>
    </table>

    <hr>

    <div class=\"buttons\">
        <input type=\"submit\" class=\"btn submit disabled export-btn\" disabled value=\"Export selected\">
    </div>
</form>

";
        $context["content"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 118
        ob_start();
        // line 119
        echo "    new Craft.AdminTable({
        tableSelector: '#fieldmanager',
        noObjectsSelector: '#nofields',
        deleteAction: 'fields/delete-field'
    });
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 28
    public function block_actionButton($context, array $blocks = array())
    {
        // line 29
        echo "    ";
        if ((isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new Twig_Error_Runtime('Variable "groups" does not exist.', 29, $this->source); })())) {
            // line 30
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("settings/fields/new"), "html", null, true);
            echo "\" class=\"submit btn add icon new-field-btn\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New field", "field-manager"), "html", null, true);
            echo "</a>
    ";
        }
    }

    public function getTemplateName()
    {
        return "field-manager/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  272 => 30,  269 => 29,  266 => 28,  262 => 1,  254 => 119,  252 => 118,  239 => 106,  233 => 105,  223 => 101,  219 => 99,  212 => 96,  205 => 93,  203 => 92,  198 => 90,  193 => 87,  191 => 86,  190 => 85,  189 => 83,  186 => 82,  182 => 80,  178 => 78,  176 => 77,  169 => 75,  166 => 74,  164 => 73,  154 => 71,  150 => 70,  144 => 67,  137 => 62,  135 => 61,  134 => 60,  131 => 59,  123 => 56,  120 => 55,  118 => 54,  113 => 52,  110 => 51,  107 => 50,  103 => 49,  95 => 44,  91 => 43,  87 => 42,  80 => 38,  75 => 35,  73 => 34,  68 => 24,  57 => 22,  53 => 21,  49 => 20,  45 => 19,  41 => 17,  39 => 16,  37 => 14,  35 => 9,  33 => 7,  31 => 5,  29 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"_layouts/cp\" %}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"verbb\\\\fieldmanager\\\\assetbundles\\\\FieldManagerAsset\") %}

{% set title = 'Field Manager' %}

{% set tabs = {
    fields: { label: \"Fields\" | t('field-manager'), url: url('field-manager') },
    import: { label: \"Import\" | t('field-manager'), url: url('field-manager/import') },
} %}

{% set groups = craft.app.fields.allGroups %}

{% set sidebar %}
    <nav class=\"sidebar-nav\">
        <ul>
            <li class=\"heading\"><span>{{ 'Field Groups' | t('field-manager') }}</span></li>
            <li class=\"active\"><a href=\"#\" data-groupid=\"all\">{{ 'All' | t('field-manager') }}</a></li>
            {% for group in groups %}
                <li><a href=\"#\" data-groupid=\"{{ group.id }}\">{{ group.name }}</a></li>
            {% endfor %}
        </ul>
    </nav>
{% endset %}

{% block actionButton %}
    {% if groups %}
        <a href=\"{{ url('settings/fields/new') }}\" class=\"submit btn add icon new-field-btn\">{{ \"New field\" | t('field-manager') }}</a>
    {% endif %}
{% endblock %}

{% set content %}

<form method=\"POST\" accept-charset=\"UTF-8\">
    <input type=\"hidden\" name=\"action\" value=\"field-manager/base/export\">
    {{ csrfInput() }}

    <table id=\"fieldmanager\" class=\"data fullwidth collapsible\">
        <thead>
            <th>{{ \"Group Name\" | t('field-manager') }}</th>
            <th>{{ \"Handle\" | t('field-manager') }}</th>
            <th>{{ \"Type\" | t('field-manager') }}</th>
            <th></th>
            <th></th>
        </thead>
        <tbody>
            {% for group in groups %}
                {% set fields = craft.app.fields.getFieldsByGroupId(group.id) %}

                <tr class=\"group\" data-groupid=\"{{ group.id }}\">
                    <th scope=\"row\">
                        {% set label %}
                            <span class=\"go\">
                                <a href=\"{{ url('settings/fields/' ~ group.id) }}\">{{ group.name }}</a>
                            </span>
                        {% endset %}

                        {{ forms.checkboxField({
                            label: label
                        }) }}
                    </th>
                    <td></td>
                    <td></td>
                    <td class=\"thin\"><div class=\"btn small clone-btn element\">Clone Group</div></td>
                    <td class=\"thin delete-row\"><a class=\"delete-group icon\" title=\"{{ 'Delete' | t('field-manager') }}\" role=\"button\"></a></td>
                </tr>

                {% for field in fields %}
                    <tr class=\"field\" data-id=\"{{ field.id }}\" data-groupid=\"{{ group.id }}\" data-name=\"{{ field.name }}\">
                        <th scope=\"row\" class=\"name\">
                            {% set label %}
                                <span class=\"go\">
                                    <a href=\"{{ url('settings/fields/edit/' ~ field.id) }}\">{{ field.name }}</a>

                                    {% if field.id in unusedFieldIds %}
                                        <span class=\"unused-field\">Unused</span>
                                    {% endif %}
                                </span>
                            {% endset %}

                            {{ forms.checkboxField({
                                name: 'selectedFields[]',
                                value: field.id,
                                label: label
                            }) }}
                        </th>

                        <td><code>{{ field.handle }}</code></td>

                        {% if field is missing %}
                            <td><span class=\"error\">{{ field.expectedType }}</span></td>
                            <td class=\"thin\"></td>
                        {% else %}
                            <td>{{ field.displayName() }}</td>
                            <td class=\"thin\"><div class=\"btn small clone-btn element\">Clone</div></td>
                        {% endif %}

                        <td class=\"thin delete-row\">
                            <a class=\"delete icon\" title=\"{{ 'Delete' | t('field-manager') }}\" role=\"button\"></a>
                        </td>
                    </tr>
                {% endfor %}
            {% endfor %}
        </tbody>
    </table>

    <hr>

    <div class=\"buttons\">
        <input type=\"submit\" class=\"btn submit disabled export-btn\" disabled value=\"Export selected\">
    </div>
</form>

{% endset %}

{% js %}
    new Craft.AdminTable({
        tableSelector: '#fieldmanager',
        noObjectsSelector: '#nofields',
        deleteAction: 'fields/delete-field'
    });
{% endjs %}

", "field-manager/index", "/app/vendor/verbb/field-manager/src/templates/index.html");
    }
}

<?php

/* colour-swatches/settings */
class __TwigTemplate_d4790d853f1b311dc05cf3c6b01dcc343e5e1d59c12a6a1e44df218764626218 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 15
        echo "
";
        // line 16
        $context["forms"] = $this->loadTemplate("_includes/forms", "colour-swatches/settings", 16);
        // line 17
        echo "
<div class=\"color-swatches-options\">
    ";
        // line 19
        echo $context["forms"]->macro_editableTable((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 19, $this->source); })()));
        echo "
</div>
";
    }

    public function getTemplateName()
    {
        return "colour-swatches/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 19,  28 => 17,  26 => 16,  23 => 15,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * color-swatches plugin for Craft CMS
 *
 * ColourSwatches Field Settings
 *
 * @author    Rias
 * @copyright Copyright (c) 2018 Rias
 * @link      https://rias.be
 * @package   Colour Swatches
 * @since     1.0.0
 */
#}

{% import \"_includes/forms\" as forms %}

<div class=\"color-swatches-options\">
    {{ forms.editableTable(config) }}
</div>
", "colour-swatches/settings", "/app/vendor/rias/craft-colour-swatches/src/templates/settings.twig");
    }
}

<?php

/* macros/page-builder */
class __TwigTemplate_804ae6369b5593113403b3a6b275380643a5b8c115264573c734a46a16e93fc6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
";
        // line 8
        echo "
";
        // line 10
        echo "
";
        // line 49
        echo "
";
        // line 51
        echo "
";
        // line 84
        echo "
";
        // line 86
        echo "
";
        // line 99
        echo "
";
        // line 122
        echo "
";
    }

    // line 3
    public function macro_text($__item__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "item" => $__item__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 4
            echo "    <div class=\"grid-container\">
        <div class=\"grid-x margin-bottom-2 small-11 small-centered medium-10 large-8\">";
            // line 5
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 5, $this->source); })()), "text", array()), "html", null, true);
            echo "</div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 11
    public function macro_carousel($__items__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "items" => $__items__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 12
            echo "    ";
            $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "macros/page-builder", 12);
            // line 13
            echo "    <div class=\"grid-container\">
        <div class=\"grid-x padding-bottom-2\">
            <div class=\"gallery\">
                ";
            // line 16
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 16, $this->source); })()), "title", array())) {
                // line 17
                echo "                    <h3 class=\"gallery__title\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 17, $this->source); })()), "title", array()), "html", null, true);
                echo "</h3>
                ";
            }
            // line 19
            echo "
                <div class=\"gallery__main js-gallery-main\">
                    ";
            // line 21
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 21, $this->source); })()), "images", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["carouselImage"]) {
                // line 22
                echo "                        <div>

                            ";
                // line 24
                echo $context["imageHelper"]->macro_srcset($context["carouselImage"], craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "title", array()));
                echo "
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['carouselImage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo "                </div>
                <div class=\"gallery__thumbs js-gallery-thumb\">
                    ";
            // line 29
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 29, $this->source); })()), "images", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["carouselImage"]) {
                // line 30
                echo "                        <div>
                            ";
                // line 31
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "title", array()), 300, 200);
                echo "
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['carouselImage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "                </div>

                <div class=\"gallery__navigation medium-6 medium-centered text-center\">
                    <span class=\"prev\">
                        <div class=\"icon icon-arrow-left\"></div>
                    </span>
                    <span>&nbsp;</span>
                    <span class=\"next\">
                        <div class=\"icon icon-arrow-right\"></div>
                    </span>
                </div>
            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 52
    public function macro_stripCarousel($__images__ = null, $__index__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "images" => $__images__,
            "index" => $__index__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 53
            echo "    ";
            $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "macros/page-builder", 53);
            // line 54
            echo "    <div class=\"grid-container margin-bottom-2\">
        <div class=\"grid-x\">
            <div class=\"js-slick cell\" data-slick='{\"slidesToShow\": 2, \"prevArrow\": \".strip-carousel-";
            // line 56
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 56, $this->source); })()), "html", null, true);
            echo "-prev\", \"nextArrow\": \".strip-carousel-";
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 56, $this->source); })()), "html", null, true);
            echo "-next\", \"responsive\": [
      {
        \"breakpoint\": 960,
        \"settings\": {
          \"centerMode\": true,
          \"slidesToShow\": 1,
          \"slidesToScroll\": 1,
          \"centerPadding\": \"-10px\"
        }
      }
    ]}'>
                ";
            // line 67
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["images"]) || array_key_exists("images", $context) ? $context["images"] : (function () { throw new Twig_Error_Runtime('Variable "images" does not exist.', 67, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 68
                echo "                    <div class=\"cell padding-1\">";
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "title", array()), 1000);
                echo "</div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 70
            echo "            </div>
            <div class=\"text-center cell strip-carousel-";
            // line 71
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 71, $this->source); })()), "html", null, true);
            echo "\">
                <span class=\"prev strip-carousel-";
            // line 72
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 72, $this->source); })()), "html", null, true);
            echo "-prev\">
                    <div class=\"icon icon-arrow-left\"></div>
                </span>

                <span class=\"next strip-carousel-";
            // line 76
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 76, $this->source); })()), "html", null, true);
            echo "-next\">
                    <div class=\"icon icon-arrow-right\"></div>
                </span>

            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 87
    public function macro_video($__video__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "video" => $__video__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 88
            echo "    <div class=\"grid-container full bg-very-light-gray\">
        <div class=\"grid-container padding-3\">
            <div class=\"cell medium-10 medium-centered\">
                <div class=\"video\">
                    ";
            // line 92
            $context["embeddedAsset"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 92, $this->source); })()), "embeddedAssets", array()), "get", array(0 => (isset($context["video"]) || array_key_exists("video", $context) ? $context["video"] : (function () { throw new Twig_Error_Runtime('Variable "video" does not exist.', 92, $this->source); })()), 1 => array("width" => 200)), "method");
            // line 93
            echo "                    ";
            echo twig_escape_filter($this->env, (((isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 93, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 93, $this->source); })()), "html", array())) : ("")), "html", null, true);
            echo "
                </div>
            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 101
    public function macro_iconBlocks($__iconBlock__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "iconBlock" => $__iconBlock__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 102
            echo "    <div class=\"grid-container\">
        <div class=\"cell text-center padding-top-2 padding-bottom-3\">
            ";
            // line 104
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["iconBlock"]) || array_key_exists("iconBlock", $context) ? $context["iconBlock"] : (function () { throw new Twig_Error_Runtime('Variable "iconBlock" does not exist.', 104, $this->source); })()), "iconBlockTitle", array())) {
                // line 105
                echo "                <div class=\"cell padding-2\">
                    <h4 class=\"uppercase strong color-blue\">";
                // line 106
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["iconBlock"]) || array_key_exists("iconBlock", $context) ? $context["iconBlock"] : (function () { throw new Twig_Error_Runtime('Variable "iconBlock" does not exist.', 106, $this->source); })()), "iconBlockTitle", array()), "html", null, true);
                echo "</h4>
                </div>
            ";
            }
            // line 109
            echo "
            <div class=\"grid-x small-up-2 medium-up-3 large-up-4 align-center-middle\">
                ";
            // line 111
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["iconBlock"]) || array_key_exists("iconBlock", $context) ? $context["iconBlock"] : (function () { throw new Twig_Error_Runtime('Variable "iconBlock" does not exist.', 111, $this->source); })()), "iconBlocks", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["icon"]) {
                // line 112
                echo "                    <div class=\"cell padding-bottom-1\">
                        <img src=\"";
                // line 113
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["icon"], "iconBlockIcon", array()), "one", array(), "method"), "url", array()), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["icon"], "iconBlockSubText", array()), "html", null, true);
                echo "\">
                        <h3 class=\"margin-0 padding-top-1 strong color-purple\">";
                // line 114
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["icon"], "iconBlockTitle", array()), "html", null, true);
                echo "</h3>
                        <p>";
                // line 115
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["icon"], "iconBlockSubText", array()), "html", null, true);
                echo "</p>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['icon'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 118
            echo "            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 124
    public function macro_logoBlocks($__images__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "images" => $__images__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 125
            echo "    ";
            $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "macros/page-builder", 125);
            // line 126
            echo "    <div class=\"grid-container\">
        <div class=\"cell text-center padding-top-2 padding-bottom-3\">
            <div class=\"grid-x small-up-4 medium-up-5 large-up-8 align-center-middle grid-margin-x\">
                ";
            // line 129
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["images"]) || array_key_exists("images", $context) ? $context["images"] : (function () { throw new Twig_Error_Runtime('Variable "images" does not exist.', 129, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 130
                echo "                    <div class=\"cell padding-bottom-1\">
                        ";
                // line 131
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "title", array()), 400, 400);
                echo "
                        <p>&nbsp;</p>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 135
            echo "            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "macros/page-builder";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  393 => 135,  383 => 131,  380 => 130,  376 => 129,  371 => 126,  368 => 125,  356 => 124,  344 => 118,  335 => 115,  331 => 114,  325 => 113,  322 => 112,  318 => 111,  314 => 109,  308 => 106,  305 => 105,  303 => 104,  299 => 102,  287 => 101,  271 => 93,  269 => 92,  263 => 88,  251 => 87,  234 => 76,  227 => 72,  223 => 71,  220 => 70,  211 => 68,  207 => 67,  191 => 56,  187 => 54,  184 => 53,  171 => 52,  148 => 34,  139 => 31,  136 => 30,  132 => 29,  128 => 27,  119 => 24,  115 => 22,  111 => 21,  107 => 19,  101 => 17,  99 => 16,  94 => 13,  91 => 12,  79 => 11,  67 => 5,  64 => 4,  52 => 3,  47 => 122,  44 => 99,  41 => 86,  38 => 84,  35 => 51,  32 => 49,  29 => 10,  26 => 8,  23 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# Plain Text #}

{% macro text(item) %}
    <div class=\"grid-container\">
        <div class=\"grid-x margin-bottom-2 small-11 small-centered medium-10 large-8\">{{ item.text }}</div>
    </div>
{% endmacro %}

{# Carousel #}

{% macro carousel(items) %}
    {% import 'macros/image-helper' as imageHelper %}
    <div class=\"grid-container\">
        <div class=\"grid-x padding-bottom-2\">
            <div class=\"gallery\">
                {% if items.title %}
                    <h3 class=\"gallery__title\">{{ items.title }}</h3>
                {% endif %}

                <div class=\"gallery__main js-gallery-main\">
                    {% for carouselImage in items.images.all() %}
                        <div>

                            {{ imageHelper.srcset(carouselImage, carouselImage.title) }}
                        </div>
                    {% endfor %}
                </div>
                <div class=\"gallery__thumbs js-gallery-thumb\">
                    {% for carouselImage in items.images.all() %}
                        <div>
                            {{ imageHelper.transform(carouselImage.url, carouselImage.title, 300, 200) }}
                        </div>
                    {% endfor %}
                </div>

                <div class=\"gallery__navigation medium-6 medium-centered text-center\">
                    <span class=\"prev\">
                        <div class=\"icon icon-arrow-left\"></div>
                    </span>
                    <span>&nbsp;</span>
                    <span class=\"next\">
                        <div class=\"icon icon-arrow-right\"></div>
                    </span>
                </div>
            </div>
        </div>
    </div>
{% endmacro %}

{# Strip Carousel #}

{% macro stripCarousel(images, index) %}
    {% import 'macros/image-helper' as imageHelper %}
    <div class=\"grid-container margin-bottom-2\">
        <div class=\"grid-x\">
            <div class=\"js-slick cell\" data-slick='{\"slidesToShow\": 2, \"prevArrow\": \".strip-carousel-{{ index }}-prev\", \"nextArrow\": \".strip-carousel-{{ index }}-next\", \"responsive\": [
      {
        \"breakpoint\": 960,
        \"settings\": {
          \"centerMode\": true,
          \"slidesToShow\": 1,
          \"slidesToScroll\": 1,
          \"centerPadding\": \"-10px\"
        }
      }
    ]}'>
                {% for image in images %}
                    <div class=\"cell padding-1\">{{ imageHelper.transform(image.url, image.title, 1000) }}</div>
                {% endfor %}
            </div>
            <div class=\"text-center cell strip-carousel-{{ index }}\">
                <span class=\"prev strip-carousel-{{ index }}-prev\">
                    <div class=\"icon icon-arrow-left\"></div>
                </span>

                <span class=\"next strip-carousel-{{ index }}-next\">
                    <div class=\"icon icon-arrow-right\"></div>
                </span>

            </div>
        </div>
    </div>
{% endmacro %}

{# Video block #}

{% macro video(video) %}
    <div class=\"grid-container full bg-very-light-gray\">
        <div class=\"grid-container padding-3\">
            <div class=\"cell medium-10 medium-centered\">
                <div class=\"video\">
                    {% set embeddedAsset = craft.embeddedAssets.get(video, {width: 200}) %}
                    {{ embeddedAsset ? embeddedAsset.html }}
                </div>
            </div>
        </div>
    </div>
{% endmacro %}

{# Icon Blocks #}
{% macro iconBlocks(iconBlock) %}
    <div class=\"grid-container\">
        <div class=\"cell text-center padding-top-2 padding-bottom-3\">
            {% if iconBlock.iconBlockTitle %}
                <div class=\"cell padding-2\">
                    <h4 class=\"uppercase strong color-blue\">{{ iconBlock.iconBlockTitle }}</h4>
                </div>
            {% endif %}

            <div class=\"grid-x small-up-2 medium-up-3 large-up-4 align-center-middle\">
                {% for icon in iconBlock.iconBlocks %}
                    <div class=\"cell padding-bottom-1\">
                        <img src=\"{{ icon.iconBlockIcon.one().url }}\" alt=\"{{ icon.iconBlockSubText }}\">
                        <h3 class=\"margin-0 padding-top-1 strong color-purple\">{{ icon.iconBlockTitle }}</h3>
                        <p>{{ icon.iconBlockSubText }}</p>
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
{% endmacro %}

{# Logo Blocks #}
{% macro logoBlocks(images) %}
    {% import 'macros/image-helper' as imageHelper %}
    <div class=\"grid-container\">
        <div class=\"cell text-center padding-top-2 padding-bottom-3\">
            <div class=\"grid-x small-up-4 medium-up-5 large-up-8 align-center-middle grid-margin-x\">
                {% for image in images %}
                    <div class=\"cell padding-bottom-1\">
                        {{ imageHelper.transform(image.url, image.title, 400, 400) }}
                        <p>&nbsp;</p>
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
{% endmacro %}", "macros/page-builder", "/app/templates/macros/page-builder.twig");
    }
}

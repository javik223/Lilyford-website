<?php

/* __string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e */
class __TwigTemplate_e945fd8d02832e9a16248e3a34d3b8f553fa78d31c16f3e20ce5d30bdd4dd2cb extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "section", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "section", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "section", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "section", array()))), "name", array());
    }

    public function getTemplateName()
    {
        return "__string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ (_variables.section ?? object.section).name|raw|raw }}", "__string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e", "");
    }
}

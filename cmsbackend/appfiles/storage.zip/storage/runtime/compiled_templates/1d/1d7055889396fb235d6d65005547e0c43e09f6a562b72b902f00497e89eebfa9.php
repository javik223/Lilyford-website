<?php

/* super-table/matrix/fields */
class __TwigTemplate_921d1b1f7efb52eff243728cafc87c9079d42d2f41b4387227b23e5c5b0647be extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ( !(isset($context["element"]) || array_key_exists("element", $context))) {
            $context["element"] = null;
        }
        // line 2
        if ( !(isset($context["namespace"]) || array_key_exists("namespace", $context))) {
            $context["namespace"] = "fields";
        }
        // line 3
        echo "
";
        // line 4
        $_namespace = (isset($context["namespace"]) || array_key_exists("namespace", $context) ? $context["namespace"] : (function () { throw new Twig_Error_Runtime('Variable "namespace" does not exist.', 4, $this->source); })());
        if ($_namespace) {
            $_originalNamespace = Craft::$app->getView()->getNamespace();
            Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
            ob_start();
            try {
                // line 5
                echo "    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 5, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                    // line 6
                    echo "        <tr data-id=\"\">
            <td class=\"thin rowHeader\">
                <span class=\"heading-text ";
                    // line 8
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "required", array())) {
                        echo "required";
                    }
                    echo "\">
                    ";
                    // line 9
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", array()), "site"), "html", null, true);
                    echo "

                    ";
                    // line 11
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", array())) {
                        // line 12
                        echo "                        <span class=\"info\">";
                        echo call_user_func_array($this->env->getFilter('md')->getCallable(), array($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", array()), "site")));
                        echo "</span>
                    ";
                    }
                    // line 14
                    echo "                </span>
            </td>

            <td>
                ";
                    // line 18
                    $this->loadTemplate("super-table/field", "super-table/matrix/fields", 18)->display(array("field" =>                     // line 19
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 20
$context["field"], "required", array()), "element" =>                     // line 21
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new Twig_Error_Runtime('Variable "element" does not exist.', 21, $this->source); })()), "static" => ((                    // line 22
(isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 22, $this->source); })())) : (null))));
                    // line 24
                    echo "            </td>

            ";
                    // line 26
                    if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 26, $this->source); })())) {
                        // line 27
                        echo "                <td class=\"thin placeholder\"></td>
            ";
                    }
                    // line 29
                    echo "        </tr>
    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
            } catch (Exception $e) {
                ob_end_clean();

                throw $e;
            }
            echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
            Craft::$app->getView()->setNamespace($_originalNamespace);
        } else {
            // line 5
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 5, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 6
                echo "        <tr data-id=\"\">
            <td class=\"thin rowHeader\">
                <span class=\"heading-text ";
                // line 8
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "required", array())) {
                    echo "required";
                }
                echo "\">
                    ";
                // line 9
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", array()), "site"), "html", null, true);
                echo "

                    ";
                // line 11
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", array())) {
                    // line 12
                    echo "                        <span class=\"info\">";
                    echo call_user_func_array($this->env->getFilter('md')->getCallable(), array($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", array()), "site")));
                    echo "</span>
                    ";
                }
                // line 14
                echo "                </span>
            </td>

            <td>
                ";
                // line 18
                $this->loadTemplate("super-table/field", "super-table/matrix/fields", 18)->display(array("field" =>                 // line 19
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 20
$context["field"], "required", array()), "element" =>                 // line 21
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new Twig_Error_Runtime('Variable "element" does not exist.', 21, $this->source); })()), "static" => ((                // line 22
(isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 22, $this->source); })())) : (null))));
                // line 24
                echo "            </td>

            ";
                // line 26
                if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 26, $this->source); })())) {
                    // line 27
                    echo "                <td class=\"thin placeholder\"></td>
            ";
                }
                // line 29
                echo "        </tr>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        unset($_originalNamespace, $_namespace);
    }

    public function getTemplateName()
    {
        return "super-table/matrix/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 29,  152 => 27,  150 => 26,  146 => 24,  144 => 22,  143 => 21,  142 => 20,  141 => 19,  140 => 18,  134 => 14,  128 => 12,  126 => 11,  121 => 9,  115 => 8,  111 => 6,  106 => 5,  91 => 29,  87 => 27,  85 => 26,  81 => 24,  79 => 22,  78 => 21,  77 => 20,  76 => 19,  75 => 18,  69 => 14,  63 => 12,  61 => 11,  56 => 9,  50 => 8,  46 => 6,  41 => 5,  34 => 4,  31 => 3,  27 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if element is not defined %}{% set element = null %}{% endif %}
{% if namespace is not defined %}{% set namespace = 'fields' %}{% endif %}

{% namespace namespace %}
    {% for field in fields %}
        <tr data-id=\"\">
            <td class=\"thin rowHeader\">
                <span class=\"heading-text {% if field.required %}required{% endif %}\">
                    {{ field.name | t('site') }}

                    {% if field.instructions %}
                        <span class=\"info\">{{ field.instructions | t('site') | md | raw }}</span>
                    {% endif %}
                </span>
            </td>

            <td>
                {% include \"super-table/field\" with {
                    field:    field,
                    required: field.required,
                    element:  element,
                    static:   (static is defined ? static : null)
                } only %}
            </td>

            {% if not staticBlocks %}
                <td class=\"thin placeholder\"></td>
            {% endif %}
        </tr>
    {% endfor %}
{% endnamespace %}
", "super-table/matrix/fields", "/app/vendor/verbb/super-table/src/templates/matrix/fields.html");
    }
}

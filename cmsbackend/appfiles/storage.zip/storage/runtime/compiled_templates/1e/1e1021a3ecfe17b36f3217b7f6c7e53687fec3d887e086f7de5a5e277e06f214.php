<?php

/* partials/socialicons-2x.twig */
class __TwigTemplate_146397be264e95d33d891c4ddef97a58473dd041f344af63b5a0b87b2ab84858 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<a class=\"icon icon-facebook text-2x\" href=\"";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["socialUrls"]) || array_key_exists("socialUrls", $context) ? $context["socialUrls"] : (function () { throw new Twig_Error_Runtime('Variable "socialUrls" does not exist.', 1, $this->source); })()), "facebook", array()), "html", null, true);
        echo "\" title=\"Lilyford Foundation on Facebook\" target=\"_blank\"></a>
<a class=\"icon icon-twitter text-2x\" href=\"";
        // line 2
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["socialUrls"]) || array_key_exists("socialUrls", $context) ? $context["socialUrls"] : (function () { throw new Twig_Error_Runtime('Variable "socialUrls" does not exist.', 2, $this->source); })()), "twitter", array()), "html", null, true);
        echo "\" title=\"Lilyford Foundation on Twitter\" target=\"_blank\"></a>
<a class=\"icon icon-instagram text-2x\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["socialUrls"]) || array_key_exists("socialUrls", $context) ? $context["socialUrls"] : (function () { throw new Twig_Error_Runtime('Variable "socialUrls" does not exist.', 3, $this->source); })()), "instagram", array()), "html", null, true);
        echo "\" title=\"Lilyford Foundation on Instagram\" target=\"_blank\"></a>
<a class=\"icon icon-linkedin text-2x\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["socialUrls"]) || array_key_exists("socialUrls", $context) ? $context["socialUrls"] : (function () { throw new Twig_Error_Runtime('Variable "socialUrls" does not exist.', 4, $this->source); })()), "linkedin", array()), "html", null, true);
        echo "\" title=\"Lilyford Foundation on Linkedin\" target=\"_blank\"></a>";
    }

    public function getTemplateName()
    {
        return "partials/socialicons-2x.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  36 => 4,  32 => 3,  28 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<a class=\"icon icon-facebook text-2x\" href=\"{{ socialUrls.facebook }}\" title=\"Lilyford Foundation on Facebook\" target=\"_blank\"></a>
<a class=\"icon icon-twitter text-2x\" href=\"{{ socialUrls.twitter }}\" title=\"Lilyford Foundation on Twitter\" target=\"_blank\"></a>
<a class=\"icon icon-instagram text-2x\" href=\"{{ socialUrls.instagram }}\" title=\"Lilyford Foundation on Instagram\" target=\"_blank\"></a>
<a class=\"icon icon-linkedin text-2x\" href=\"{{ socialUrls.linkedin }}\" title=\"Lilyford Foundation on Linkedin\" target=\"_blank\"></a>", "partials/socialicons-2x.twig", "/app/templates/partials/socialicons-2x.twig");
    }
}

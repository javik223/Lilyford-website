<?php

/* wheelform/_edit-form.twig */
class __TwigTemplate_c8839d0fe80b549e10644375fe031e5f3f225b5364c7d40c2b110a4aa464897a extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "wheelform/_edit-form.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 3
        $context["formEl"] = $this->loadTemplate("_includes/forms", "wheelform/_edit-form.twig", 3);
        // line 5
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", array(0 => "wheelform\\assets\\WheelformCpAsset"), "method");
        // line 7
        $context["title"] = ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["form"] ?? null), "id", array(), "any", true, true)) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Edit Form")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("New Form")));
        // line 8
        $context["docsUrl"] = "https://github.com/xpertbot/craft-wheelform";
        // line 10
        $context["crumbs"] = array(0 => array("label" => "Wheel Form", "url" => craft\helpers\UrlHelper::url("wheelform")));
        // line 14
        $context["fullPageForm"] = true;
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 16
    public function block_content($context, array $blocks = array())
    {
        // line 17
        echo "
    <input type=\"hidden\" name=\"action\" value=\"wheelform/form/save\">
    ";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->redirectInputFunction("wheelform"), "html", null, true);
        echo "
    <input type=\"hidden\" name=\"changed_fields\" id=\"changed_fields\" value=\"0\">
    ";
        // line 21
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["form"] ?? null), "id", array(), "any", true, true)) {
            echo "<input type=\"hidden\" name=\"form_id\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 21, $this->source); })()), "id", array()), "html", null, true);
            echo "\">";
        }
        // line 22
        echo "
    ";
        // line 23
        echo $context["formEl"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Form Name"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 27
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 27, $this->source); })()), "name", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 28
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 28, $this->source); })()), "getErrors", array(0 => "name"), "method"), "first" => true, "autofocus" => true, "required" => true, "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name of this Form in the CP.", "wheelform")));
        // line 33
        echo "

    ";
        // line 35
        echo $context["formEl"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("To Email"), "id" => "to_email", "name" => "to_email", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 39
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 39, $this->source); })()), "to_email", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 40
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 40, $this->source); })()), "getErrors", array(0 => "to_email"), "method"), "required" => true, "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The email address(es) that the contact form will send to. Separate multiple email addresses with commas.", "wheelform")));
        // line 43
        echo "

    ";
        // line 45
        echo $context["formEl"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Honeypot"), "id" => "options[honeypot]", "name" => "options[honeypot]", "value" => ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 49
($context["form"] ?? null), "options", array(), "any", false, true), "honeypot", array(), "array", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 49, $this->source); })()), "options", array()), "honeypot", array(), "array")) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 50
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 50, $this->source); })()), "getErrors", array(0 => "options[honeypot]"), "method"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name of hidden field that helps prevent bot spam. Leave empty to disable.", "wheelform")));
        // line 52
        echo "

    ";
        // line 54
        echo $context["formEl"]->macro_lightswitchField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Active", "wheelform"), "id" => "active", "name" => "active", "on" => (((null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 58
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 58, $this->source); })()), "active", array()))) ? (true) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 58, $this->source); })()), "active", array())))));
        // line 59
        echo "

    ";
        // line 61
        echo $context["formEl"]->macro_lightswitchField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save Entries", "wheelform"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save Entries to database", "wheelform"), "id" => "save_entry", "name" => "save_entry", "on" => (((null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 66
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 66, $this->source); })()), "save_entry", array()))) ? (true) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 66, $this->source); })()), "save_entry", array())))));
        // line 67
        echo "

    ";
        // line 69
        echo $context["formEl"]->macro_lightswitchField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Send Email", "wheelform"), "id" => "send_email", "name" => "send_email", "on" => (((null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 73
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 73, $this->source); })()), "send_email", array()))) ? (true) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 73, $this->source); })()), "send_email", array())))));
        // line 74
        echo "

    ";
        // line 76
        echo $context["formEl"]->macro_lightswitchField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Recaptcha", "wheelform"), "id" => "recaptcha", "name" => "recaptcha", "on" => (((null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 80
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 80, $this->source); })()), "recaptcha", array()))) ? (false) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 80, $this->source); })()), "recaptcha", array())))));
        // line 81
        echo "

    ";
        // line 83
        ob_start();
        // line 84
        echo "        window.Wheelform = {
            form_id: ";
        // line 85
        echo twig_escape_filter($this->env, ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 85, $this->source); })()), "id", array())) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 85, $this->source); })()), "id", array())) : (0)), "html", null, true);
        echo "
        }
    ";
        Craft::$app->getView()->registerJs(ob_get_clean(), 1);
        // line 88
        echo "    <div id=\"formapp\">
        <Container />
    </div>

";
    }

    public function getTemplateName()
    {
        return "wheelform/_edit-form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 88,  123 => 85,  120 => 84,  118 => 83,  114 => 81,  112 => 80,  111 => 76,  107 => 74,  105 => 73,  104 => 69,  100 => 67,  98 => 66,  97 => 61,  93 => 59,  91 => 58,  90 => 54,  86 => 52,  84 => 50,  83 => 49,  82 => 45,  78 => 43,  76 => 40,  75 => 39,  74 => 35,  70 => 33,  68 => 28,  67 => 27,  66 => 23,  63 => 22,  57 => 21,  52 => 19,  48 => 17,  45 => 16,  41 => 1,  39 => 14,  37 => 10,  35 => 8,  33 => 7,  31 => 5,  29 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"_layouts/cp\" %}

{% import \"_includes/forms\" as formEl %}

{% do view.registerAssetBundle(\"wheelform\\\\assets\\\\WheelformCpAsset\") %}

{% set title = (form.id is defined ? 'Edit Form'|t : 'New Form'|t) %}
{% set docsUrl = 'https://github.com/xpertbot/craft-wheelform' %}

{% set crumbs = [
    { label: 'Wheel Form', url: url('wheelform') },
] %}

{% set fullPageForm = true %}

{% block content %}

    <input type=\"hidden\" name=\"action\" value=\"wheelform/form/save\">
    {{ redirectInput('wheelform') }}
    <input type=\"hidden\" name=\"changed_fields\" id=\"changed_fields\" value=\"0\">
    {% if form.id is defined %}<input type=\"hidden\" name=\"form_id\" value=\"{{ form.id }}\">{% endif %}

    {{ formEl.textField({
        label: \"Form Name\"|t,
        id: 'name',
        name: 'name',
        value: form.name,
        errors: form.getErrors('name'),
        first: true,
        autofocus: true,
        required: true,
        instructions: 'Name of this Form in the CP.'|t('wheelform'),
    }) }}

    {{ formEl.textField({
        label: \"To Email\"|t,
        id: 'to_email',
        name: 'to_email',
        value: form.to_email,
        errors: form.getErrors('to_email'),
        required: true,
        instructions: 'The email address(es) that the contact form will send to. Separate multiple email addresses with commas.'|t('wheelform'),
    }) }}

    {{ formEl.textField({
        label: \"Honeypot\"|t,
        id: 'options[honeypot]',
        name: 'options[honeypot]',
        value: (form.options['honeypot'] is defined ? form.options['honeypot'] : ''),
        errors: form.getErrors('options[honeypot]'),
        instructions: 'Name of hidden field that helps prevent bot spam. Leave empty to disable.'|t('wheelform'),
    }) }}

    {{ formEl.lightswitchField({
        label: \"Active\"|t('wheelform'),
        id: 'active',
        name: 'active',
        on: (form.active is null ? true : form.active),
    }) }}

    {{ formEl.lightswitchField({
        label: \"Save Entries\"|t('wheelform'),
        instructions: \"Save Entries to database\"|t('wheelform'),
        id: 'save_entry',
        name: 'save_entry',
        on: (form.save_entry is null ? true : form.save_entry),
    }) }}

    {{ formEl.lightswitchField({
        label: \"Send Email\"|t('wheelform'),
        id: 'send_email',
        name: 'send_email',
        on: (form.send_email is null ? true : form.send_email),
    }) }}

    {{ formEl.lightswitchField({
        label: \"Recaptcha\"|t('wheelform'),
        id: 'recaptcha',
        name: 'recaptcha',
        on: (form.recaptcha is null ? false : form.recaptcha),
    }) }}

    {% js at head %}
        window.Wheelform = {
            form_id: {{ form.id ? form.id : 0 }}
        }
    {% endjs %}
    <div id=\"formapp\">
        <Container />
    </div>

{% endblock %}
", "wheelform/_edit-form.twig", "/app/vendor/xpertbot/craft-wheelform/src/templates/_edit-form.twig");
    }
}

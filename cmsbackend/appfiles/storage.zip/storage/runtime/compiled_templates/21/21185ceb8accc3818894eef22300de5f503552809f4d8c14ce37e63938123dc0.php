<?php

/* _components/utilities/PhpInfo */
class __TwigTemplate_4b588de0e70916a81ba3ae564f479b5767c3bfde6caf39edab902291ae2a0702 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"readable\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["phpInfo"]) || array_key_exists("phpInfo", $context) ? $context["phpInfo"] : (function () { throw new Twig_Error_Runtime('Variable "phpInfo" does not exist.', 2, $this->source); })()));
        foreach ($context['_seq'] as $context["section"] => $context["values"]) {
            // line 3
            echo "        <h2>";
            echo twig_escape_filter($this->env, $context["section"], "html", null, true);
            echo "</h2>
        <table class=\"data fullwidth fixed-layout\">
            <tbody>
                ";
            // line 6
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["values"]);
            foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                // line 7
                echo "                    <tr>
                        <th class=\"light\">";
                // line 8
                echo $context["key"];
                echo "</th>
                        <td>";
                // line 10
                if (twig_test_iterable($context["value"])) {
                    // line 11
                    echo twig_escape_filter($this->env, twig_join_filter($context["value"], ", "), "html", null, true);
                } else {
                    // line 13
                    echo twig_escape_filter($this->env, $context["value"], "html", null, true);
                }
                // line 15
                echo "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 18
            echo "            </tbody>
        </table>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['section'], $context['values'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "_components/utilities/PhpInfo";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 21,  64 => 18,  56 => 15,  53 => 13,  50 => 11,  48 => 10,  44 => 8,  41 => 7,  37 => 6,  30 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"readable\">
    {% for section, values in phpInfo %}
        <h2>{{ section }}</h2>
        <table class=\"data fullwidth fixed-layout\">
            <tbody>
                {% for key, value in values %}
                    <tr>
                        <th class=\"light\">{{ key|raw }}</th>
                        <td>
                            {%- if value is iterable %}
                                {{- value|join(', ') }}
                            {%- else %}
                                {{- value }}
                            {%- endif -%}
                        </td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    {% endfor %}
</div>
", "_components/utilities/PhpInfo", "/app/vendor/craftcms/cms/src/templates/_components/utilities/PhpInfo.html");
    }
}

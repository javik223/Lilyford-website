<?php

/* ./partials/_seo.twig */
class __TwigTemplate_f098df85a4864004bbb11080f14c6553eabc7cd2d0f2e206966fd4d75ccce1eb extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "./partials/_seo.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "./partials/_seo.twig", "/app/templates/partials/_seo.twig");
    }
}

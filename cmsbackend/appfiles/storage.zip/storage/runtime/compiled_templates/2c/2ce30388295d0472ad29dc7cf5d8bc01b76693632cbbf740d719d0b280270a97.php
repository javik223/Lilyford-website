<?php

/* take-action/ */
class __TwigTemplate_f1bed26484130c1fdfd73fddcf9955faa524d1897324d524d3012d64aa5f0841 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "take-action/", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper.twig", "take-action/", 2);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">Take Action</h2>
        <h5 class=\"subheader\">";
        // line 6
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 6, $this->source); })()), "introText", array()), "html", null, true);
        echo "</h5>
    </div>

    ";
        // line 9
        $context["takeActionProgrammes"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 9, $this->source); })()), "takeActionProgrammes", array()), "all", array(), "method");
        // line 10
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["takeActionProgrammes"]) || array_key_exists("takeActionProgrammes", $context) ? $context["takeActionProgrammes"] : (function () { throw new Twig_Error_Runtime('Variable "takeActionProgrammes" does not exist.', 10, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 11
            echo "        <div class=\"grid-container\">
            <div class=\"grid-x margin-bottom-2\">
                <div class=\"hero-card hero-card-dark bg-";
            // line 13
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "takeActionProgrammeColor", array()), "html", null, true);
            echo " color-white\">
                    <div class=\"hero-card__image\">
                        ";
            // line 15
            $context["image"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "takeActionProgrammeImage", array()), "one", array(), "method");
            // line 16
            echo "                        ";
            echo $context["imageHelper"]->macro_srcset(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 16, $this->source); })()), "url", array(), "method"), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 16, $this->source); })()), "title", array()));
            echo "
                    </div>
                    <div class=\"hero-card__content padding-3\">
                        <h2>";
            // line 19
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "takeActionProgrammeTitle", array()), "html", null, true);
            echo "</h2>
                        <p>";
            // line 20
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "takeActionProgrammeExcerpt", array()), "html", null, true);
            echo "</p>
                        <a href=\"";
            // line 21
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "takeActionProgrammeButtonLink", array()), "one", array(), "method"), "url", array()), "html", null, true);
            echo "\" class=\"button uppercase strong dark margin-top-2\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "takeActionProgrammeButtonTitle", array()), "html", null, true);
            echo "</a>
                    </div>
                </div>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "
";
    }

    public function getTemplateName()
    {
        return "take-action/";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 27,  81 => 21,  77 => 20,  73 => 19,  66 => 16,  64 => 15,  59 => 13,  55 => 11,  50 => 10,  48 => 9,  42 => 6,  38 => 4,  35 => 3,  31 => 1,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% import 'macros/image-helper.twig' as imageHelper %}
{% block main %}
    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">Take Action</h2>
        <h5 class=\"subheader\">{{ entry.introText }}</h5>
    </div>

    {% set takeActionProgrammes = entry.takeActionProgrammes.all() %}
    {% for item in takeActionProgrammes %}
        <div class=\"grid-container\">
            <div class=\"grid-x margin-bottom-2\">
                <div class=\"hero-card hero-card-dark bg-{{ item.takeActionProgrammeColor }} color-white\">
                    <div class=\"hero-card__image\">
                        {% set image = item.takeActionProgrammeImage.one() %}
                        {{ imageHelper.srcset(image.url(), image.title) }}
                    </div>
                    <div class=\"hero-card__content padding-3\">
                        <h2>{{ item.takeActionProgrammeTitle }}</h2>
                        <p>{{ item.takeActionProgrammeExcerpt }}</p>
                        <a href=\"{{ item.takeActionProgrammeButtonLink.one().url }}\" class=\"button uppercase strong dark margin-top-2\">{{ item.takeActionProgrammeButtonTitle }}</a>
                    </div>
                </div>
            </div>
        </div>
    {% endfor %}

{% endblock %}", "take-action/", "/app/templates/take-action/index.twig");
    }
}

<?php

/* macros/image-helper */
class __TwigTemplate_2028005ac3e7a128367305e672bbc299096f51f5aec732d29bbf0fac42b3c133 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 17
        echo "
";
    }

    // line 1
    public function macro_srcset($__image__ = null, $__alt__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "image" => $__image__,
            "alt" => $__alt__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "    ";
            if (twig_length_filter($this->env, (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 2, $this->source); })()))) {
                // line 3
                echo "        ";
                $context["transformedImages"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 3, $this->source); })()), "imager", array()), "transformImage", array(0 => (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 3, $this->source); })()), 1 => array(0 => array("width" => 1440), 1 => array("width" => 1000), 2 => array("width" => 600), 3 => array("width" => 400)), 2 => array("fillTransforms" => true)), "method");
                // line 14
                echo "        <img src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 14, $this->source); })()), "imager", array()), "placeholder", array(0 => array("width" => 800, "height" => 600)), "method"), "html", null, true);
                echo "\" sizes=\"100vw\" srcset=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 14, $this->source); })()), "imager", array()), "srcset", array(0 => (isset($context["transformedImages"]) || array_key_exists("transformedImages", $context) ? $context["transformedImages"] : (function () { throw new Twig_Error_Runtime('Variable "transformedImages" does not exist.', 14, $this->source); })())), "method"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, (isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new Twig_Error_Runtime('Variable "alt" does not exist.', 14, $this->source); })()), "html", null, true);
                echo "\">
    ";
            }

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 18
    public function macro_transform($__image__ = null, $__alt__ = null, $__width__ = null, $__height__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "image" => $__image__,
            "alt" => $__alt__,
            "width" => $__width__,
            "height" => $__height__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 19
            echo "    ";
            if (twig_length_filter($this->env, (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 19, $this->source); })()))) {
                // line 20
                echo "        ";
                $context["transformedImage"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 20, $this->source); })()), "imager", array()), "transformImage", array(0 => (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 20, $this->source); })()), 1 => array("width" =>                 // line 21
(isset($context["width"]) || array_key_exists("width", $context) ? $context["width"] : (function () { throw new Twig_Error_Runtime('Variable "width" does not exist.', 21, $this->source); })()), "height" =>                 // line 22
(isset($context["height"]) || array_key_exists("height", $context) ? $context["height"] : (function () { throw new Twig_Error_Runtime('Variable "height" does not exist.', 22, $this->source); })()))), "method");
                // line 24
                echo "        <img src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["transformedImage"]) || array_key_exists("transformedImage", $context) ? $context["transformedImage"] : (function () { throw new Twig_Error_Runtime('Variable "transformedImage" does not exist.', 24, $this->source); })()), "url", array()), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, (isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new Twig_Error_Runtime('Variable "alt" does not exist.', 24, $this->source); })()), "html", null, true);
                echo "\" width=\"";
                echo twig_escape_filter($this->env, (isset($context["width"]) || array_key_exists("width", $context) ? $context["width"] : (function () { throw new Twig_Error_Runtime('Variable "width" does not exist.', 24, $this->source); })()), "html", null, true);
                echo "\" height=\"";
                echo twig_escape_filter($this->env, (isset($context["height"]) || array_key_exists("height", $context) ? $context["height"] : (function () { throw new Twig_Error_Runtime('Variable "height" does not exist.', 24, $this->source); })()), "html", null, true);
                echo "\">
    ";
            }

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "macros/image-helper";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 24,  85 => 22,  84 => 21,  82 => 20,  79 => 19,  64 => 18,  47 => 14,  44 => 3,  41 => 2,  28 => 1,  23 => 17,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro srcset(image, alt) %}
    {% if image | length %}
        {% set transformedImages = craft.imager.transformImage(image, [
            {
                width: 1440
            }, {
                width: 1000
            }, {
                width: 600
            }, {
                width: 400
            }
        ], {fillTransforms: true}) %}
        <img src=\"{{ craft.imager.placeholder({width: 800, height: 600}) }}\" sizes=\"100vw\" srcset=\"{{ craft.imager.srcset(transformedImages) }}\" alt=\"{{ alt }}\">
    {% endif %}
{% endmacro srcset %}

{% macro transform(image, alt, width, height) %}
    {% if image | length %}
        {% set transformedImage = craft.imager.transformImage(image, {
            width: width,
            height: height
        }) %}
        <img src=\"{{ transformedImage.url }}\" alt=\"{{ alt }}\" width=\"{{ width }}\" height=\"{{ height }}\">
    {% endif %}
{% endmacro %}", "macros/image-helper", "/app/templates/macros/image-helper.twig");
    }
}

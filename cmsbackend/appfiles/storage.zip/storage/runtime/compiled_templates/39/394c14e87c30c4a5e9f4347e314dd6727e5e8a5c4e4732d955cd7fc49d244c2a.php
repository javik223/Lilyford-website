<?php

/* seo/index */
class __TwigTemplate_a68f760780de9d083ab860d8b59568e0317c2048cbc90bb8d66f46bed4959ae2 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "seo/index", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["title"] = "SEO";
        // line 3
        $context["selectedSubnavItem"] = "dashboard";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "\t<ul class=\"icons\">
\t\t";
        // line 7
        if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new Twig_Error_Runtime('Variable "currentUser" does not exist.', 7, $this->source); })()), "admin", array()) || craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new Twig_Error_Runtime('Variable "currentUser" does not exist.', 7, $this->source); })()), "can", array(0 => "manageSitemap"), "method"))) {
            // line 8
            echo "\t\t\t<li>
\t\t\t\t<a href=\"";
            // line 9
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("seo/sitemap"), "html", null, true);
            echo "\" data-icon=\"globe\">
\t\t\t\t\tSitemap
\t\t\t\t</a>
\t\t\t</li>
\t\t";
        }
        // line 14
        echo "\t\t";
        if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new Twig_Error_Runtime('Variable "currentUser" does not exist.', 14, $this->source); })()), "admin", array()) || craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new Twig_Error_Runtime('Variable "currentUser" does not exist.', 14, $this->source); })()), "can", array(0 => "manageRedirects"), "method"))) {
            // line 15
            echo "\t\t\t<li>
\t\t\t\t<a href=\"";
            // line 16
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("seo/redirects"), "html", null, true);
            echo "\" data-icon=\"routes\">
\t\t\t\t\tRedirects
\t\t\t\t</a>
\t\t\t</li>
\t\t";
        }
        // line 21
        echo "\t\t";
        // line 26
        echo "\t\t";
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new Twig_Error_Runtime('Variable "currentUser" does not exist.', 26, $this->source); })()), "admin", array())) {
            // line 27
            echo "\t\t\t<li>
\t\t\t\t<a href=\"";
            // line 28
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("seo/settings"), "html", null, true);
            echo "\"
\t\t\t\t   data-icon=\"settings\"
\t\t\t\t>
\t\t\t\t\tSettings
\t\t\t\t</a>
\t\t\t</li>
\t\t";
        }
        // line 35
        echo "\t</ul>
";
    }

    public function getTemplateName()
    {
        return "seo/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 35,  78 => 28,  75 => 27,  72 => 26,  70 => 21,  62 => 16,  59 => 15,  56 => 14,  48 => 9,  45 => 8,  43 => 7,  40 => 6,  37 => 5,  33 => 1,  31 => 3,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"_layouts/cp\" %}
{% set title = 'SEO' %}
{% set selectedSubnavItem = 'dashboard' %}

{% block content %}
\t<ul class=\"icons\">
\t\t{% if currentUser.admin or currentUser.can('manageSitemap') %}
\t\t\t<li>
\t\t\t\t<a href=\"{{ url('seo/sitemap') }}\" data-icon=\"globe\">
\t\t\t\t\tSitemap
\t\t\t\t</a>
\t\t\t</li>
\t\t{% endif %}
\t\t{% if currentUser.admin or currentUser.can('manageRedirects') %}
\t\t\t<li>
\t\t\t\t<a href=\"{{ url('seo/redirects') }}\" data-icon=\"routes\">
\t\t\t\t\tRedirects
\t\t\t\t</a>
\t\t\t</li>
\t\t{% endif %}
\t\t{#<li>
\t\t\t<a href=\"{{ url('seo/schema') }}\" data-icon=\"tags\">
\t\t\t\tSchema
\t\t\t</a>
\t\t</li>#}
\t\t{% if currentUser.admin %}
\t\t\t<li>
\t\t\t\t<a href=\"{{ url('seo/settings') }}\"
\t\t\t\t   data-icon=\"settings\"
\t\t\t\t>
\t\t\t\t\tSettings
\t\t\t\t</a>
\t\t\t</li>
\t\t{% endif %}
\t</ul>
{% endblock %}", "seo/index", "/app/vendor/ether/seo/src/templates/index.twig");
    }
}

<?php

/* super-table/settings */
class __TwigTemplate_5a89efaf1c2cb0cd91bcf0371ea8650e75a5f2eb940bb9440852c3092ba062bd extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "super-table/settings", 1);
        // line 2
        echo "
";
        // line 3
        ob_start();
        // line 4
        echo "    
    <div class=\"stc-sidebar fields\">
        <div class=\"col-inner-container\">
            <div class=\"heading\">
                <h5>";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "site"), "html", null, true);
        echo "</h5>
            </div>

            <div class=\"field-items\">
                ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypes" does not exist.', 12, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 13
            echo "                    <div data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\">
                        ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["blockTypeFields"]) || array_key_exists("blockTypeFields", $context) ? $context["blockTypeFields"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypeFields" does not exist.', 14, $this->source); })()), $context["blockTypeId"], array(), "array"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["fieldId"] => $context["field"]) {
                // line 15
                echo "                            <div class=\"supertableconfigitem stci-field";
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "hasErrors", array(), "method")) {
                    echo " error";
                }
                echo " ";
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "first", array())) {
                    echo "sel";
                }
                echo "\" data-id=\"";
                echo twig_escape_filter($this->env, $context["fieldId"], "html", null, true);
                echo "\">
                                <div class=\"name";
                // line 16
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "required", array())) {
                    echo " required";
                }
                echo "\">
                                    ";
                // line 17
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", array())) {
                    // line 18
                    echo "                                        ";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", array()), "html", null, true);
                    echo "
                                    ";
                } else {
                    // line 20
                    echo "                                        <em class=\"light\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("(blank)", "site"), "html", null, true);
                    echo "</em>
                                    ";
                }
                // line 22
                echo "                                </div>

                                <div class=\"handle code\">
                                    ";
                // line 25
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "handle", array())) {
                    // line 26
                    echo "                                        ";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "handle", array()), "html", null, true);
                    echo "
                                    ";
                } else {
                    // line 28
                    echo "                                        &nbsp;
                                    ";
                }
                // line 30
                echo "                                </div>

                                <div class=\"actions\">
                                    <a class=\"move icon\" title=\"";
                // line 33
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "site"), "html", null, true);
                echo "\" role=\"button\"></a>
                                </div>
                            </div>
                        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['fieldId'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 37
            echo "                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "
                <div class=\"btn add icon\">";
        // line 40
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New field", "site"), "html", null, true);
        echo "</div>
            </div>
        </div>
    </div>

    <div class=\"stc-settings\">
        <div class=\"col-inner-container\">
            <div class=\"heading\">
                <h5>";
        // line 48
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Field Settings", "site"), "html", null, true);
        echo "</h5>
            </div>

            <div class=\"field-items\">
                ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypes" does not exist.', 52, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 53
            echo "                    <div data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\">
                        ";
            // line 54
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["blockTypeFields"]) || array_key_exists("blockTypeFields", $context) ? $context["blockTypeFields"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypeFields" does not exist.', 54, $this->source); })()), $context["blockTypeId"], array(), "array"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["fieldId"] => $context["field"]) {
                // line 55
                echo "                            <div data-id=\"";
                echo twig_escape_filter($this->env, $context["fieldId"], "html", null, true);
                echo "\" ";
                if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "first", array())) {
                    echo "class=\"hidden\"";
                }
                echo ">
                                ";
                // line 56
                $_namespace = (((("blockTypes[" . $context["blockTypeId"]) . "][fields][") . $context["fieldId"]) . "]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 57
                        echo "                                    ";
                        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "site"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 61
$context["field"], "name", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 62
$context["field"], "getErrors", array(0 => "name"), "method"), "autofocus" => true, "required" => true));
                        // line 65
                        echo "

                                    ";
                        // line 67
                        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "site"), "id" => "handle", "class" => "code", "name" => "handle", "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 73
$context["field"], "handle", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 74
$context["field"], "getErrors", array(0 => "handle"), "method"), "required" => true));
                        // line 76
                        echo "

                                    ";
                        // line 78
                        echo $context["forms"]->macro_textareaField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "site"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 83
$context["field"], "instructions", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 84
$context["field"], "getErrors", array(0 => "instructions"), "method")));
                        // line 85
                        echo "
                                ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    // line 57
                    echo "                                    ";
                    echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "site"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 61
$context["field"], "name", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 62
$context["field"], "getErrors", array(0 => "name"), "method"), "autofocus" => true, "required" => true));
                    // line 65
                    echo "

                                    ";
                    // line 67
                    echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "site"), "id" => "handle", "class" => "code", "name" => "handle", "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 73
$context["field"], "handle", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 74
$context["field"], "getErrors", array(0 => "handle"), "method"), "required" => true));
                    // line 76
                    echo "

                                    ";
                    // line 78
                    echo $context["forms"]->macro_textareaField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "site"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 83
$context["field"], "instructions", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 84
$context["field"], "getErrors", array(0 => "instructions"), "method")));
                    // line 85
                    echo "
                                ";
                }
                unset($_originalNamespace, $_namespace);
                // line 87
                echo "
                                ";
                // line 88
                echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Column Width", "super-table"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Only applies for Table Layout. Set the width for this column in either pixels or percentage. i.e. `10px` or `10%`.", "super-table"), "id" => (("columns-" .                 // line 91
$context["fieldId"]) . "-width"), "name" => (("columns[" .                 // line 92
$context["fieldId"]) . "][width]"), "size" => 8, "value" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 94
($context["supertableField"] ?? null), "columns", array(), "any", false, true), $context["fieldId"], array(), "array", false, true), "width", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "columns", array(), "any", false, true), $context["fieldId"], array(), "array", false, true), "width", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "columns", array(), "any", false, true), $context["fieldId"], array(), "array", false, true), "width", array())) : (""))));
                // line 95
                echo "

                                ";
                // line 97
                $_namespace = (((("blockTypes[" . $context["blockTypeId"]) . "][fields][") . $context["fieldId"]) . "]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 98
                        echo "                                    ";
                        echo $context["forms"]->macro_checkboxField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is required", "super-table"), "id" => "required", "name" => "required", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 102
$context["field"], "required", array())));
                        // line 103
                        echo "

                                    ";
                        // line 105
                        echo $context["forms"]->macro_selectField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "site"), "warning" => ((( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 107
$context["field"], "isNew", array(), "method") &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "hasErrors", array(0 => "type"), "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "site")) : ("")), "id" => "type", "name" => "type", "options" => (((twig_slice($this->env,                         // line 110
$context["fieldId"], 0, 3) != "new")) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new Twig_Error_Runtime('Variable "fieldTypes" does not exist.', 110, $this->source); })()), $context["fieldId"], array(), "array")) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new Twig_Error_Runtime('Variable "fieldTypes" does not exist.', 110, $this->source); })()), "new", array()))), "value" => get_class(                        // line 111
$context["field"]), "errors" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                         // line 112
$context["field"], "getErrors", array(0 => "type"), "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getErrors", array(0 => "type"), "method")))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getErrors", array(0 => "type"), "method")) : (null))));
                        // line 113
                        echo "

                                    ";
                        // line 115
                        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 115, $this->source); })()), "app", array()), "getIsMultiSite", array(), "method")) {
                            // line 116
                            echo "                                        ";
                            $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "supportedTranslationMethods", array());
                            // line 117
                            echo "
                                        ";
                            // line 118
                            if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 118, $this->source); })())) > 1)) {
                                // line 119
                                echo "                                            <div id=\"translation-settings\">
                                                ";
                                // line 120
                                echo $context["forms"]->macro_selectField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "site"), "id" => "translation-method", "name" => "translationMethod", "options" => array_filter(array(0 => ((twig_in_filter("none",                                 // line 125
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 125, $this->source); })()))) ? (array("value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app"))) : ("")), 1 => ((twig_in_filter("site",                                 // line 126
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 126, $this->source); })()))) ? (array("value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app"))) : ("")), 2 => ((twig_in_filter("siteGroup",                                 // line 127
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 127, $this->source); })()))) ? (array("value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app"))) : ("")), 3 => ((twig_in_filter("language",                                 // line 128
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 128, $this->source); })()))) ? (array("value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app"))) : ("")), 4 => ((twig_in_filter("custom",                                 // line 129
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 129, $this->source); })()))) ? (array("value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app"))) : ("")))), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                                 // line 131
$context["field"], "translationMethod", array()), "toggle" => true, "targetPrefix" => "translation-method-"));
                                // line 134
                                echo "

                                                ";
                                // line 136
                                if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 136, $this->source); })()))) {
                                    // line 137
                                    echo "                                                    <div id=\"translation-method-custom\" ";
                                    if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "translationMethod", array()) != "custom")) {
                                        echo "class=\"hidden\"";
                                    }
                                    echo ">
                                                        ";
                                    // line 138
                                    echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "site"), "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                                     // line 142
$context["field"], "translationKeyFormat", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                                     // line 143
$context["field"], "getErrors", array(0 => "translationKeyFormat"), "method")));
                                    // line 144
                                    echo "
                                                    </div>
                                                ";
                                }
                                // line 147
                                echo "                                            </div>
                                        ";
                            }
                            // line 149
                            echo "                                    ";
                        }
                        // line 150
                        echo "                                ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    // line 98
                    echo "                                    ";
                    echo $context["forms"]->macro_checkboxField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is required", "super-table"), "id" => "required", "name" => "required", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 102
$context["field"], "required", array())));
                    // line 103
                    echo "

                                    ";
                    // line 105
                    echo $context["forms"]->macro_selectField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "site"), "warning" => ((( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 107
$context["field"], "isNew", array(), "method") &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "hasErrors", array(0 => "type"), "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "site")) : ("")), "id" => "type", "name" => "type", "options" => (((twig_slice($this->env,                     // line 110
$context["fieldId"], 0, 3) != "new")) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new Twig_Error_Runtime('Variable "fieldTypes" does not exist.', 110, $this->source); })()), $context["fieldId"], array(), "array")) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new Twig_Error_Runtime('Variable "fieldTypes" does not exist.', 110, $this->source); })()), "new", array()))), "value" => get_class(                    // line 111
$context["field"]), "errors" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 112
$context["field"], "getErrors", array(0 => "type"), "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getErrors", array(0 => "type"), "method")))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getErrors", array(0 => "type"), "method")) : (null))));
                    // line 113
                    echo "

                                    ";
                    // line 115
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 115, $this->source); })()), "app", array()), "getIsMultiSite", array(), "method")) {
                        // line 116
                        echo "                                        ";
                        $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "supportedTranslationMethods", array());
                        // line 117
                        echo "
                                        ";
                        // line 118
                        if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 118, $this->source); })())) > 1)) {
                            // line 119
                            echo "                                            <div id=\"translation-settings\">
                                                ";
                            // line 120
                            echo $context["forms"]->macro_selectField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "site"), "id" => "translation-method", "name" => "translationMethod", "options" => array_filter(array(0 => ((twig_in_filter("none",                             // line 125
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 125, $this->source); })()))) ? (array("value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app"))) : ("")), 1 => ((twig_in_filter("site",                             // line 126
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 126, $this->source); })()))) ? (array("value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app"))) : ("")), 2 => ((twig_in_filter("siteGroup",                             // line 127
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 127, $this->source); })()))) ? (array("value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app"))) : ("")), 3 => ((twig_in_filter("language",                             // line 128
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 128, $this->source); })()))) ? (array("value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app"))) : ("")), 4 => ((twig_in_filter("custom",                             // line 129
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 129, $this->source); })()))) ? (array("value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app"))) : ("")))), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                             // line 131
$context["field"], "translationMethod", array()), "toggle" => true, "targetPrefix" => "translation-method-"));
                            // line 134
                            echo "

                                                ";
                            // line 136
                            if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 136, $this->source); })()))) {
                                // line 137
                                echo "                                                    <div id=\"translation-method-custom\" ";
                                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "translationMethod", array()) != "custom")) {
                                    echo "class=\"hidden\"";
                                }
                                echo ">
                                                        ";
                                // line 138
                                echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "site"), "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                                 // line 142
$context["field"], "translationKeyFormat", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                                 // line 143
$context["field"], "getErrors", array(0 => "translationKeyFormat"), "method")));
                                // line 144
                                echo "
                                                    </div>
                                                ";
                            }
                            // line 147
                            echo "                                            </div>
                                        ";
                        }
                        // line 149
                        echo "                                    ";
                    }
                    // line 150
                    echo "                                ";
                }
                unset($_originalNamespace, $_namespace);
                // line 151
                echo "
                                <hr>

                                <div class=\"fieldtype-settings\">
                                    <div>
                                        ";
                // line 156
                $_namespace = (((("blockTypes[" . $context["blockTypeId"]) . "][fields][") . $context["fieldId"]) . "][typesettings]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 157
                        echo "                                            ";
                        // line 158
                        echo "                                            ";
                        // line 159
                        echo "                                            
                                            ";
                        // line 160
                        if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "displayName", array(), "method") == "Matrix")) {
                            // line 161
                            echo "                                                ";
                            echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 161, $this->source); })()), "superTable", array()), "getMatrixSettingsHtml", array(0 => $context["field"]), "method");
                            echo "
                                            ";
                        } else {
                            // line 163
                            echo "                                                ";
                            echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getSettingsHtml", array(), "method");
                            echo "
                                            ";
                        }
                        // line 165
                        echo "                                        ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    // line 157
                    echo "                                            ";
                    // line 158
                    echo "                                            ";
                    // line 159
                    echo "                                            
                                            ";
                    // line 160
                    if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "displayName", array(), "method") == "Matrix")) {
                        // line 161
                        echo "                                                ";
                        echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 161, $this->source); })()), "superTable", array()), "getMatrixSettingsHtml", array(0 => $context["field"]), "method");
                        echo "
                                            ";
                    } else {
                        // line 163
                        echo "                                                ";
                        echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getSettingsHtml", array(), "method");
                        echo "
                                            ";
                    }
                    // line 165
                    echo "                                        ";
                }
                unset($_originalNamespace, $_namespace);
                // line 166
                echo "                                    </div>
                                </div>

                                <hr>

                                <a class=\"error delete\">";
                // line 171
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "site"), "html", null, true);
                echo "</a>
                            </div>
                        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['fieldId'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 174
            echo "                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 176
        echo "            </div>
        </div>
    </div>

";
        $context["blockTypeInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 181
        echo "
";
        // line 182
        echo $context["forms"]->macro_selectField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Layout", "super-table"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Set how fields are presented. Table Layout displays fields vertically in a table, Row Layout displays fields horizontally and Matrix layout displays fields like a Matrix field.", "super-table"), "id" => "fieldLayout", "name" => "fieldLayout", "options" => array("table" => "Table Layout", "row" => "Row Layout", "matrix" => "Matrix Layout"), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 188
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 188, $this->source); })()), "fieldLayout", array())));
        // line 189
        echo "

<div id=\"supertable-configurator\" class=\"supertable-configurator\">
    ";
        // line 192
        echo $context["forms"]->macro_field(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Configuration"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Define the fields your Super Table should have.", "super-table"), "name" => "config"),         // line 196
(isset($context["blockTypeInput"]) || array_key_exists("blockTypeInput", $context) ? $context["blockTypeInput"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypeInput" does not exist.', 196, $this->source); })()));
        echo "
</div>

";
        // line 199
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 199, $this->source); })()), "app", array()), "getIsMultiSite", array(), "method")) {
            // line 200
            echo "    ";
            echo $context["forms"]->macro_checkboxField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Manage blocks on a per-site basis", "super-table"), "id" => "localize-blocks", "name" => "localizeBlocks", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 204
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 204, $this->source); })()), "localizeBlocks", array())));
            // line 205
            echo "
";
        }
        // line 207
        echo "
";
        // line 208
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("New Row Label", "super-table"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enter the text you want to appear in the button to create a new row.", "super-table"), "id" => "selectionLabel", "name" => "selectionLabel", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 213
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 213, $this->source); })()), "selectionLabel", array()), "placeholder" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 214
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 214, $this->source); })()), "defaultSelectionLabel", array(), "method"), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 215
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 215, $this->source); })()), "getErrors", array(0 => "selectionLabel"), "method")));
        // line 216
        echo "

";
        // line 218
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Min Rows", "super-table"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The minimum number of rows the field must to have.", "super-table"), "id" => "minRows", "name" => "minRows", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 223
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 223, $this->source); })()), "minRows", array()), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 225
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 225, $this->source); })()), "getErrors", array(0 => "minRows"), "method")));
        // line 226
        echo "

";
        // line 228
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Rows", "super-table"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of rows the field is allowed to have.", "super-table"), "id" => "maxRows", "name" => "maxRows", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 233
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 233, $this->source); })()), "maxRows", array()), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 235
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 235, $this->source); })()), "getErrors", array(0 => "maxRows"), "method")));
        // line 236
        echo "

";
        // line 238
        echo $context["forms"]->macro_lightswitchField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Static field", "super-table"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("A static field will only display a single row of fields.", "super-table"), "id" => "staticField", "name" => "staticField", "on" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 243
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 243, $this->source); })()), "staticField", array())));
        // line 244
        echo "
";
    }

    public function getTemplateName()
    {
        return "super-table/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  606 => 244,  604 => 243,  603 => 238,  599 => 236,  597 => 235,  596 => 233,  595 => 228,  591 => 226,  589 => 225,  588 => 223,  587 => 218,  583 => 216,  581 => 215,  580 => 214,  579 => 213,  578 => 208,  575 => 207,  571 => 205,  569 => 204,  567 => 200,  565 => 199,  559 => 196,  558 => 192,  553 => 189,  551 => 188,  550 => 182,  547 => 181,  540 => 176,  533 => 174,  516 => 171,  509 => 166,  505 => 165,  499 => 163,  493 => 161,  491 => 160,  488 => 159,  486 => 158,  484 => 157,  474 => 165,  468 => 163,  462 => 161,  460 => 160,  457 => 159,  455 => 158,  453 => 157,  446 => 156,  439 => 151,  435 => 150,  432 => 149,  428 => 147,  423 => 144,  421 => 143,  420 => 142,  419 => 138,  412 => 137,  410 => 136,  406 => 134,  404 => 131,  403 => 129,  402 => 128,  401 => 127,  400 => 126,  399 => 125,  398 => 120,  395 => 119,  393 => 118,  390 => 117,  387 => 116,  385 => 115,  381 => 113,  379 => 112,  378 => 111,  377 => 110,  376 => 107,  375 => 105,  371 => 103,  369 => 102,  367 => 98,  357 => 150,  354 => 149,  350 => 147,  345 => 144,  343 => 143,  342 => 142,  341 => 138,  334 => 137,  332 => 136,  328 => 134,  326 => 131,  325 => 129,  324 => 128,  323 => 127,  322 => 126,  321 => 125,  320 => 120,  317 => 119,  315 => 118,  312 => 117,  309 => 116,  307 => 115,  303 => 113,  301 => 112,  300 => 111,  299 => 110,  298 => 107,  297 => 105,  293 => 103,  291 => 102,  289 => 98,  282 => 97,  278 => 95,  276 => 94,  275 => 92,  274 => 91,  273 => 88,  270 => 87,  265 => 85,  263 => 84,  262 => 83,  261 => 78,  257 => 76,  255 => 74,  254 => 73,  253 => 67,  249 => 65,  247 => 62,  246 => 61,  244 => 57,  233 => 85,  231 => 84,  230 => 83,  229 => 78,  225 => 76,  223 => 74,  222 => 73,  221 => 67,  217 => 65,  215 => 62,  214 => 61,  212 => 57,  205 => 56,  196 => 55,  179 => 54,  174 => 53,  170 => 52,  163 => 48,  152 => 40,  149 => 39,  142 => 37,  124 => 33,  119 => 30,  115 => 28,  109 => 26,  107 => 25,  102 => 22,  96 => 20,  90 => 18,  88 => 17,  82 => 16,  69 => 15,  52 => 14,  47 => 13,  43 => 12,  36 => 8,  30 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{% set blockTypeInput %}
    
    <div class=\"stc-sidebar fields\">
        <div class=\"col-inner-container\">
            <div class=\"heading\">
                <h5>{{ \"Fields\" | t('site') }}</h5>
            </div>

            <div class=\"field-items\">
                {% for blockTypeId, blockType in blockTypes %}
                    <div data-id=\"{{ blockTypeId }}\">
                        {% for fieldId, field in blockTypeFields[blockTypeId] %}
                            <div class=\"supertableconfigitem stci-field{% if field.hasErrors() %} error{% endif %} {% if loop.first %}sel{% endif %}\" data-id=\"{{ fieldId }}\">
                                <div class=\"name{% if field.required %} required{% endif %}\">
                                    {% if field.name %}
                                        {{ field.name }}
                                    {% else %}
                                        <em class=\"light\">{{ '(blank)' | t('site') }}</em>
                                    {% endif %}
                                </div>

                                <div class=\"handle code\">
                                    {% if field.handle %}
                                        {{ field.handle }}
                                    {% else %}
                                        &nbsp;
                                    {% endif %}
                                </div>

                                <div class=\"actions\">
                                    <a class=\"move icon\" title=\"{{ 'Reorder' | t('site') }}\" role=\"button\"></a>
                                </div>
                            </div>
                        {% endfor %}
                    </div>
                {% endfor %}

                <div class=\"btn add icon\">{{ \"New field\" | t('site') }}</div>
            </div>
        </div>
    </div>

    <div class=\"stc-settings\">
        <div class=\"col-inner-container\">
            <div class=\"heading\">
                <h5>{{ \"Field Settings\" | t('site') }}</h5>
            </div>

            <div class=\"field-items\">
                {% for blockTypeId, blockType in blockTypes %}
                    <div data-id=\"{{ blockTypeId }}\">
                        {% for fieldId, field in blockTypeFields[blockTypeId] %}
                            <div data-id=\"{{ fieldId }}\" {% if not loop.first %}class=\"hidden\"{% endif %}>
                                {% namespace 'blockTypes[' ~ blockTypeId ~ '][fields][' ~ fieldId ~ ']' %}
                                    {{ forms.textField({
                                        label: \"Name\" | t('site'),
                                        id: 'name',
                                        name: 'name',
                                        value: field.name,
                                        errors: field.getErrors('name'),
                                        autofocus: true,
                                        required: true,
                                    }) }}

                                    {{ forms.textField({
                                        label: \"Handle\" | t('site'),
                                        id: 'handle',
                                        class: 'code',
                                        name: 'handle',
                                        maxlength: 64,
                                        value: field.handle,
                                        errors: field.getErrors('handle'),
                                        required: true,
                                    }) }}

                                    {{ forms.textareaField({
                                        label: \"Instructions\" | t('site'),
                                        id: 'instructions',
                                        class: 'nicetext',
                                        name: 'instructions',
                                        value: field.instructions,
                                        errors: field.getErrors('instructions'),
                                    }) }}
                                {% endnamespace %}

                                {{ forms.textField({
                                    label: \"Column Width\" | t('super-table'),
                                    instructions: \"Only applies for Table Layout. Set the width for this column in either pixels or percentage. i.e. `10px` or `10%`.\" | t('super-table'),
                                    id: 'columns-' ~ fieldId ~ '-width',
                                    name: 'columns[' ~ fieldId ~ '][width]',
                                    size: 8,
                                    value: supertableField.columns[fieldId].width ?? '',
                                }) }}

                                {% namespace 'blockTypes[' ~ blockTypeId ~ '][fields][' ~ fieldId ~ ']' %}
                                    {{ forms.checkboxField({
                                        label: \"This field is required\" | t('super-table'),
                                        id: 'required',
                                        name: 'required',
                                        checked: field.required
                                    }) }}

                                    {{ forms.selectField({
                                        label: \"Field Type\" | t('site'),
                                        warning: (not field.isNew() and not field.hasErrors('type') ? \"Changing this may result in data loss.\" | t('site')),
                                        id: 'type',
                                        name: 'type',
                                        options: fieldId[0:3] != 'new' ? fieldTypes[fieldId] : fieldTypes.new,
                                        value: className(field),
                                        errors: field.getErrors('type') ?? null
                                    }) }}

                                    {% if craft.app.getIsMultiSite() %}
                                        {% set translationMethods = field.supportedTranslationMethods %}

                                        {% if translationMethods | length > 1 %}
                                            <div id=\"translation-settings\">
                                                {{ forms.selectField({
                                                    label: \"Translation Method\" | t('site'),
                                                    id: 'translation-method',
                                                    name: 'translationMethod',
                                                    options: [
                                                        'none' in translationMethods ? { value: 'none', label: \"Not translatable\" | t('app') },
                                                        'site' in translationMethods ? { value: 'site', label: \"Translate for each site\" | t('app') },
                                                        'siteGroup' in translationMethods ? { value: 'siteGroup', label: \"Translate for each site group\" | t('app') },
                                                        'language' in translationMethods ? { value: 'language', label: \"Translate for each language\" | t('app') },
                                                        'custom' in translationMethods ? { value: 'custom', label: \"Custom…\" | t('app') }
                                                    ] | filter,
                                                    value: field.translationMethod,
                                                    toggle: true,
                                                    targetPrefix: 'translation-method-'
                                                }) }}

                                                {% if 'custom' in translationMethods %}
                                                    <div id=\"translation-method-custom\" {% if field.translationMethod != 'custom' %}class=\"hidden\"{% endif %}>
                                                        {{ forms.textField({
                                                            label: \"Translation Key Format\" | t('site'),
                                                            id: 'translation-key-format',
                                                            name: 'translationKeyFormat',
                                                            value: field.translationKeyFormat,
                                                            errors: field.getErrors('translationKeyFormat')
                                                        }) }}
                                                    </div>
                                                {% endif %}
                                            </div>
                                        {% endif %}
                                    {% endif %}
                                {% endnamespace %}

                                <hr>

                                <div class=\"fieldtype-settings\">
                                    <div>
                                        {% namespace 'blockTypes[' ~ blockTypeId ~ '][fields][' ~ fieldId ~ '][typesettings]' %}
                                            {# Special-case for Matrix at the moment - hopefully will not be needed after core alts #}
                                            {# This is necessary to load our MatrixConfiguratorAlt.js rather than core Matrix JS #}
                                            
                                            {% if field.displayName() == 'Matrix' %}
                                                {{ craft.superTable.getMatrixSettingsHtml(field) | raw }}
                                            {% else %}
                                                {{ field.getSettingsHtml() | raw }}
                                            {% endif %}
                                        {% endnamespace %}
                                    </div>
                                </div>

                                <hr>

                                <a class=\"error delete\">{{ \"Delete\" | t('site') }}</a>
                            </div>
                        {% endfor %}
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>

{% endset %}

{{ forms.selectField({
    label: \"Field Layout\" | t('super-table'),
    instructions: \"Set how fields are presented. Table Layout displays fields vertically in a table, Row Layout displays fields horizontally and Matrix layout displays fields like a Matrix field.\" | t('super-table'),
    id: 'fieldLayout',
    name: 'fieldLayout',
    options: {table: 'Table Layout', row: \"Row Layout\", matrix: \"Matrix Layout\"},
    value: supertableField.fieldLayout,
}) }}

<div id=\"supertable-configurator\" class=\"supertable-configurator\">
    {{ forms.field({
        label: \"Configuration\" | t,
        instructions: \"Define the fields your Super Table should have.\" | t('super-table'),
        name: 'config'
    }, blockTypeInput) }}
</div>

{% if craft.app.getIsMultiSite() %}
    {{ forms.checkboxField({
        label: \"Manage blocks on a per-site basis\" | t('super-table'),
        id: 'localize-blocks',
        name: 'localizeBlocks',
        checked: supertableField.localizeBlocks
    }) }}
{% endif %}

{{ forms.textField({
    label: \"New Row Label\" | t('super-table'),
    instructions: \"Enter the text you want to appear in the button to create a new row.\" | t('super-table'),
    id: 'selectionLabel',
    name: 'selectionLabel',
    value: supertableField.selectionLabel,
    placeholder: supertableField.defaultSelectionLabel(),
    errors: supertableField.getErrors('selectionLabel')
}) }}

{{ forms.textField({
    label: \"Min Rows\" | t('super-table'),
    instructions: \"The minimum number of rows the field must to have.\" | t('super-table'),
    id: 'minRows',
    name: 'minRows',
    value: supertableField.minRows,
    size: 3,
    errors: supertableField.getErrors('minRows')
}) }}

{{ forms.textField({
    label: \"Max Rows\" | t('super-table'),
    instructions: \"The maximum number of rows the field is allowed to have.\" | t('super-table'),
    id: 'maxRows',
    name: 'maxRows',
    value: supertableField.maxRows,
    size: 3,
    errors: supertableField.getErrors('maxRows')
}) }}

{{ forms.lightswitchField({
    label: \"Static field\" | t('super-table'),
    instructions: \"A static field will only display a single row of fields.\" | t('super-table'),
    id: 'staticField',
    name: 'staticField',
    on: supertableField.staticField,
}) }}
", "super-table/settings", "/app/vendor/verbb/super-table/src/templates/settings.html");
    }
}

<?php

/* colour-swatches/input */
class __TwigTemplate_35649238cf81dbffc7674613efec84e45743b9f80e67417c9d12cb7011d92763 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 15
        echo "
";
        // line 16
        $context["forms"] = $this->loadTemplate("_includes/forms", "colour-swatches/input", 16);
        // line 17
        echo "
";
        // line 18
        $context["defaultValue"] = null;
        // line 19
        echo "
<div id=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 20, $this->source); })()), "html", null, true);
        echo "\" class=\"color-swatches\">
    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 21, $this->source); })()), "options", array()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 22
            echo "        ";
            $context["optionId"] = (((isset($context["namespacedId"]) || array_key_exists("namespacedId", $context) ? $context["namespacedId"] : (function () { throw new Twig_Error_Runtime('Variable "namespacedId" does not exist.', 22, $this->source); })()) . "-option-") . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index", array()));
            // line 23
            echo "        ";
            $context["value"] = array("label" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 24
$context["option"], "label", array()), "color" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 25
$context["option"], "color", array()));
            // line 27
            echo "        ";
            if (twig_in_filter(";", craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 27, $this->source); })()), "color", array()))) {
                // line 28
                echo "            ";
                $context["colours"] = twig_split_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 28, $this->source); })()), "color", array()), ";");
                // line 29
                echo "        ";
            } else {
                // line 30
                echo "            ";
                $context["colours"] = twig_split_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 30, $this->source); })()), "color", array()), ",");
                // line 31
                echo "        ";
            }
            // line 32
            echo "
        ";
            // line 34
            echo "        ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["option"], "default", array()) &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["fieldValue"]) || array_key_exists("fieldValue", $context) ? $context["fieldValue"] : (function () { throw new Twig_Error_Runtime('Variable "fieldValue" does not exist.', 34, $this->source); })()), "color", array()))) {
                // line 35
                echo "            ";
                $context["defaultValue"] = $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 35, $this->source); })()));
                // line 36
                echo "        ";
            }
            // line 37
            echo "
        <button type=\"button\" title=\"";
            // line 38
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["option"], "label", array()), "html", null, true);
            echo "\" data-value=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 38, $this->source); })())), "html", null, true);
            echo "\" class=\"option ";
            if (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["option"], "default", array()) &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["fieldValue"]) || array_key_exists("fieldValue", $context) ? $context["fieldValue"] : (function () { throw new Twig_Error_Runtime('Variable "fieldValue" does not exist.', 38, $this->source); })()), "color", array())) || (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["fieldValue"]) || array_key_exists("fieldValue", $context) ? $context["fieldValue"] : (function () { throw new Twig_Error_Runtime('Variable "fieldValue" does not exist.', 38, $this->source); })()), "color", array()) == craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["option"], "color", array())))) {
                echo " active";
            }
            echo "\"
                style=\"
            ";
            // line 40
            switch (twig_length_filter($this->env, (isset($context["colours"]) || array_key_exists("colours", $context) ? $context["colours"] : (function () { throw new Twig_Error_Runtime('Variable "colours" does not exist.', 40, $this->source); })()))) {
                case 1:
                {
                    // line 42
                    echo "                        background: ";
                    echo $this->extensions['craft\web\twig\Extension']->parseRefsFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 42, $this->source); })()), "color", array()));
                    echo ";
                    ";
                    break;
                }
                default:
                {
                    // line 44
                    echo "                        ";
                    $context["percentage"] = (100 / twig_length_filter($this->env, (isset($context["colours"]) || array_key_exists("colours", $context) ? $context["colours"] : (function () { throw new Twig_Error_Runtime('Variable "colours" does not exist.', 44, $this->source); })())));
                    // line 45
                    echo "                        background: linear-gradient(to bottom right, ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["colours"]) || array_key_exists("colours", $context) ? $context["colours"] : (function () { throw new Twig_Error_Runtime('Variable "colours" does not exist.', 45, $this->source); })()));
                    $context['loop'] = array(
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    );
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["colour"]) {
                        echo $this->extensions['craft\web\twig\Extension']->parseRefsFilter($context["colour"]);
                        echo " ";
                        echo twig_escape_filter($this->env, ((isset($context["percentage"]) || array_key_exists("percentage", $context) ? $context["percentage"] : (function () { throw new Twig_Error_Runtime('Variable "percentage" does not exist.', 45, $this->source); })()) * craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index0", array())), "html", null, true);
                        echo "%, ";
                        echo $this->extensions['craft\web\twig\Extension']->parseRefsFilter($context["colour"]);
                        echo " ";
                        echo twig_escape_filter($this->env, ((isset($context["percentage"]) || array_key_exists("percentage", $context) ? $context["percentage"] : (function () { throw new Twig_Error_Runtime('Variable "percentage" does not exist.', 45, $this->source); })()) * craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index", array())), "html", null, true);
                        echo "%";
                        if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "last", array())) {
                            echo ",";
                        }
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['colour'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    echo ");
            ";
                }
            }
            // line 47
            echo "        \"></button>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "
</div>

<input id=\"";
        // line 52
        echo twig_escape_filter($this->env, (isset($context["namespacedId"]) || array_key_exists("namespacedId", $context) ? $context["namespacedId"] : (function () { throw new Twig_Error_Runtime('Variable "namespacedId" does not exist.', 52, $this->source); })()), "html", null, true);
        echo "\" type=\"hidden\" name=\"";
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 52, $this->source); })()), "html", null, true);
        echo "\" value=\"";
        echo twig_escape_filter($this->env, (($context["defaultValue"]) ?? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["fieldValue"]) || array_key_exists("fieldValue", $context) ? $context["fieldValue"] : (function () { throw new Twig_Error_Runtime('Variable "fieldValue" does not exist.', 52, $this->source); })())))), "html", null, true);
        echo "\">
";
    }

    public function getTemplateName()
    {
        return "colour-swatches/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 52,  182 => 49,  167 => 47,  122 => 45,  119 => 44,  110 => 42,  106 => 40,  95 => 38,  92 => 37,  89 => 36,  86 => 35,  83 => 34,  80 => 32,  77 => 31,  74 => 30,  71 => 29,  68 => 28,  65 => 27,  63 => 25,  62 => 24,  60 => 23,  57 => 22,  40 => 21,  36 => 20,  33 => 19,  31 => 18,  28 => 17,  26 => 16,  23 => 15,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * color-swatches plugin for Craft CMS 3.x
 *
 * ColourSwatches Field Input
 *
 * @author    Rias
 * @copyright Copyright (c) 2018 Rias
 * @link      https://rias.be
 * @package   Colour Swatches
 * @since     1.0.0
 */
#}

{% import \"_includes/forms\" as forms %}

{% set defaultValue = null %}

<div id=\"{{ id }}\" class=\"color-swatches\">
    {% for option in field.options %}
        {% set optionId = namespacedId ~ '-option-' ~ loop.index %}
        {% set value = {
            label: option.label,
            color: option.color,
        } %}
        {% if ';' in value.color %}
            {% set colours = value.color | split(';') %}
        {% else %}
            {% set colours = value.color | split(',') %}
        {% endif %}

        {# Set the default value #}
        {% if option.default and not fieldValue.color %}
            {% set defaultValue = value|json_encode %}
        {% endif %}

        <button type=\"button\" title=\"{{ option.label }}\" data-value=\"{{ value | json_encode }}\" class=\"option {% if (option.default and not fieldValue.color) or (fieldValue.color == option.color) %} active{% endif %}\"
                style=\"
            {% switch colours | length %}
                    {% case 1 %}
                        background: {{ value.color|parseRefs|raw }};
                    {% default %}
                        {% set percentage = 100 / colours | length %}
                        background: linear-gradient(to bottom right, {% for colour in colours %}{{ colour|parseRefs|raw }} {{ percentage * loop.index0 }}%, {{ colour|parseRefs|raw }} {{ percentage * loop.index }}%{% if not loop.last %},{% endif %}{% endfor %});
            {% endswitch %}
        \"></button>
    {% endfor %}

</div>

<input id=\"{{ namespacedId }}\" type=\"hidden\" name=\"{{ name }}\" value=\"{{ defaultValue ?? fieldValue|json_encode }}\">
", "colour-swatches/input", "/app/vendor/rias/craft-colour-swatches/src/templates/input.twig");
    }
}

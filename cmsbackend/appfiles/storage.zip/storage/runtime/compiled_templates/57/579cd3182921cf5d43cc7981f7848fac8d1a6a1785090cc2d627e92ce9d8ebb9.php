<?php

/* macros/image-helper.twig */
class __TwigTemplate_80fc15972566ccfdf68b340619863c364aa8236c0301fd95948633bda295dc30 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 15
        echo "
";
    }

    // line 1
    public function macro_srcset($__image__ = null, $__alt__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "image" => $__image__,
            "alt" => $__alt__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "    ";
            if (twig_length_filter($this->env, ($context["image"] ?? null))) {
                // line 3
                echo "        ";
                $context["transformedImages"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "imager", array()), "transformImage", array(0 => ($context["image"] ?? null), 1 => array(0 => array("width" => 1200), 1 => array("width" => 600), 2 => array("width" => 400)), 2 => array("fillTransforms" => true)), "method");
                // line 12
                echo "        <img src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "imager", array()), "placeholder", array(0 => array("width" => 800, "height" => 600)), "method"), "html", null, true);
                echo "\" sizes=\"100vw\" srcset=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "imager", array()), "srcset", array(0 => ($context["transformedImages"] ?? null)), "method"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, ($context["alt"] ?? null), "html", null, true);
                echo "\">
    ";
            }

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 16
    public function macro_transform($__image__ = null, $__alt__ = null, $__width__ = null, $__height__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "image" => $__image__,
            "alt" => $__alt__,
            "width" => $__width__,
            "height" => $__height__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 17
            echo "    ";
            if (twig_length_filter($this->env, ($context["image"] ?? null))) {
                // line 18
                echo "        ";
                $context["transformedImage"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "imager", array()), "transformImage", array(0 => ($context["image"] ?? null), 1 => array("width" =>                 // line 19
($context["width"] ?? null), "height" =>                 // line 20
($context["height"] ?? null))), "method");
                // line 22
                echo "        <img src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["transformedImage"] ?? null), "url", array()), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, ($context["alt"] ?? null), "html", null, true);
                echo "\" width=\"";
                echo twig_escape_filter($this->env, ($context["width"] ?? null), "html", null, true);
                echo "\" height=\"";
                echo twig_escape_filter($this->env, ($context["height"] ?? null), "html", null, true);
                echo "\">
    ";
            }

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "macros/image-helper.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 22,  85 => 20,  84 => 19,  82 => 18,  79 => 17,  64 => 16,  47 => 12,  44 => 3,  41 => 2,  28 => 1,  23 => 15,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro srcset(image, alt) %}
    {% if image | length %}
        {% set transformedImages = craft.imager.transformImage(image, [
            {
                width: 1200
            }, {
                width: 600
            }, {
                width: 400
            }
        ], {fillTransforms: true}) %}
        <img src=\"{{ craft.imager.placeholder({width: 800, height: 600}) }}\" sizes=\"100vw\" srcset=\"{{ craft.imager.srcset(transformedImages) }}\" alt=\"{{ alt }}\">
    {% endif %}
{% endmacro srcset %}

{% macro transform(image, alt, width, height) %}
    {% if image | length %}
        {% set transformedImage = craft.imager.transformImage(image, {
            width: width,
            height: height
        }) %}
        <img src=\"{{ transformedImage.url }}\" alt=\"{{ alt }}\" width=\"{{ width }}\" height=\"{{ height }}\">
    {% endif %}
{% endmacro %}", "macros/image-helper.twig", "/app/templates/macros/image-helper.twig");
    }
}

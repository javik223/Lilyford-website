<?php

/* field-manager/_single/field_edit */
class __TwigTemplate_66858ce2bdb24ee11bef6cafd7660de0bbbd9648aa845102a1e070d4ab71c4ed extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "field-manager/_single/field_edit", 1);
        // line 2
        echo "
<div class=\"content\">
    <div class=\"main\">
        <div class=\"elements\">
            <form>
                <input type=\"hidden\" name=\"redirect\" value=\"field-manager\">
                
                ";
        // line 9
        if ((isset($context["field"]) || array_key_exists("field", $context))) {
            // line 10
            echo "                    <input type=\"hidden\" name=\"fieldId\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 10, $this->source); })()), "id", array()), "html", null, true);
            echo "\">
                ";
        }
        // line 12
        echo "                
                ";
        // line 13
        echo $context["forms"]->macro_selectField(array("first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which group should this field be displayed in?", "app"), "id" => "group", "name" => "group", "options" =>         // line 19
(isset($context["groupOptions"]) || array_key_exists("groupOptions", $context) ? $context["groupOptions"] : (function () { throw new Twig_Error_Runtime('Variable "groupOptions" does not exist.', 19, $this->source); })()), "value" =>         // line 20
(isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new Twig_Error_Runtime('Variable "groupId" does not exist.', 20, $this->source); })())));
        // line 21
        echo "

                ";
        // line 23
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this field will be called in the CP.", "app"), "id" => "name", "name" => "name", "value" => (( !twig_test_empty(        // line 28
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 28, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 28, $this->source); })()), "name", array())) : (null)), "errors" => (( !twig_test_empty(        // line 29
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 29, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 29, $this->source); })()), "getErrors", array(0 => "name"), "method")) : (null)), "required" => true, "translatable" => true, "autofocus" => true));
        // line 33
        echo "

                ";
        // line 35
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this field in the templates.", "app"), "id" => "handle", "class" => "code", "name" => "handle", "maxlength" => 64, "value" => (( !twig_test_empty(        // line 42
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 42, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 42, $this->source); })()), "handle", array())) : (null)), "errors" => (( !twig_test_empty(        // line 43
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 43, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 43, $this->source); })()), "getErrors", array(0 => "handle"), "method")) : (null)), "required" => true));
        // line 45
        echo "

                ";
        // line 47
        echo $context["forms"]->macro_textareaField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Helper text to guide the author.", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => (( !twig_test_empty(        // line 53
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 53, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 53, $this->source); })()), "instructions", array())) : (null)), "errors" => (( !twig_test_empty(        // line 54
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 54, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 54, $this->source); })()), "getErrors", array(0 => "instructions"), "method")) : (null)), "translatable" => true));
        // line 56
        echo "

                ";
        // line 58
        echo $context["forms"]->macro_selectField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of field is this?", "app"), "warning" => ((( !twig_test_empty(        // line 61
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new Twig_Error_Runtime('Variable "fieldId" does not exist.', 61, $this->source); })())) &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 61, $this->source); })()), "hasErrors", array(0 => "type"), "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" =>         // line 64
(isset($context["fieldTypeOptions"]) || array_key_exists("fieldTypeOptions", $context) ? $context["fieldTypeOptions"] : (function () { throw new Twig_Error_Runtime('Variable "fieldTypeOptions" does not exist.', 64, $this->source); })()), "value" => get_class(        // line 65
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 65, $this->source); })())), "errors" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 66
($context["field"] ?? null), "getErrors", array(0 => "type"), "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["field"] ?? null), "getErrors", array(0 => "type"), "method")))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["field"] ?? null), "getErrors", array(0 => "type"), "method")) : (null)), "toggle" => true));
        // line 68
        echo "

                ";
        // line 70
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 70, $this->source); })()), "app", array()), "getIsMultiSite", array(), "method")) {
            // line 71
            echo "                    ";
            $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 71, $this->source); })()), "supportedTranslationMethods", array());
            // line 72
            echo "                    ";
            if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 72, $this->source); })())) > 1)) {
                // line 73
                echo "                        <div id=\"translation-settings\">
                            ";
                // line 74
                echo $context["forms"]->macro_selectField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should this field’s values be translated?", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => array_filter(array(0 => ((twig_in_filter("none",                 // line 80
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 80, $this->source); })()))) ? (array("value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app"))) : ("")), 1 => ((twig_in_filter("language",                 // line 81
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 81, $this->source); })()))) ? (array("value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app"))) : ("")), 2 => ((twig_in_filter("site",                 // line 82
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 82, $this->source); })()))) ? (array("value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app"))) : ("")), 3 => ((twig_in_filter("custom",                 // line 83
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 83, $this->source); })()))) ? (array("value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app"))) : ("")))), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 85
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 85, $this->source); })()), "translationMethod", array()), "toggle" => true, "targetPrefix" => "translation-method-"));
                // line 88
                echo "

                            ";
                // line 90
                if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 90, $this->source); })()))) {
                    // line 91
                    echo "                                <div id=\"translation-method-custom\" ";
                    if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 91, $this->source); })()), "translationMethod", array()) != "custom")) {
                        echo "class=\"hidden\"";
                    }
                    echo ">
                                    ";
                    // line 92
                    echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "instructions" => "Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.", "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 97
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 97, $this->source); })()), "translationKeyFormat", array()), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 98
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 98, $this->source); })()), "getErrors", array(0 => "translationKeyFormat"), "method")));
                    // line 99
                    echo "
                                </div>
                            ";
                }
                // line 102
                echo "                        </div>
                    ";
            }
            // line 104
            echo "                ";
        }
        // line 105
        echo "
                <hr>

                ";
        // line 108
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allowedFieldTypes"]) || array_key_exists("allowedFieldTypes", $context) ? $context["allowedFieldTypes"] : (function () { throw new Twig_Error_Runtime('Variable "allowedFieldTypes" does not exist.', 108, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 109
            echo "                    ";
            $context["isCurrent"] = ($context["type"] == get_class((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 109, $this->source); })())));
            // line 110
            echo "                    <div id=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('id')->getCallable(), array($context["type"])), "html", null, true);
            echo "\"";
            if ( !(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new Twig_Error_Runtime('Variable "isCurrent" does not exist.', 110, $this->source); })())) {
                echo " class=\"hidden\"";
            }
            echo ">
                        ";
            // line 111
            $_namespace = (("types[" . $context["type"]) . "]");
            if ($_namespace) {
                $_originalNamespace = Craft::$app->getView()->getNamespace();
                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                ob_start();
                try {
                    // line 112
                    echo "                            ";
                    $context["_field"] = (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new Twig_Error_Runtime('Variable "isCurrent" does not exist.', 112, $this->source); })())) ? ((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 112, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 112, $this->source); })()), "app", array()), "fields", array()), "createField", array(0 => $context["type"]), "method")));
                    // line 113
                    echo "                            ";
                    echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["_field"]) || array_key_exists("_field", $context) ? $context["_field"] : (function () { throw new Twig_Error_Runtime('Variable "_field" does not exist.', 113, $this->source); })()), "getSettingsHtml", array(), "method");
                    echo "
                        ";
                } catch (Exception $e) {
                    ob_end_clean();

                    throw $e;
                }
                echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                Craft::$app->getView()->setNamespace($_originalNamespace);
            } else {
                // line 112
                echo "                            ";
                $context["_field"] = (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new Twig_Error_Runtime('Variable "isCurrent" does not exist.', 112, $this->source); })())) ? ((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 112, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 112, $this->source); })()), "app", array()), "fields", array()), "createField", array(0 => $context["type"]), "method")));
                // line 113
                echo "                            ";
                echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["_field"]) || array_key_exists("_field", $context) ? $context["_field"] : (function () { throw new Twig_Error_Runtime('Variable "_field" does not exist.', 113, $this->source); })()), "getSettingsHtml", array(), "method");
                echo "
                        ";
            }
            unset($_originalNamespace, $_namespace);
            // line 115
            echo "                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 117
        echo "            </form>
        </div>

        <div class=\"centeralign\">
            <div class=\"spinner loadingmore hidden\"></div>
        </div>
    </div>
</div>

";
        // line 126
        if (( !(isset($context["field"]) || array_key_exists("field", $context)) ||  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 126, $this->source); })()), "handle", array()))) {
            // line 127
            echo "    ";
            ob_start();
            // line 128
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 131
        echo "
";
        // line 132
        ob_start();
        // line 133
        echo "    Craft.supportedTranslationMethods = ";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["supportedTranslationMethods"]) || array_key_exists("supportedTranslationMethods", $context) ? $context["supportedTranslationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "supportedTranslationMethods" does not exist.', 133, $this->source); })()));
        echo ";

    Craft.updateTranslationMethodSettings = function(type, container) {
        var \$container = \$(container);
        if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
            \$container.addClass('hidden');
        } else {
            \$container.removeClass('hidden');
            // Rebuild the options based on the field type's supported translation methods
            \$container.find('select').html(
                (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">";
        // line 143
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">";
        // line 144
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">";
        // line 145
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">";
        // line 146
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app"), "js"), "html", null, true);
        echo "</option>' : '')
            );
        }
    }

    var \$fieldTypeInput = \$(\"#";
        // line 151
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), array("type")), "js"), "html", null, true);
        echo "\"),
        \$translationSettings = \$(\"#";
        // line 152
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), array("translation-settings")), "js"), "html", null, true);
        echo "\");

    \$fieldTypeInput.change(function(e) {
        Craft.updateTranslationMethodSettings(\$(this).val(), \$translationSettings);
    });
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
    }

    public function getTemplateName()
    {
        return "field-manager/_single/field_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  259 => 152,  255 => 151,  247 => 146,  243 => 145,  239 => 144,  235 => 143,  221 => 133,  219 => 132,  216 => 131,  211 => 128,  208 => 127,  206 => 126,  195 => 117,  188 => 115,  181 => 113,  178 => 112,  165 => 113,  162 => 112,  155 => 111,  146 => 110,  143 => 109,  139 => 108,  134 => 105,  131 => 104,  127 => 102,  122 => 99,  120 => 98,  119 => 97,  118 => 92,  111 => 91,  109 => 90,  105 => 88,  103 => 85,  102 => 83,  101 => 82,  100 => 81,  99 => 80,  98 => 74,  95 => 73,  92 => 72,  89 => 71,  87 => 70,  83 => 68,  81 => 66,  80 => 65,  79 => 64,  78 => 61,  77 => 58,  73 => 56,  71 => 54,  70 => 53,  69 => 47,  65 => 45,  63 => 43,  62 => 42,  61 => 35,  57 => 33,  55 => 29,  54 => 28,  53 => 23,  49 => 21,  47 => 20,  46 => 19,  45 => 13,  42 => 12,  36 => 10,  34 => 9,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

<div class=\"content\">
    <div class=\"main\">
        <div class=\"elements\">
            <form>
                <input type=\"hidden\" name=\"redirect\" value=\"field-manager\">
                
                {% if field is defined %}
                    <input type=\"hidden\" name=\"fieldId\" value=\"{{ field.id }}\">
                {% endif %}
                
                {{ forms.selectField({
                    first: true,
                    label: \"Group\"|t('app'),
                    instructions: \"Which group should this field be displayed in?\"|t('app'),
                    id: 'group',
                    name: 'group',
                    options: groupOptions,
                    value: groupId
                }) }}

                {{ forms.textField({
                    label: \"Name\"|t('app'),
                    instructions: \"What this field will be called in the CP.\"|t('app'),
                    id: 'name',
                    name: 'name',
                    value: (field is not empty ? field.name : null),
                    errors: (field is not empty ? field.getErrors('name') : null),
                    required: true,
                    translatable: true,
                    autofocus: true
                }) }}

                {{ forms.textField({
                    label: \"Handle\"|t('app'),
                    instructions: \"How you’ll refer to this field in the templates.\"|t('app'),
                    id: 'handle',
                    class: 'code',
                    name: 'handle',
                    maxlength: 64,
                    value: (field is not empty ? field.handle : null),
                    errors: (field is not empty ? field.getErrors('handle') : null),
                    required: true,
                }) }}

                {{ forms.textareaField({
                    label: \"Instructions\"|t('app'),
                    instructions: \"Helper text to guide the author.\"|t('app'),
                    id: 'instructions',
                    class: 'nicetext',
                    name: 'instructions',
                    value: (field is not empty ? field.instructions : null),
                    errors: (field is not empty ? field.getErrors('instructions') : null),
                    translatable: true
                }) }}

                {{ forms.selectField({
                    label: \"Field Type\"|t('app'),
                    instructions: \"What type of field is this?\"|t('app'),
                    warning: (fieldId is not empty and not field.hasErrors('type') ? \"Changing this may result in data loss.\"|t('app')),
                    id: 'type',
                    name: 'type',
                    options: fieldTypeOptions,
                    value: className(field),
                    errors: field.getErrors('type') ?? null,
                    toggle: true
                }) }}

                {% if craft.app.getIsMultiSite() %}
                    {% set translationMethods = field.supportedTranslationMethods %}
                    {% if translationMethods|length > 1 %}
                        <div id=\"translation-settings\">
                            {{ forms.selectField({
                                label: \"Translation Method\"|t('app'),
                                instructions: \"How should this field’s values be translated?\"|t('app'),
                                id: 'translation-method',
                                name: 'translationMethod',
                                options: [
                                    'none' in translationMethods ? { value: 'none', label: \"Not translatable\"|t('app') },
                                    'language' in translationMethods ? { value: 'language', label: \"Translate for each language\"|t('app') },
                                    'site' in translationMethods ? { value: 'site', label: \"Translate for each site\"|t('app') },
                                    'custom' in translationMethods ? { value: 'custom', label: \"Custom…\"|t('app') }
                                ]|filter,
                                value: field.translationMethod,
                                toggle: true,
                                targetPrefix: 'translation-method-'
                            }) }}

                            {% if 'custom' in translationMethods %}
                                <div id=\"translation-method-custom\" {% if field.translationMethod != 'custom' %}class=\"hidden\"{% endif %}>
                                    {{ forms.textField({
                                        label: \"Translation Key Format\"|t('app'),
                                        instructions: \"Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.\",
                                        id: 'translation-key-format',
                                        name: 'translationKeyFormat',
                                        value: field.translationKeyFormat,
                                        errors: field.getErrors('translationKeyFormat')
                                    }) }}
                                </div>
                            {% endif %}
                        </div>
                    {% endif %}
                {% endif %}

                <hr>

                {% for type in allowedFieldTypes %}
                    {% set isCurrent = (type == className(field)) %}
                    <div id=\"{{ type|id }}\"{% if not isCurrent %} class=\"hidden\"{% endif %}>
                        {% namespace 'types['~type~']' %}
                            {% set _field = isCurrent ? field : craft.app.fields.createField(type) %}
                            {{ _field.getSettingsHtml()|raw }}
                        {% endnamespace %}
                    </div>
                {% endfor %}
            </form>
        </div>

        <div class=\"centeralign\">
            <div class=\"spinner loadingmore hidden\"></div>
        </div>
    </div>
</div>

{% if field is not defined or not field.handle %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}

{% js %}
    Craft.supportedTranslationMethods = {{ supportedTranslationMethods|json_encode|raw }};

    Craft.updateTranslationMethodSettings = function(type, container) {
        var \$container = \$(container);
        if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
            \$container.addClass('hidden');
        } else {
            \$container.removeClass('hidden');
            // Rebuild the options based on the field type's supported translation methods
            \$container.find('select').html(
                (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">{{ \"Not translatable\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">{{ \"Translate for each language\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">{{ \"Translate for each site\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">{{ \"Custom…\"|t('app')|e('js') }}</option>' : '')
            );
        }
    }

    var \$fieldTypeInput = \$(\"#{{ 'type'|namespaceInputId|e('js') }}\"),
        \$translationSettings = \$(\"#{{ 'translation-settings'|namespaceInputId|e('js') }}\");

    \$fieldTypeInput.change(function(e) {
        Craft.updateTranslationMethodSettings(\$(this).val(), \$translationSettings);
    });
{% endjs %}", "field-manager/_single/field_edit", "/app/vendor/verbb/field-manager/src/templates/_single/field_edit.html");
    }
}

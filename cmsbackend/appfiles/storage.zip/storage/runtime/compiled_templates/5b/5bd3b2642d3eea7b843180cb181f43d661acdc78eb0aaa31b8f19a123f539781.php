<?php

/* super-table/matrix/input */
class __TwigTemplate_ed82c7a992f1b5e26358aadd4080106bb2318d94da3df399f457b5aa88701247 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 1, $this->source); })()), "html", null, true);
        echo "\" class=\"superTableContainer matrixLayout\">
    <div class=\"matrixLayoutContainer\">
        ";
        // line 3
        $context["totalNewBlocks"] = 0;
        // line 4
        echo "
        ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new Twig_Error_Runtime('Variable "blocks" does not exist.', 5, $this->source); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
            // line 6
            echo "            ";
            $context["blockId"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "id", array());
            // line 7
            echo "
            ";
            // line 8
            if ( !(isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 8, $this->source); })())) {
                // line 9
                echo "                ";
                $context["totalNewBlocks"] = ((isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 9, $this->source); })()) + 1);
                // line 10
                echo "                ";
                $context["blockId"] = ("new" . (isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 10, $this->source); })()));
                // line 11
                echo "            ";
            }
            // line 12
            echo "
            <div class=\"superTableMatrix matrixblock\" data-id=\"";
            // line 13
            echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 13, $this->source); })()), "html", null, true);
            echo "\"";
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "collapsed", array())) {
                echo " data-collapsed";
            }
            echo ">
                <input type=\"hidden\" name=\"";
            // line 14
            echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 14, $this->source); })()), "html", null, true);
            echo "[";
            echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 14, $this->source); })()), "html", null, true);
            echo "][type]\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "getType", array(), "method"), "html", null, true);
            echo "\">

                ";
            // line 16
            if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 16, $this->source); })())) {
                // line 17
                echo "                    <div class=\"titlebar\">
                        <div class=\"blocktype\"></div>
                        <div class=\"preview\"></div>
                    </div>

                    <div class=\"actions\">
                        <a class=\"settings icon menubtn\" title=\"";
                // line 23
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "html", null, true);
                echo "\" role=\"button\"></a>

                        <div class=\"menu\">
                            <ul class=\"padded\">
                                <li><a data-icon=\"collapse\" data-action=\"collapse\">";
                // line 27
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Collapse", "app"), "html", null, true);
                echo "</a></li>
                                <li class=\"hidden\"><a data-icon=\"expand\" data-action=\"expand\">";
                // line 28
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Expand", "app"), "html", null, true);
                echo "</a></li>
                            </ul>

                            ";
                // line 31
                if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 31, $this->source); })())) {
                    // line 32
                    echo "                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    <li><a class=\"error\" data-icon=\"remove\" data-action=\"delete\">";
                    // line 34
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "</a></li>
                                </ul>
                            ";
                }
                // line 37
                echo "                        </div>

                        <a class=\"move icon\" title=\"";
                // line 39
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" role=\"button\"></a>
                    </div>
                ";
            }
            // line 42
            echo "
                <div class=\"fields\">
                    ";
            // line 44
            $this->loadTemplate("_includes/fields", "super-table/matrix/input", 44)->display(array_merge($context, array("namespace" => (((            // line 45
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 45, $this->source); })()) . "[") . (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 45, $this->source); })())) . "][fields]"), "element" =>             // line 46
$context["block"], "fields" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 47
$context["block"], "getType", array(), "method"), "getFieldLayout", array(), "method"), "getFields", array(), "method"), "settings" =>             // line 48
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 48, $this->source); })()))));
            // line 50
            echo "                </div>
            </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "    </div>

    ";
        // line 55
        if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 55, $this->source); })())) {
            // line 56
            echo "        <div class=\"superTableAddRow btn add icon\">
            ";
            // line 57
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "selectionLabel", array(), "any", true, true)) ? (_twig_default_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "selectionLabel", array()), "Add a row")) : ("Add a row")), "site"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 60
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "super-table/matrix/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 60,  172 => 57,  169 => 56,  167 => 55,  163 => 53,  147 => 50,  145 => 48,  144 => 47,  143 => 46,  142 => 45,  141 => 44,  137 => 42,  131 => 39,  127 => 37,  121 => 34,  117 => 32,  115 => 31,  109 => 28,  105 => 27,  98 => 23,  90 => 17,  88 => 16,  79 => 14,  71 => 13,  68 => 12,  65 => 11,  62 => 10,  59 => 9,  57 => 8,  54 => 7,  51 => 6,  34 => 5,  31 => 4,  29 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"{{ id }}\" class=\"superTableContainer matrixLayout\">
    <div class=\"matrixLayoutContainer\">
        {% set totalNewBlocks = 0 %}

        {% for block in blocks %}
            {% set blockId = block.id %}

            {% if not blockId %}
                {% set totalNewBlocks = totalNewBlocks + 1 %}
                {% set blockId = 'new' ~ totalNewBlocks %}
            {% endif %}

            <div class=\"superTableMatrix matrixblock\" data-id=\"{{ blockId }}\"{% if block.collapsed %} data-collapsed{% endif %}>
                <input type=\"hidden\" name=\"{{ name }}[{{ blockId }}][type]\" value=\"{{ block.getType() }}\">

                {% if not staticBlocks %}
                    <div class=\"titlebar\">
                        <div class=\"blocktype\"></div>
                        <div class=\"preview\"></div>
                    </div>

                    <div class=\"actions\">
                        <a class=\"settings icon menubtn\" title=\"{{ 'Actions'|t('app') }}\" role=\"button\"></a>

                        <div class=\"menu\">
                            <ul class=\"padded\">
                                <li><a data-icon=\"collapse\" data-action=\"collapse\">{{ \"Collapse\"|t('app') }}</a></li>
                                <li class=\"hidden\"><a data-icon=\"expand\" data-action=\"expand\">{{ \"Expand\"|t('app') }}</a></li>
                            </ul>

                            {% if not staticBlocks %}
                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    <li><a class=\"error\" data-icon=\"remove\" data-action=\"delete\">{{ \"Delete\"|t('app') }}</a></li>
                                </ul>
                            {% endif %}
                        </div>

                        <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a>
                    </div>
                {% endif %}

                <div class=\"fields\">
                    {% include \"_includes/fields\" with {
                        namespace: name ~ '[' ~ blockId ~ '][fields]',
                        element: block,
                        fields: block.getType().getFieldLayout().getFields(),
                        settings: supertableField,
                    } %}
                </div>
            </div>
        {% endfor %}
    </div>

    {% if not staticBlocks %}
        <div class=\"superTableAddRow btn add icon\">
            {{ supertableField.selectionLabel | default(\"Add a row\") | t('site') }}
        </div>
    {% endif %}
</div>
", "super-table/matrix/input", "/app/vendor/verbb/super-table/src/templates/matrix/input.html");
    }
}

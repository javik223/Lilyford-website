<?php

/* ./partials/_seo.twig */
class __TwigTemplate_94886e1ed7d0be35b6fc33f0e2b283a32be147a827a23168ffc29a28a491c8df extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "./partials/_seo.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "./partials/_seo.twig", "/app/templates/partials/_seo.twig");
    }
}

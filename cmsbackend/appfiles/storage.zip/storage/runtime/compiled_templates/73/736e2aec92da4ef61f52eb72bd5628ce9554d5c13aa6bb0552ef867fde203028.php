<?php

/* __string_template__3c6d7e4775309ac5f91fb14ba43f5d70c73164e24ecb5a7a1885cfc5ac1f3f10 */
class __TwigTemplate_1629cfe34f54fd1adb8d16f417640fc0a6bc538b658ca158d706b0bb4ecf4317 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "entries/takeAction/new?parentId=";
        echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "parent", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "parent", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "parent", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "parent", array()))), "id", array());
        echo "#";
    }

    public function getTemplateName()
    {
        return "__string_template__3c6d7e4775309ac5f91fb14ba43f5d70c73164e24ecb5a7a1885cfc5ac1f3f10";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("entries/takeAction/new?parentId={{ (_variables.parent ?? object.parent).id|raw }}#", "__string_template__3c6d7e4775309ac5f91fb14ba43f5d70c73164e24ecb5a7a1885cfc5ac1f3f10", "");
    }
}

<?php

/* _elements/thumbsview/container */
class __TwigTemplate_01621cceef9bff1f589358836a5ca4c75b3be8c1209c9dc29bb06efed40814d5 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<ul class=\"thumbsview\">
    ";
        // line 2
        $this->loadTemplate("_elements/thumbsview/elements", "_elements/thumbsview/container", 2)->display($context);
        // line 3
        echo "</ul>
<div class=\"clear\"></div>
";
    }

    public function getTemplateName()
    {
        return "_elements/thumbsview/container";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ul class=\"thumbsview\">
    {% include \"_elements/thumbsview/elements\" %}
</ul>
<div class=\"clear\"></div>
", "_elements/thumbsview/container", "/app/vendor/craftcms/cms/src/templates/_elements/thumbsview/container.html");
    }
}

<?php

/* __string_template__5ebf899ef1d3c2568a43ca775b14250c38ec9d90b454c584ff09f35a0112eec7 */
class __TwigTemplate_88e2a4057c578e6e1af55d9ecbc2f1a8c1a70b61cd12059324c041e8fdd895e6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "entries/ourProgrammes/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "id", array())));
        echo "-";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "slug", array())));
    }

    public function getTemplateName()
    {
        return "__string_template__5ebf899ef1d3c2568a43ca775b14250c38ec9d90b454c584ff09f35a0112eec7";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("entries/ourProgrammes/{{ (_variables.id ?? object.id)|raw }}-{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__5ebf899ef1d3c2568a43ca775b14250c38ec9d90b454c584ff09f35a0112eec7", "");
    }
}

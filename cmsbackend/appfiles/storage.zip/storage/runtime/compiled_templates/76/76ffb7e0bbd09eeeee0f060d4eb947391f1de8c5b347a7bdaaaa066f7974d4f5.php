<?php

/* _elements/thumbsview/elements */
class __TwigTemplate_25c6b9e013a361574df4d399bc69d07a71e72436a7be8c405df3a9223cdf8d46 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        ob_start();
        // line 2
        echo "
";
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new Twig_Error_Runtime('Variable "elements" does not exist.', 3, $this->source); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 4
            echo "    <li data-id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["element"], "id", array()), "html", null, true);
            echo "\" class=\"";
            if (twig_in_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["element"], "id", array()), (isset($context["disabledElementIds"]) || array_key_exists("disabledElementIds", $context) ? $context["disabledElementIds"] : (function () { throw new Twig_Error_Runtime('Variable "disabledElementIds" does not exist.', 4, $this->source); })()))) {
                echo "disabled";
            }
            echo " ";
            if ((isset($context["showCheckboxes"]) || array_key_exists("showCheckboxes", $context) ? $context["showCheckboxes"] : (function () { throw new Twig_Error_Runtime('Variable "showCheckboxes" does not exist.', 4, $this->source); })())) {
                echo "has-checkbox";
            }
            echo "\">
        ";
            // line 5
            $this->loadTemplate("_elements/element", "_elements/thumbsview/elements", 5)->display($context);
            // line 6
            echo "        ";
            if ((isset($context["showCheckboxes"]) || array_key_exists("showCheckboxes", $context) ? $context["showCheckboxes"] : (function () { throw new Twig_Error_Runtime('Variable "showCheckboxes" does not exist.', 6, $this->source); })())) {
                echo "<div class=\"checkbox\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Select", "app"), "html", null, true);
                echo "\"></div>";
            }
            // line 7
            echo "    </li>
";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    public function getTemplateName()
    {
        return "_elements/thumbsview/elements";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 9,  67 => 7,  60 => 6,  58 => 5,  45 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% spaceless %}

{% for element in elements %}
    <li data-id=\"{{ element.id }}\" class=\"{% if element.id in disabledElementIds %}disabled{% endif %} {% if showCheckboxes %}has-checkbox{% endif %}\">
        {% include \"_elements/element\" %}
        {% if showCheckboxes %}<div class=\"checkbox\" title=\"{{ 'Select'|t('app') }}\"></div>{% endif %}
    </li>
{% endfor %}

{% endspaceless -%}
", "_elements/thumbsview/elements", "/app/vendor/craftcms/cms/src/templates/_elements/thumbsview/elements.html");
    }
}

<?php

/* macros/page-builder */
class __TwigTemplate_4dc47747e0b8af741e60e3510dd2888bbf3d7d7fb391e2e76f575d4136fa31e3 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 4
        echo "
";
        // line 43
        echo "
";
        // line 85
        echo "
";
    }

    // line 1
    public function macro_text($__item__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "item" => $__item__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "    <div class=\"grid-x margin-bottom-2 small-11 small-centered medium-10 large-8\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 2, $this->source); })()), "text", array()), "html", null, true);
            echo "</div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 5
    public function macro_carousel($__items__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "items" => $__items__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 6
            echo "    ";
            $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "macros/page-builder", 6);
            // line 7
            echo "    <div class=\"grid-container\">
        <div class=\"grid-x padding-bottom-2\">
            <div class=\"gallery\">
                ";
            // line 10
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 10, $this->source); })()), "title", array())) {
                // line 11
                echo "                    <h3 class=\"gallery__title\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 11, $this->source); })()), "title", array()), "html", null, true);
                echo "</h3>
                ";
            }
            // line 13
            echo "
                <div class=\"gallery__main js-gallery-main\">
                    ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 15, $this->source); })()), "images", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["carouselImage"]) {
                // line 16
                echo "                        <div>

                            ";
                // line 18
                echo $context["imageHelper"]->macro_srcset($context["carouselImage"], craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "title", array()));
                echo "
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['carouselImage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 21
            echo "                </div>
                <div class=\"gallery__thumbs js-gallery-thumb\">
                    ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 23, $this->source); })()), "images", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["carouselImage"]) {
                // line 24
                echo "                        <div>
                            ";
                // line 25
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "title", array()), 300, 200);
                echo "
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['carouselImage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 28
            echo "                </div>

                <div class=\"gallery__navigation medium-6 medium-centered text-center\">
                    <span class=\"prev\">
                        <div class=\"icon icon-arrow-left\"></div>
                    </span>
                    <span>&nbsp;</span>
                    <span class=\"next\">
                        <div class=\"icon icon-arrow-right\"></div>
                    </span>
                </div>
            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 44
    public function macro_stripCarousel($__images__ = null, $__index__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "images" => $__images__,
            "index" => $__index__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 45
            echo "    ";
            $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "macros/page-builder", 45);
            // line 46
            echo "    <div class=\"grid-container\">
        <div class=\"grid-x\">
            <div class=\"js-slick cell\" data-slick='{\"slidesToShow\": 1, \"centerMode\": true, \"centerPadding\": \"60px\", \"prevArrow\": \".strip-carousel-";
            // line 48
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 48, $this->source); })()), "html", null, true);
            echo "-prev\", \"nextArrow\": \".strip-carousel-";
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 48, $this->source); })()), "html", null, true);
            echo "-next\", \"responsive\": [
      {
        \"breakpoint\": 480,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 2,
          \"centerPadding\": \"10px\"
        }
      },
      {
        \"breakpoint\": 800,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 1,
          \"centerPadding\": \"20px\"
        }
      },
    ]}'>
                ";
            // line 68
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["images"]) || array_key_exists("images", $context) ? $context["images"] : (function () { throw new Twig_Error_Runtime('Variable "images" does not exist.', 68, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 69
                echo "                    <div class=\"cell\">";
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "title", array()), 1000);
                echo "</div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 71
            echo "            </div>
            <div class=\"text-center cell strip-carousel-";
            // line 72
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 72, $this->source); })()), "html", null, true);
            echo "\">
                <span class=\"prev strip-carousel-";
            // line 73
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 73, $this->source); })()), "html", null, true);
            echo "-prev\">
                    <div class=\"icon icon-arrow-left\"></div>
                </span>

                <span class=\"next strip-carousel-";
            // line 77
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 77, $this->source); })()), "html", null, true);
            echo "-next\">
                    <div class=\"icon icon-arrow-right\"></div>
                </span>

            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 86
    public function macro_video($__video__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "video" => $__video__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 87
            echo "    <div class=\"grid-container full bg-very-light-gray\">
        <div class=\"grid-container padding-3\">
            <div class=\"cell medium-10 medium-centered\">
                <div class=\"video\">
                    ";
            // line 91
            $context["embeddedAsset"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 91, $this->source); })()), "embeddedAssets", array()), "get", array(0 => (isset($context["video"]) || array_key_exists("video", $context) ? $context["video"] : (function () { throw new Twig_Error_Runtime('Variable "video" does not exist.', 91, $this->source); })()), 1 => array("width" => 200)), "method");
            // line 92
            echo "                    ";
            echo twig_escape_filter($this->env, (((isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 92, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 92, $this->source); })()), "html", array())) : ("")), "html", null, true);
            echo "
                </div>
            </div>
        </div>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "macros/page-builder";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  259 => 92,  257 => 91,  251 => 87,  239 => 86,  222 => 77,  215 => 73,  211 => 72,  208 => 71,  199 => 69,  195 => 68,  170 => 48,  166 => 46,  163 => 45,  150 => 44,  127 => 28,  118 => 25,  115 => 24,  111 => 23,  107 => 21,  98 => 18,  94 => 16,  90 => 15,  86 => 13,  80 => 11,  78 => 10,  73 => 7,  70 => 6,  58 => 5,  46 => 2,  34 => 1,  29 => 85,  26 => 43,  23 => 4,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro text(item) %}
    <div class=\"grid-x margin-bottom-2 small-11 small-centered medium-10 large-8\">{{ item.text }}</div>
{% endmacro %}

{% macro carousel(items) %}
    {% import 'macros/image-helper' as imageHelper %}
    <div class=\"grid-container\">
        <div class=\"grid-x padding-bottom-2\">
            <div class=\"gallery\">
                {% if items.title %}
                    <h3 class=\"gallery__title\">{{ items.title }}</h3>
                {% endif %}

                <div class=\"gallery__main js-gallery-main\">
                    {% for carouselImage in items.images.all() %}
                        <div>

                            {{ imageHelper.srcset(carouselImage, carouselImage.title) }}
                        </div>
                    {% endfor %}
                </div>
                <div class=\"gallery__thumbs js-gallery-thumb\">
                    {% for carouselImage in items.images.all() %}
                        <div>
                            {{ imageHelper.transform(carouselImage.url, carouselImage.title, 300, 200) }}
                        </div>
                    {% endfor %}
                </div>

                <div class=\"gallery__navigation medium-6 medium-centered text-center\">
                    <span class=\"prev\">
                        <div class=\"icon icon-arrow-left\"></div>
                    </span>
                    <span>&nbsp;</span>
                    <span class=\"next\">
                        <div class=\"icon icon-arrow-right\"></div>
                    </span>
                </div>
            </div>
        </div>
    </div>
{% endmacro %}

{% macro stripCarousel(images, index) %}
    {% import 'macros/image-helper' as imageHelper %}
    <div class=\"grid-container\">
        <div class=\"grid-x\">
            <div class=\"js-slick cell\" data-slick='{\"slidesToShow\": 1, \"centerMode\": true, \"centerPadding\": \"60px\", \"prevArrow\": \".strip-carousel-{{ index }}-prev\", \"nextArrow\": \".strip-carousel-{{ index }}-next\", \"responsive\": [
      {
        \"breakpoint\": 480,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 2,
          \"centerPadding\": \"10px\"
        }
      },
      {
        \"breakpoint\": 800,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 1,
          \"centerPadding\": \"20px\"
        }
      },
    ]}'>
                {% for image in images %}
                    <div class=\"cell\">{{ imageHelper.transform(image.url, image.title, 1000) }}</div>
                {% endfor %}
            </div>
            <div class=\"text-center cell strip-carousel-{{ index }}\">
                <span class=\"prev strip-carousel-{{ index }}-prev\">
                    <div class=\"icon icon-arrow-left\"></div>
                </span>

                <span class=\"next strip-carousel-{{ index }}-next\">
                    <div class=\"icon icon-arrow-right\"></div>
                </span>

            </div>
        </div>
    </div>
{% endmacro %}

{% macro video(video) %}
    <div class=\"grid-container full bg-very-light-gray\">
        <div class=\"grid-container padding-3\">
            <div class=\"cell medium-10 medium-centered\">
                <div class=\"video\">
                    {% set embeddedAsset = craft.embeddedAssets.get(video, {width: 200}) %}
                    {{ embeddedAsset ? embeddedAsset.html }}
                </div>
            </div>
        </div>
    </div>
{% endmacro %}", "macros/page-builder", "/app/templates/macros/page-builder.twig");
    }
}

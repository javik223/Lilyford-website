<?php

/* settings/plugins/_settings */
class __TwigTemplate_9441100161e521b80e24935a487bd6dc5784857d0c8931e97a52a8e4ced2e9b9 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 11
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/plugins/_settings", 11);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 3
        $context["crumbs"] = array(0 => array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")), 1 => array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Plugins", "app"), "url" => craft\helpers\UrlHelper::url("settings/plugins")));
        // line 8
        $context["fullPageForm"] = true;
        // line 12
        $context["title"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["plugin"]) || array_key_exists("plugin", $context) ? $context["plugin"] : (function () { throw new Twig_Error_Runtime('Variable "plugin" does not exist.', 12, $this->source); })()), "name", array());
        // line 13
        $context["docTitle"] = (((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 13, $this->source); })()) . " - ") . $this->extensions['craft\web\twig\Extension']->translateFilter("Plugins", "app"));
        // line 11
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 16
    public function block_content($context, array $blocks = array())
    {
        // line 17
        echo "    <input type=\"hidden\" name=\"action\" value=\"plugins/save-plugin-settings\">
    <input type=\"hidden\" name=\"pluginHandle\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["plugin"]) || array_key_exists("plugin", $context) ? $context["plugin"] : (function () { throw new Twig_Error_Runtime('Variable "plugin" does not exist.', 18, $this->source); })()), "handle", array()), "html", null, true);
        echo "\">
    ";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->redirectInputFunction("settings"), "html", null, true);
        echo "

    ";
        // line 21
        $_namespace = "settings";
        if ($_namespace) {
            $_originalNamespace = Craft::$app->getView()->getNamespace();
            Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
            ob_start();
            try {
                // line 22
                echo "        ";
                echo (isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new Twig_Error_Runtime('Variable "settingsHtml" does not exist.', 22, $this->source); })());
                echo "
    ";
            } catch (Exception $e) {
                ob_end_clean();

                throw $e;
            }
            echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
            Craft::$app->getView()->setNamespace($_originalNamespace);
        } else {
            echo "        ";
            echo (isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new Twig_Error_Runtime('Variable "settingsHtml" does not exist.', 22, $this->source); })());
            echo "
    ";
        }
        unset($_originalNamespace, $_namespace);
    }

    public function getTemplateName()
    {
        return "settings/plugins/_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 22,  58 => 21,  53 => 19,  49 => 18,  46 => 17,  43 => 16,  39 => 11,  37 => 13,  35 => 12,  33 => 8,  31 => 3,  29 => 1,  15 => 11,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% requireAdmin %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') },
    { label: \"Plugins\"|t('app'), url: url('settings/plugins') }
] %}

{% set fullPageForm = true %}


{% extends \"_layouts/cp\" %}
{% set title = plugin.name %}
{% set docTitle = title ~ ' - ' ~ \"Plugins\"|t('app') %}


{% block content %}
    <input type=\"hidden\" name=\"action\" value=\"plugins/save-plugin-settings\">
    <input type=\"hidden\" name=\"pluginHandle\" value=\"{{ plugin.handle }}\">
    {{ redirectInput('settings') }}

    {% namespace 'settings' %}
        {{ settingsHtml|raw }}
    {% endnamespace %}
{% endblock %}
", "settings/plugins/_settings", "/app/vendor/craftcms/cms/src/templates/settings/plugins/_settings.html");
    }
}

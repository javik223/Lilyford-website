<?php

/* __string_template__5ff2f2fc6026a12c25f1c0101db3c933ba1383f6ff5e7af318e20372fc9094e8 */
class __TwigTemplate_f448039f8b99804a28d12f423acdd9fdf321eb0f6de8b1be82fd3d93a47420cf extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "media/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "slug", array())));
    }

    public function getTemplateName()
    {
        return "__string_template__5ff2f2fc6026a12c25f1c0101db3c933ba1383f6ff5e7af318e20372fc9094e8";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("media/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__5ff2f2fc6026a12c25f1c0101db3c933ba1383f6ff5e7af318e20372fc9094e8", "");
    }
}

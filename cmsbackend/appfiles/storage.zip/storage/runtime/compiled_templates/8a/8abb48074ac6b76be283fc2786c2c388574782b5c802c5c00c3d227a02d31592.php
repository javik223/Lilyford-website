<?php

/*  */
class __TwigTemplate_b2725d4189b4d3fe4e0331faf492262d71d5ba15efa229a53efe1adcc316a293 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        \Craft::$app->getResponse()->redirect(craft\helpers\UrlHelper::url(((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 1, $this->source); })()), "app", array()), "config", array()), "general", array()), "postCpLoginRedirect", array())) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 1, $this->source); })()), "app", array()), "config", array()), "general", array()), "postCpLoginRedirect", array())) : ("dashboard"))), 302);
        \Craft::$app->end();    }

    public function getTemplateName()
    {
        return "";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% redirect craft.app.config.general.postCpLoginRedirect ?: 'dashboard' %}
", "", "/app/vendor/craftcms/cms/src/templates/index.html");
    }
}

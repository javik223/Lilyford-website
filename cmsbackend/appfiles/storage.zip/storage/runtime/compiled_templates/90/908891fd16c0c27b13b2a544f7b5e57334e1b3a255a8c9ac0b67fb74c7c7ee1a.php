<?php

/* our-programmes */
class __TwigTemplate_b372f9da38019b246783d9d6e9527bcbf455bb1fcef9f0f69a23eadfcec0e7f6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "our-programmes", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_main($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">Programmes</h2>
    </div>

    <div class=\"grid-container\">
        <div class=\"featured-programmes\">
            ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 9, $this->source); })()), "entries", array()), "section", array(0 => "ourProgrammes"), "method"), "all", array(), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["programme"]) {
            // line 13
            echo "                <a class=\"featured-programme bg-";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "color", array()), "html", null, true);
            echo "\" href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "url", array()), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "title", array()), "html", null, true);
            echo "\">
                    <div class=\"featured-programme__content\">
                        <img src=\"";
            // line 15
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "inverseIcon", array()), "one", array(), "method"), "url", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "title", array()), "html", null, true);
            echo "\">
                        <p class=\"featured-programme__title margin-bottom-0\">
                            ";
            // line 17
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "title", array()), "html", null, true);
            echo "
                        </p>
                    </div>
                </a>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['programme'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "our-programmes";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 22,  64 => 17,  57 => 15,  47 => 13,  43 => 9,  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% block main %}
    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">Programmes</h2>
    </div>

    <div class=\"grid-container\">
        <div class=\"featured-programmes\">
            {% for programme in craft
                .entries
                .section('ourProgrammes')
                .all() %}
                <a class=\"featured-programme bg-{{ programme.color }}\" href=\"{{ programme.url }}\" title=\"{{ programme.title }}\">
                    <div class=\"featured-programme__content\">
                        <img src=\"{{ programme.inverseIcon.one().url }}\" alt=\"{{ programme.title }}\">
                        <p class=\"featured-programme__title margin-bottom-0\">
                            {{ programme.title }}
                        </p>
                    </div>
                </a>
            {% endfor %}
        </div>
    </div>
{% endblock %}", "our-programmes", "/app/templates/our-programmes/index.twig");
    }
}

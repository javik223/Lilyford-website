<?php

/* super-table/table/input */
class __TwigTemplate_2ee6dd687d215aac432100381751a34f929a06d08af16dc7552f6a81b3bb740b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"superTableContainer columnLayout\">
    <div class=\"superTableColumn\">
        <table id=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "\" class=\"superTable-table superTable-layout-table\">
            <thead>
                <tr>
                    <th class=\"hidden\"></th>

                    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypes" does not exist.', 8, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["blockType"]) {
            // line 9
            echo "                        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["blockType"], "getFieldLayout", array(), "method"), "getFields", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 10
                echo "                            ";
                $context["width"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "columns", array(), "any", false, true), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "id", array()), array(), "array", false, true), "width", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "columns", array(), "any", false, true), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "id", array()), array(), "array", false, true), "width", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "columns", array(), "any", false, true), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "id", array()), array(), "array", false, true), "width", array())) : (""));
                // line 11
                echo "
                            ";
                // line 12
                $context["translatable"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getIsTranslatable", array(), "method");
                // line 13
                echo "
                            ";
                // line 14
                if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new Twig_Error_Runtime('Variable "translatable" does not exist.', 14, $this->source); })())) {
                    // line 15
                    echo "                                ";
                    switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "translationMethod", array())) {
                        case "site":
                        {
                            // line 17
                            echo "                                    ";
                            $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site.", "app");
                            // line 18
                            echo "                                ";
                            break;
                        }
                        case "siteGroup":
                        {
                            // line 19
                            echo "                                    ";
                            $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site group.", "app");
                            // line 20
                            echo "                                ";
                            break;
                        }
                        case "language":
                        {
                            // line 21
                            echo "                                    ";
                            $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each language.", "app");
                            // line 22
                            echo "                                ";
                            break;
                        }
                    }
                    // line 23
                    echo "                            ";
                }
                // line 24
                echo "
                            <th scope=\"col\" class=\"col-header\" ";
                // line 25
                if ((isset($context["width"]) || array_key_exists("width", $context) ? $context["width"] : (function () { throw new Twig_Error_Runtime('Variable "width" does not exist.', 25, $this->source); })())) {
                    echo "style=\"width: ";
                    echo twig_escape_filter($this->env, (isset($context["width"]) || array_key_exists("width", $context) ? $context["width"] : (function () { throw new Twig_Error_Runtime('Variable "width" does not exist.', 25, $this->source); })()), "html", null, true);
                    echo "\"";
                }
                echo ">
                                <span class=\"heading-text ";
                // line 26
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "required", array())) {
                    echo "required";
                }
                echo "\">
                                    ";
                // line 27
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", array()), "site"), "html", null, true);
                echo " ";
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", array())) {
                    echo "<span class=\"info\">";
                    echo call_user_func_array($this->env->getFilter('md')->getCallable(), array($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", array()), "site")));
                    echo "</span>";
                }
                echo " ";
                if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new Twig_Error_Runtime('Variable "translatable" does not exist.', 27, $this->source); })())) {
                    echo "<span class=\"extralight\" data-icon=\"language\" title=\"";
                    echo twig_escape_filter($this->env, (($context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app"))), "html", null, true);
                    echo "\"></span>";
                }
                // line 28
                echo "                                </span>
                            </th>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            echo "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "
                    ";
        // line 33
        if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 33, $this->source); })())) {
            // line 34
            echo "                        <th class=\"col-header\" colspan=\"2\"></th>
                    ";
        }
        // line 36
        echo "                </tr>
            </thead>
            <tbody>
                ";
        // line 39
        $context["totalNewBlocks"] = 0;
        // line 40
        echo "                
                ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new Twig_Error_Runtime('Variable "blocks" does not exist.', 41, $this->source); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
            // line 42
            echo "                    ";
            $context["blockId"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "id", array());
            // line 43
            echo "
                    ";
            // line 44
            if ( !(isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 44, $this->source); })())) {
                // line 45
                echo "                        ";
                $context["totalNewBlocks"] = ((isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 45, $this->source); })()) + 1);
                // line 46
                echo "                        ";
                $context["blockId"] = ("new" . (isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 46, $this->source); })()));
                // line 47
                echo "                    ";
            }
            // line 48
            echo "
                    <tr data-id=\"";
            // line 49
            echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 49, $this->source); })()), "html", null, true);
            echo "\">
                        <td class=\"hidden\">
                            <input type=\"hidden\" name=\"";
            // line 51
            echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 51, $this->source); })()), "html", null, true);
            echo "[";
            echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 51, $this->source); })()), "html", null, true);
            echo "][type]\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "getType", array(), "method"), "html", null, true);
            echo "\">
                        </td>
                        
                        ";
            // line 54
            $this->loadTemplate("super-table/table/fields", "super-table/table/input", 54)->display(array_merge($context, array("namespace" => (((            // line 55
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 55, $this->source); })()) . "[") . (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 55, $this->source); })())) . "][fields]"), "element" =>             // line 56
$context["block"], "fields" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 57
$context["block"], "getType", array(), "method"), "getFieldLayout", array(), "method"), "getFields", array(), "method"), "settings" =>             // line 58
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 58, $this->source); })()))));
            // line 60
            echo "
                        ";
            // line 61
            if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 61, $this->source); })())) {
                // line 62
                echo "                            <td class=\"thin action super-table-action\">
                                <a class=\"move icon\" title=\"";
                // line 63
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "site"), "html", null, true);
                echo "\"></a>
                            </td>

                            <td class=\"thin action super-table-action\">
                                <a class=\"delete icon\" title=\"";
                // line 67
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "site"), "html", null, true);
                echo "\"></a>
                            </td>
                        ";
            } else {
                // line 70
                echo "                            ";
                // line 71
                echo "                            <td class=\"hidden\"></td>
                        ";
            }
            // line 73
            echo "                    </tr>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "            </tbody>
        </table>

        ";
        // line 78
        if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 78, $this->source); })())) {
            // line 79
            echo "            <div class=\"btn add icon\">
                ";
            // line 80
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "selectionLabel", array(), "any", true, true)) ? (_twig_default_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "selectionLabel", array()), "Add a row")) : ("Add a row")), "site"), "html", null, true);
            echo "
            </div>
        ";
        }
        // line 83
        echo "    </div>
</div>


";
    }

    public function getTemplateName()
    {
        return "super-table/table/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  271 => 83,  265 => 80,  262 => 79,  260 => 78,  255 => 75,  240 => 73,  236 => 71,  234 => 70,  228 => 67,  221 => 63,  218 => 62,  216 => 61,  213 => 60,  211 => 58,  210 => 57,  209 => 56,  208 => 55,  207 => 54,  197 => 51,  192 => 49,  189 => 48,  186 => 47,  183 => 46,  180 => 45,  178 => 44,  175 => 43,  172 => 42,  155 => 41,  152 => 40,  150 => 39,  145 => 36,  141 => 34,  139 => 33,  136 => 32,  130 => 31,  122 => 28,  108 => 27,  102 => 26,  94 => 25,  91 => 24,  88 => 23,  83 => 22,  80 => 21,  74 => 20,  71 => 19,  65 => 18,  62 => 17,  57 => 15,  55 => 14,  52 => 13,  50 => 12,  47 => 11,  44 => 10,  39 => 9,  35 => 8,  27 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"superTableContainer columnLayout\">
    <div class=\"superTableColumn\">
        <table id=\"{{ id }}\" class=\"superTable-table superTable-layout-table\">
            <thead>
                <tr>
                    <th class=\"hidden\"></th>

                    {% for blockType in blockTypes %}
                        {% for field in blockType.getFieldLayout().getFields() %}
                            {% set width = supertableField.columns[field.id].width ?? '' %}

                            {% set translatable = field.getIsTranslatable() %}

                            {% if translatable %}
                                {% switch field.translationMethod %}
                                {% case 'site' %}
                                    {% set translationDescription = 'This field is translated for each site.'|t('app') %}
                                {% case 'siteGroup' %}
                                    {% set translationDescription = 'This field is translated for each site group.'|t('app') %}
                                {% case 'language' %}
                                    {% set translationDescription = 'This field is translated for each language.'|t('app') %}
                                {% endswitch %}
                            {% endif %}

                            <th scope=\"col\" class=\"col-header\" {% if width %}style=\"width: {{ width }}\"{% endif %}>
                                <span class=\"heading-text {% if field.required %}required{% endif %}\">
                                    {{ field.name | t('site') }} {% if field.instructions %}<span class=\"info\">{{ field.instructions | t('site') | md | raw }}</span>{% endif %} {% if translatable %}<span class=\"extralight\" data-icon=\"language\" title=\"{{ translationDescription ?? 'This field is translatable.' | t('app') }}\"></span>{% endif %}
                                </span>
                            </th>
                        {% endfor %}
                    {% endfor %}

                    {% if not staticBlocks %}
                        <th class=\"col-header\" colspan=\"2\"></th>
                    {% endif %}
                </tr>
            </thead>
            <tbody>
                {% set totalNewBlocks = 0 %}
                
                {% for block in blocks %}
                    {% set blockId = block.id %}

                    {% if not blockId %}
                        {% set totalNewBlocks = totalNewBlocks + 1 %}
                        {% set blockId = 'new' ~ totalNewBlocks %}
                    {% endif %}

                    <tr data-id=\"{{ blockId }}\">
                        <td class=\"hidden\">
                            <input type=\"hidden\" name=\"{{ name }}[{{ blockId }}][type]\" value=\"{{ block.getType() }}\">
                        </td>
                        
                        {% include \"super-table/table/fields\" with {
                            namespace: name ~ '[' ~ blockId ~ '][fields]',
                            element: block,
                            fields: block.getType().getFieldLayout().getFields(),
                            settings: supertableField,
                        } %}

                        {% if not staticBlocks %}
                            <td class=\"thin action super-table-action\">
                                <a class=\"move icon\" title=\"{{ 'Reorder' | t('site') }}\"></a>
                            </td>

                            <td class=\"thin action super-table-action\">
                                <a class=\"delete icon\" title=\"{{ 'Delete' | t('site') }}\"></a>
                            </td>
                        {% else %}
                            {# Prevents case where inner Table fields will collapse everything #}
                            <td class=\"hidden\"></td>
                        {% endif %}
                    </tr>
                {% endfor %}
            </tbody>
        </table>

        {% if not staticBlocks %}
            <div class=\"btn add icon\">
                {{ supertableField.selectionLabel | default(\"Add a row\") | t('site') }}
            </div>
        {% endif %}
    </div>
</div>


", "super-table/table/input", "/app/vendor/verbb/super-table/src/templates/table/input.html");
    }
}

<?php

/* __string_template__8c644392014625cbc59b29d7da5fadfc6cdb5c9f890ea1584875f70de91d16c1 */
class __TwigTemplate_c39f8d1adf312c63cf53b4627d28b14521fbac76cce2aebfc0913a827d004bd0 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "take-action/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "slug", array())));
    }

    public function getTemplateName()
    {
        return "__string_template__8c644392014625cbc59b29d7da5fadfc6cdb5c9f890ea1584875f70de91d16c1";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("take-action/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__8c644392014625cbc59b29d7da5fadfc6cdb5c9f890ea1584875f70de91d16c1", "");
    }
}

<?php

/* macros/with-page-builder */
class __TwigTemplate_4dfbe370b6c5ecf81cfffa468a08245ee5eba0542664ea6ff43fad7fb98e31be extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    // line 1
    public function macro_withPageBuilder($__pageBuilderBlock__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "pageBuilderBlock" => $__pageBuilderBlock__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "    ";
            $context["pageBuilder"] = $this->loadTemplate("macros/page-builder", "macros/with-page-builder", 2);
            // line 3
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["pageBuilderBlock"]) || array_key_exists("pageBuilderBlock", $context) ? $context["pageBuilderBlock"] : (function () { throw new Twig_Error_Runtime('Variable "pageBuilderBlock" does not exist.', 3, $this->source); })()));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 4
                echo "        ";
                switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "type", array())) {
                    case "text":
                    {
                        // line 7
                        echo "            ";
                        echo $context["pageBuilder"]->macro_text($context["item"]);
                        echo "

            ";
                        break;
                    }
                    case "carousel":
                    {
                        // line 10
                        echo "                ";
                        echo $context["pageBuilder"]->macro_carousel($context["item"]);
                        echo "

                ";
                        break;
                    }
                    case "stripCarousel":
                    {
                        // line 13
                        echo "                    ";
                        echo $context["pageBuilder"]->macro_stripCarousel(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "images", array()), "all", array(), "method"), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index", array()));
                        echo "

                    ";
                        break;
                    }
                    case "video":
                    {
                        // line 16
                        echo "                        ";
                        echo $context["pageBuilder"]->macro_video(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "video", array()), "one", array(), "method"));
                        echo "

                        ";
                        break;
                    }
                    case "iconBlocks":
                    {
                        // line 19
                        echo "                            ";
                        echo $context["pageBuilder"]->macro_iconBlocks($context["item"]);
                        echo "

                            ";
                        break;
                    }
                    case "logoBlocks":
                    {
                        // line 22
                        echo "                                ";
                        echo $context["pageBuilder"]->macro_logoBlocks(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "logoBlocks", array()), "all", array(), "method"));
                        echo "

                                ";
                        break;
                    }
                    default:
                    {
                        // line 25
                        echo "
                                ";
                    }
                }
                // line 27
                echo "
                            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "                        ";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "macros/with-page-builder";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 29,  128 => 27,  123 => 25,  113 => 22,  103 => 19,  93 => 16,  83 => 13,  73 => 10,  63 => 7,  58 => 4,  40 => 3,  37 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro withPageBuilder(pageBuilderBlock) %}
    {% import 'macros/page-builder' as pageBuilder %}
    {% for item in pageBuilderBlock %}
        {% switch item.type %}

        {% case \"text\" %}
            {{ pageBuilder.text(item) }}

            {% case \"carousel\" %}
                {{ pageBuilder.carousel(item) }}

                {% case \"stripCarousel\" %}
                    {{ pageBuilder.stripCarousel(item.images.all(), loop.index) }}

                    {% case \"video\" %}
                        {{ pageBuilder.video(item.video.one()) }}

                        {% case \"iconBlocks\" %}
                            {{ pageBuilder.iconBlocks(item) }}

                            {% case \"logoBlocks\" %}
                                {{ pageBuilder.logoBlocks(item.logoBlocks.all()) }}

                                {% default %}

                                {% endswitch %}

                            {% endfor %}
                        {% endmacro %}", "macros/with-page-builder", "/app/templates/macros/with-page-builder.twig");
    }
}

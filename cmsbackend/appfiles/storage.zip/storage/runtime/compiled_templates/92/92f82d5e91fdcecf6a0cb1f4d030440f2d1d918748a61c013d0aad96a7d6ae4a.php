<?php

/* __string_template__f1461ab9111cb25555241a0e9f03b48231f460290125a052de69e6d616fdb192 */
class __TwigTemplate_2938adbcf3b2b3ae2276547d5641eafc56c2311c51467552ee69df6775fe98fe extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "our-programmes/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "slug", array())));
    }

    public function getTemplateName()
    {
        return "__string_template__f1461ab9111cb25555241a0e9f03b48231f460290125a052de69e6d616fdb192";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("our-programmes/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__f1461ab9111cb25555241a0e9f03b48231f460290125a052de69e6d616fdb192", "");
    }
}

<?php

/* _elements/element */
class __TwigTemplate_068727c8b04062182ef5259f1ae1c5cbe78e69f0bf0354bc26e3c10cd9c20258 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo \Craft::$app->getView()->invokeHook("cp.elements.element", $context);

    }

    public function getTemplateName()
    {
        return "_elements/element";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% hook \"cp.elements.element\" %}
", "_elements/element", "/app/vendor/craftcms/cms/src/templates/_elements/element.html");
    }
}

<?php

/* settings/plugins */
class __TwigTemplate_297e70b58180e0d8c3341bfa250e5ccae78dfd8bb19daffec637c4eeaa3ccce5 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/plugins", 3);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 4
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Plugins", "app");
        // line 5
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", array(0 => "craft\\web\\assets\\plugins\\PluginsAsset"), "method");
        // line 7
        $context["crumbs"] = array(0 => array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")));
        // line 12
        $context["info"] = $this->extensions['craft\web\twig\Extension']->multisortFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 12, $this->source); })()), "app", array()), "plugins", array()), "getAllPluginInfo", array(), "method"), array(0 => "isEnabled", 1 => "isInstalled", 2 => "hasIssues", 3 => "name"), array(0 =>         // line 14
(isset($context["SORT_DESC"]) || array_key_exists("SORT_DESC", $context) ? $context["SORT_DESC"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_DESC" does not exist.', 14, $this->source); })()), 1 => (isset($context["SORT_DESC"]) || array_key_exists("SORT_DESC", $context) ? $context["SORT_DESC"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_DESC" does not exist.', 14, $this->source); })()), 2 => (isset($context["SORT_DESC"]) || array_key_exists("SORT_DESC", $context) ? $context["SORT_DESC"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_DESC" does not exist.', 14, $this->source); })()), 3 => (isset($context["SORT_ASC"]) || array_key_exists("SORT_ASC", $context) ? $context["SORT_ASC"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_ASC" does not exist.', 14, $this->source); })())), array(0 =>         // line 15
(isset($context["SORT_NUMERIC"]) || array_key_exists("SORT_NUMERIC", $context) ? $context["SORT_NUMERIC"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_NUMERIC" does not exist.', 15, $this->source); })()), 1 => (isset($context["SORT_NUMERIC"]) || array_key_exists("SORT_NUMERIC", $context) ? $context["SORT_NUMERIC"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_NUMERIC" does not exist.', 15, $this->source); })()), 2 => (isset($context["SORT_NUMERIC"]) || array_key_exists("SORT_NUMERIC", $context) ? $context["SORT_NUMERIC"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_NUMERIC" does not exist.', 15, $this->source); })()), 3 => (isset($context["SORT_NATURAL"]) || array_key_exists("SORT_NATURAL", $context) ? $context["SORT_NATURAL"] : (function () { throw new Twig_Error_Runtime('Variable "SORT_NATURAL" does not exist.', 15, $this->source); })())));
        // line 114
        ob_start();
        // line 115
        echo "new Craft.PluginManager();
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 3
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 19
    public function block_content($context, array $blocks = array())
    {
        // line 20
        echo "    ";
        if (twig_length_filter($this->env, (isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new Twig_Error_Runtime('Variable "info" does not exist.', 20, $this->source); })()))) {
            // line 21
            echo "        <table id=\"plugins\" class=\"data fullwidth collapsible\">
            <tbody>
                ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new Twig_Error_Runtime('Variable "info" does not exist.', 23, $this->source); })()));
            foreach ($context['_seq'] as $context["handle"] => $context["config"]) {
                // line 24
                echo "                    <tr id=\"plugin-";
                echo twig_escape_filter($this->env, $context["handle"], "html", null, true);
                echo "\" data-name=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "name", array()), "html", null, true);
                echo "\" data-handle=\"";
                echo twig_escape_filter($this->env, $context["handle"], "html", null, true);
                echo "\">
                        <th>
                            <div class=\"plugin-infos\">
                                <div class=\"icon\">
                                    ";
                // line 28
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 28, $this->source); })()), "app", array()), "plugins", array()), "getPluginIconSvg", array(0 => $context["handle"]), "method")), "html", null, true);
                echo "
                                    ";
                // line 29
                if (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseKeyStatus", array()) == "valid") || craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "hasIssues", array()))) {
                    // line 30
                    echo "                                        <span class=\"license-key-status ";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseKeyStatus", array()), "html", null, true);
                    echo "\"></span>
                                    ";
                }
                // line 32
                echo "                                </div>
                                <div class=\"details\">
                                    <h2>
                                        ";
                // line 35
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "name", array()), "html", null, true);
                echo "
                                        <span class=\"light\">";
                // line 36
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "version", array()), "html", null, true);
                echo "</span>
                                    </h2>
                                    ";
                // line 38
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "description", array())) {
                    // line 39
                    echo "                                        <p>";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "description", array()), "html", null, true);
                    echo "</p>
                                    ";
                }
                // line 41
                echo "                                    ";
                if ((((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "developerUrl", array()) || craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "developer", array())) || craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "hasCpSettings", array())) || craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "documentationUrl", array()))) {
                    // line 42
                    echo "                                        <p class=\"links\">";
                    // line 43
                    ob_start();
                    // line 44
                    echo "                                            ";
                    // line 45
                    echo "                                                ";
                    // line 46
                    echo "                                            ";
                    // line 47
                    echo "                                                ";
                    // line 48
                    echo "                                            ";
                    // line 49
                    echo "                                            ";
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "documentationUrl", array())) {
                        // line 50
                        echo "                                                <a href=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "documentationUrl", array()), "html", null, true);
                        echo "\" rel=\"noopener\" target=\"_blank\">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Documentation", "app"), "html", null, true);
                        echo "</a>
                                            ";
                    }
                    // line 52
                    echo "                                            ";
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "hasCpSettings", array())) {
                        // line 53
                        echo "                                                <a href=\"";
                        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("settings/plugins/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "moduleId", array()))), "html", null, true);
                        echo "\"><span data-icon=\"settings\"></span>";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "html", null, true);
                        echo "</a>
                                            ";
                    }
                    // line 55
                    echo "                                            ";
                    echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
                    // line 56
                    echo "</p>
                                    ";
                }
                // line 58
                echo "                                    ";
                $context["showLicenseKey"] = (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseKey", array()) || (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseKeyStatus", array()) != "unknown"));
                // line 59
                echo "                                    <div class=\"flex license-key";
                if ( !(isset($context["showLicenseKey"]) || array_key_exists("showLicenseKey", $context) ? $context["showLicenseKey"] : (function () { throw new Twig_Error_Runtime('Variable "showLicenseKey" does not exist.', 59, $this->source); })())) {
                    echo " hidden";
                }
                echo "\">
                                        <div class=\"pane\">
                                            <input class=\"text code";
                // line 61
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "hasIssues", array())) {
                    echo " error";
                }
                echo "\" size=\"29\" maxlength=\"29\" value=\"";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('trim')->getCallable(), array($this->extensions['craft\web\twig\Extension']->replaceFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseKey", array()), "/.{4}/", "\$0-"), "-")), "html", null, true);
                echo "\" placeholder=\"XXXX-XXXX-XXXX-XXXX-XXXX-XXXX\" readonly>
                                        </div>
                                        <a class=\"btn";
                // line 63
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "hasIssues", array())) {
                    echo " submit";
                }
                if ( !((isset($context["showLicenseKey"]) || array_key_exists("showLicenseKey", $context) ? $context["showLicenseKey"] : (function () { throw new Twig_Error_Runtime('Variable "showLicenseKey" does not exist.', 63, $this->source); })()) &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseKey", array()))) {
                    echo " hidden";
                }
                echo "\" href=\"";
                echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("plugin-store/buy/" . $context["handle"])), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Buy now", "app"), "html", null, true);
                echo "</a>
                                        <div class=\"spinner hidden\"></div>
                                    </div>
                                    ";
                // line 66
                if (((isset($context["showLicenseKey"]) || array_key_exists("showLicenseKey", $context) ? $context["showLicenseKey"] : (function () { throw new Twig_Error_Runtime('Variable "showLicenseKey" does not exist.', 66, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseStatusMessage", array()))) {
                    // line 67
                    echo "                                        <p class=\"error\">";
                    echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "licenseStatusMessage", array());
                    echo "</p>
                                    ";
                }
                // line 69
                echo "                                </div>
                            </div>
                        </th>
                        <td class=\"nowrap\" data-title=\"";
                // line 72
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "html", null, true);
                echo "\">
                            ";
                // line 73
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "isEnabled", array())) {
                    // line 74
                    echo "                                <span class=\"status on\"></span>";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Installed", "app"), "html", null, true);
                    echo "
                            ";
                } elseif (craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 75
$context["config"], "isInstalled", array())) {
                    // line 76
                    echo "                                <span class=\"status off\"></span>";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Disabled", "app"), "html", null, true);
                    echo "
                            ";
                } else {
                    // line 78
                    echo "                                <span class=\"status\"></span><span class=\"light\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Not installed", "app"), "html", null, true);
                    echo "</span>
                            ";
                }
                // line 80
                echo "                        </td>
                        <td class=\"nowrap thin\" data-title=\"";
                // line 81
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Action", "app"), "html", null, true);
                echo "\">
                            <form method=\"post\" accept-charset=\"UTF-8\">
                                <input type=\"hidden\" name=\"pluginHandle\" value=\"";
                // line 83
                echo twig_escape_filter($this->env, $context["handle"], "html", null, true);
                echo "\">
                                ";
                // line 84
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
                echo "
                                <div class=\"btngroup\">
                                    <div class=\"btn menubtn\" data-icon=\"settings\"></div>
                                    <div class=\"menu\" data-align=\"right\">
                                        <ul>
                                            ";
                // line 89
                if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "isInstalled", array())) {
                    // line 90
                    echo "                                                <li><a class=\"formsubmit\" data-action=\"plugins/install-plugin\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Install", "app"), "html", null, true);
                    echo "</a></li>
                                                <li><a class=\"formsubmit error\" data-action=\"pluginstore/remove\" data-param=\"packageName\" data-value=\"";
                    // line 91
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "packageName", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Remove", "app"), "html", null, true);
                    echo "</a></li>
                                            ";
                } else {
                    // line 93
                    echo "                                                ";
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "isEnabled", array())) {
                        // line 94
                        echo "                                                    <li><a class=\"formsubmit\" data-action=\"plugins/disable-plugin\">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Disable", "app"), "html", null, true);
                        echo "</a></li>
                                                    <li><a class=\"formsubmit error\" data-action=\"plugins/uninstall-plugin\" data-confirm=\"";
                        // line 95
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to uninstall {plugin}? You will lose all of its associated data.", "app", array("plugin" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["config"], "name", array()))), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Uninstall", "app"), "html", null, true);
                        echo "</a></li>
                                                ";
                    } else {
                        // line 97
                        echo "                                                    <li><a class=\"formsubmit\" data-action=\"plugins/enable-plugin\">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Enable", "app"), "html", null, true);
                        echo "</a></li>
                                                ";
                    }
                    // line 99
                    echo "                                            ";
                }
                // line 100
                echo "                                        </ul>
                                    </div>
                                </div>
                            </form>
                        </td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['handle'], $context['config'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 107
            echo "            </tbody>
        </table>
    ";
        } else {
            // line 110
            echo "        <p id=\"no-plugins\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("There are no available plugins.", "app"), "html", null, true);
            echo "
    ";
        }
    }

    public function getTemplateName()
    {
        return "settings/plugins";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  305 => 110,  300 => 107,  288 => 100,  285 => 99,  279 => 97,  272 => 95,  267 => 94,  264 => 93,  257 => 91,  252 => 90,  250 => 89,  242 => 84,  238 => 83,  233 => 81,  230 => 80,  224 => 78,  218 => 76,  216 => 75,  211 => 74,  209 => 73,  205 => 72,  200 => 69,  194 => 67,  192 => 66,  177 => 63,  168 => 61,  160 => 59,  157 => 58,  153 => 56,  150 => 55,  142 => 53,  139 => 52,  131 => 50,  128 => 49,  126 => 48,  124 => 47,  122 => 46,  120 => 45,  118 => 44,  116 => 43,  114 => 42,  111 => 41,  105 => 39,  103 => 38,  98 => 36,  94 => 35,  89 => 32,  83 => 30,  81 => 29,  77 => 28,  65 => 24,  61 => 23,  57 => 21,  54 => 20,  51 => 19,  47 => 3,  43 => 115,  41 => 114,  39 => 15,  38 => 14,  37 => 12,  35 => 7,  33 => 5,  31 => 4,  29 => 1,  15 => 3,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% requireAdmin %}

{% extends \"_layouts/cp\" %}
{% set title = \"Plugins\"|t('app') %}
{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\plugins\\\\PluginsAsset\") %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}


{% set info = craft.app.plugins.getAllPluginInfo()|multisort(
    ['isEnabled', 'isInstalled', 'hasIssues', 'name'],
    [SORT_DESC, SORT_DESC, SORT_DESC, SORT_ASC],
    [SORT_NUMERIC, SORT_NUMERIC, SORT_NUMERIC, SORT_NATURAL]
) %}


{% block content %}
    {% if info|length %}
        <table id=\"plugins\" class=\"data fullwidth collapsible\">
            <tbody>
                {% for handle, config in info %}
                    <tr id=\"plugin-{{ handle }}\" data-name=\"{{ config.name }}\" data-handle=\"{{ handle }}\">
                        <th>
                            <div class=\"plugin-infos\">
                                <div class=\"icon\">
                                    {{ svg(craft.app.plugins.getPluginIconSvg(handle)) }}
                                    {% if config.licenseKeyStatus == 'valid' or config.hasIssues %}
                                        <span class=\"license-key-status {{ config.licenseKeyStatus }}\"></span>
                                    {% endif %}
                                </div>
                                <div class=\"details\">
                                    <h2>
                                        {{ config.name }}
                                        <span class=\"light\">{{ config.version }}</span>
                                    </h2>
                                    {% if config.description %}
                                        <p>{{ config.description }}</p>
                                    {% endif %}
                                    {% if config.developerUrl or config.developer or config.hasCpSettings or config.documentationUrl %}
                                        <p class=\"links\">
                                            {%- spaceless %}
                                            {#{% if config.developerUrl %}#}
                                                {#<a href=\"{{ config.developerUrl }}\" rel=\"noopener\" target=\"_blank\">{{ config.developer ?: config.developerUrl }}</a>#}
                                            {#{% elseif config.developer %}#}
                                                {#{{ config.developer }}#}
                                            {#{% endif %}#}
                                            {% if config.documentationUrl %}
                                                <a href=\"{{ config.documentationUrl }}\" rel=\"noopener\" target=\"_blank\">{{ \"Documentation\"|t('app') }}</a>
                                            {% endif %}
                                            {% if config.hasCpSettings %}
                                                <a href=\"{{ url('settings/plugins/'~config.moduleId) }}\"><span data-icon=\"settings\"></span>{{ \"Settings\"|t('app') }}</a>
                                            {% endif %}
                                            {% endspaceless -%}
                                        </p>
                                    {% endif %}
                                    {% set showLicenseKey = config.licenseKey or config.licenseKeyStatus != 'unknown' %}
                                    <div class=\"flex license-key{% if not showLicenseKey %} hidden{% endif %}\">
                                        <div class=\"pane\">
                                            <input class=\"text code{% if config.hasIssues %} error{% endif %}\" size=\"29\" maxlength=\"29\" value=\"{{ config.licenseKey|replace('/.{4}/', '\$0-')|trim('-') }}\" placeholder=\"XXXX-XXXX-XXXX-XXXX-XXXX-XXXX\" readonly>
                                        </div>
                                        <a class=\"btn{% if config.hasIssues %} submit{% endif %}{% if not (showLicenseKey and not config.licenseKey) %} hidden{% endif %}\" href=\"{{ url('plugin-store/buy/'~handle)}}\">{{ \"Buy now\"|t('app') }}</a>
                                        <div class=\"spinner hidden\"></div>
                                    </div>
                                    {% if showLicenseKey and config.licenseStatusMessage %}
                                        <p class=\"error\">{{ config.licenseStatusMessage|raw }}</p>
                                    {% endif %}
                                </div>
                            </div>
                        </th>
                        <td class=\"nowrap\" data-title=\"{{ 'Status'|t('app') }}\">
                            {% if config.isEnabled %}
                                <span class=\"status on\"></span>{{ \"Installed\"|t('app') }}
                            {% elseif config.isInstalled %}
                                <span class=\"status off\"></span>{{ \"Disabled\"|t('app') }}
                            {% else %}
                                <span class=\"status\"></span><span class=\"light\">{{ \"Not installed\"|t('app') }}</span>
                            {% endif %}
                        </td>
                        <td class=\"nowrap thin\" data-title=\"{{ 'Action'|t('app') }}\">
                            <form method=\"post\" accept-charset=\"UTF-8\">
                                <input type=\"hidden\" name=\"pluginHandle\" value=\"{{ handle }}\">
                                {{ csrfInput() }}
                                <div class=\"btngroup\">
                                    <div class=\"btn menubtn\" data-icon=\"settings\"></div>
                                    <div class=\"menu\" data-align=\"right\">
                                        <ul>
                                            {% if not config.isInstalled %}
                                                <li><a class=\"formsubmit\" data-action=\"plugins/install-plugin\">{{ 'Install'|t('app') }}</a></li>
                                                <li><a class=\"formsubmit error\" data-action=\"pluginstore/remove\" data-param=\"packageName\" data-value=\"{{ config.packageName }}\">{{ 'Remove'|t('app') }}</a></li>
                                            {% else %}
                                                {% if config.isEnabled %}
                                                    <li><a class=\"formsubmit\" data-action=\"plugins/disable-plugin\">{{ 'Disable'|t('app') }}</a></li>
                                                    <li><a class=\"formsubmit error\" data-action=\"plugins/uninstall-plugin\" data-confirm=\"{{ 'Are you sure you want to uninstall {plugin}? You will lose all of its associated data.'|t('app', { plugin: config.name }) }}\">{{ 'Uninstall'|t('app') }}</a></li>
                                                {% else %}
                                                    <li><a class=\"formsubmit\" data-action=\"plugins/enable-plugin\">{{ 'Enable'|t('app') }}</a></li>
                                                {% endif %}
                                            {% endif %}
                                        </ul>
                                    </div>
                                </div>
                            </form>
                        </td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    {% else %}
        <p id=\"no-plugins\">{{ \"There are no available plugins.\"|t('app') }}
    {% endif %}
{% endblock %}

{% js %}
new Craft.PluginManager();
{% endjs %}
", "settings/plugins", "/app/vendor/craftcms/cms/src/templates/settings/plugins/index.html");
    }
}

<?php

/* wheelform/_index.twig */
class __TwigTemplate_bcb108d8f287168b586f0f896be2926244cbac255e11721f5efc5754011bd3aa extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "wheelform/_index.twig", 1);
        $this->blocks = array(
            'actionButton' => array($this, 'block_actionButton'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 3
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", array(0 => "wheelform\\assets\\WheelformCpAsset"), "method");
        // line 5
        $context["title"] = (((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 5, $this->source); })())) ? ((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 5, $this->source); })())) : ("Wheel Forms"));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_actionButton($context, array $blocks = array())
    {
        // line 8
        echo "    <div class=\"buttons\">
        <a class=\"btn submit icon\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("wheelform/form/new"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New Form", "wheelform"), "html", null, true);
        echo "</a>
    </div>
";
    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        // line 15
        echo "    <div class=\"tableview\">
        ";
        // line 16
        if ( !twig_test_empty((isset($context["wheelforms"]) || array_key_exists("wheelforms", $context) ? $context["wheelforms"] : (function () { throw new Twig_Error_Runtime('Variable "wheelforms" does not exist.', 16, $this->source); })()))) {
            // line 17
            echo "            <table class=\"data fullwidth\">
                <thead>
                    <tr>
                        <th scope=\"col\" class=\"thin\">
                            ";
            // line 21
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Form ID", "wheelform"), "html", null, true);
            echo "
                        </th>
                        <th class=\"thin\">
                            ";
            // line 24
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Active", "wheelform"), "html", null, true);
            echo "
                        </th>
                        <th scope=\"col\">
                            ";
            // line 27
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Form Name", "wheelform"), "html", null, true);
            echo "
                        </th>
                        <th scope=\"col\">
                            ";
            // line 30
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Entries", "wheelform"), "html", null, true);
            echo "
                        </th>
                        <th scope=\"col\" class=\"thin\">
                            ";
            // line 33
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New", "wheelform"), "html", null, true);
            echo "
                        </th>
                        ";
            // line 35
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new Twig_Error_Runtime('Variable "currentUser" does not exist.', 35, $this->source); })()), "admin", array())) {
                // line 36
                echo "                            <th scope=\"col\" class=\"thin\">
                                ";
                // line 37
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "wheelform"), "html", null, true);
                echo "
                            </th>
                        ";
            }
            // line 40
            echo "                    </tr>
                </thead>
                <tbody>
                    ";
            // line 43
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["wheelforms"]) || array_key_exists("wheelforms", $context) ? $context["wheelforms"] : (function () { throw new Twig_Error_Runtime('Variable "wheelforms" does not exist.', 43, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["form"]) {
                // line 44
                echo "                        <tr data-id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "id", array()), "html", null, true);
                echo "\" data-name=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "name", array())), "html", null, true);
                echo "\">
                            <td>";
                // line 45
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "id", array()), "html", null, true);
                echo "</td>
                            <td><span class=\"status ";
                // line 46
                echo ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "active", array())) ? ("active") : ("disabled"));
                echo "\"></span></td>
                            <td>";
                // line 47
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "name", array()), "html", null, true);
                echo "</td>
                            <td>
                            ";
                // line 49
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "entryCount", array()) > 0)) {
                    echo "<a href=\"";
                    echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url((("wheelform/form/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "id", array())) . "/entries")), "html", null, true);
                    echo "\">";
                }
                // line 50
                echo "                            ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "entryCount", array()), "html", null, true);
                echo "
                            ";
                // line 51
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "entryCount", array()) > 0)) {
                    echo "</a>";
                }
                // line 52
                echo "                            </td>
                            <td>
                            ";
                // line 54
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "hasNew", array(), "method")) {
                    // line 55
                    echo "                                <span class=\"new-badge\">!</span>
                            ";
                } else {
                    // line 57
                    echo "                                --
                            ";
                }
                // line 59
                echo "                            </td>
                            ";
                // line 60
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new Twig_Error_Runtime('Variable "currentUser" does not exist.', 60, $this->source); })()), "admin", array())) {
                    // line 61
                    echo "                                <td>
                                    <a href=\"";
                    // line 62
                    echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("wheelform/form/edit/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["form"], "id", array()))), "html", null, true);
                    echo "\" class=\"settings icon\" title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "wheelform"), "html", null, true);
                    echo "\"></a>
                                </td>
                            ";
                }
                // line 65
                echo "                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['form'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 67
            echo "                </tbody>
            </table>
        ";
        } else {
            // line 70
            echo "            <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No forms", "wheelform"), "html", null, true);
            echo "</p>
        ";
        }
        // line 72
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "wheelform/_index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  199 => 72,  193 => 70,  188 => 67,  181 => 65,  173 => 62,  170 => 61,  168 => 60,  165 => 59,  161 => 57,  157 => 55,  155 => 54,  151 => 52,  147 => 51,  142 => 50,  136 => 49,  131 => 47,  127 => 46,  123 => 45,  116 => 44,  112 => 43,  107 => 40,  101 => 37,  98 => 36,  96 => 35,  91 => 33,  85 => 30,  79 => 27,  73 => 24,  67 => 21,  61 => 17,  59 => 16,  56 => 15,  53 => 14,  44 => 9,  41 => 8,  38 => 7,  34 => 1,  32 => 5,  30 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"_layouts/cp\" %}

{% do view.registerAssetBundle(\"wheelform\\\\assets\\\\WheelformCpAsset\") %}

{% set title = title ? title : \"Wheel Forms\" %}

{% block actionButton %}
    <div class=\"buttons\">
        <a class=\"btn submit icon\" href=\"{{ url('wheelform/form/new') }}\">{{ 'New Form'|t('wheelform') }}</a>
    </div>
{% endblock %}


{% block content %}
    <div class=\"tableview\">
        {% if wheelforms is not empty %}
            <table class=\"data fullwidth\">
                <thead>
                    <tr>
                        <th scope=\"col\" class=\"thin\">
                            {{ 'Form ID' | t('wheelform') }}
                        </th>
                        <th class=\"thin\">
                            {{ 'Active' | t('wheelform') }}
                        </th>
                        <th scope=\"col\">
                            {{ 'Form Name' | t('wheelform') }}
                        </th>
                        <th scope=\"col\">
                            {{ 'Entries' | t('wheelform') }}
                        </th>
                        <th scope=\"col\" class=\"thin\">
                            {{ 'New' | t('wheelform') }}
                        </th>
                        {% if currentUser.admin %}
                            <th scope=\"col\" class=\"thin\">
                                {{ 'Settings' | t('wheelform') }}
                            </th>
                        {% endif %}
                    </tr>
                </thead>
                <tbody>
                    {% for form in wheelforms %}
                        <tr data-id=\"{{ form.id }}\" data-name=\"{{ form.name|t }}\">
                            <td>{{ form.id }}</td>
                            <td><span class=\"status {{ form.active ? 'active' : 'disabled' }}\"></span></td>
                            <td>{{ form.name }}</td>
                            <td>
                            {% if form.entryCount > 0 %}<a href=\"{{ url('wheelform/form/' ~ form.id ~ '/entries')}}\">{% endif %}
                            {{ form.entryCount }}
                            {% if form.entryCount > 0 %}</a>{% endif %}
                            </td>
                            <td>
                            {% if form.hasNew() %}
                                <span class=\"new-badge\">!</span>
                            {% else %}
                                --
                            {% endif %}
                            </td>
                            {% if currentUser.admin %}
                                <td>
                                    <a href=\"{{ url('wheelform/form/edit/'~ form.id) }}\" class=\"settings icon\" title=\"{{ 'Settings'|t('wheelform') }}\"></a>
                                </td>
                            {% endif %}
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
        {% else %}
            <p>{{ 'No forms' | t('wheelform') }}</p>
        {% endif %}
    </div>
{% endblock %}
", "wheelform/_index.twig", "/app/vendor/xpertbot/craft-wheelform/src/templates/_index.twig");
    }
}

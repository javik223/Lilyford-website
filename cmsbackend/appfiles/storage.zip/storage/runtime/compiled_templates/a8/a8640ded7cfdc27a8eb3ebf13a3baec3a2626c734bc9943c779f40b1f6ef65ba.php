<?php

/* media */
class __TwigTemplate_aac2dbe089990307efbdbff20071d01ab08a37842a2dc2d11aec30888c7f275f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "media", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "media", 2);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"grid-container\">
        <div class=\"page-header\">
            <h2 class=\"heading color-blue\">Media</h2>
            <h4 class=\"subheader\"></h4>
        </div>
    </div>

    ";
        // line 11
        $context["impacts"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 11, $this->source); })()), "entries", array()), "section", array(0 => "media"), "method");
        // line 12
        echo "
    <div class=\"grid-container\">

        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["impacts"]) || array_key_exists("impacts", $context) ? $context["impacts"] : (function () { throw new Twig_Error_Runtime('Variable "impacts" does not exist.', 15, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["impact"]) {
            // line 16
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "url", array()), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "title", array()), "html", null, true);
            echo "\">
                <div class=\"featured bg-light-gray margin-bottom-2\" style=\"width: 100%; display: inline-block;\">
                    <div class=\"featured__image\">

                        ";
            // line 20
            $context["heroImage"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "heroImage", array()), "one", array(), "method");
            // line 21
            echo "                        <div>
                            ";
            // line 22
            echo $context["imageHelper"]->macro_srcset(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["heroImage"]) || array_key_exists("heroImage", $context) ? $context["heroImage"] : (function () { throw new Twig_Error_Runtime('Variable "heroImage" does not exist.', 22, $this->source); })()), "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["heroImage"]) || array_key_exists("heroImage", $context) ? $context["heroImage"] : (function () { throw new Twig_Error_Runtime('Variable "heroImage" does not exist.', 22, $this->source); })()), "title", array()));
            echo "
                        </div>
                    </div>
                    <div class=\"featured__content\">
                        <h4 class=\"strong color-crimson\">";
            // line 26
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "title", array()), "html", null, true);
            echo "</h4>
                        <h5>";
            // line 27
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "subHeader", array()), "html", null, true);
            echo "</h5>
                    </div>
                </div>
            </a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['impact'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "media";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 32,  84 => 27,  80 => 26,  73 => 22,  70 => 21,  68 => 20,  58 => 16,  54 => 15,  49 => 12,  47 => 11,  38 => 4,  35 => 3,  31 => 1,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% import 'macros/image-helper' as imageHelper %}
{% block main %}
    <div class=\"grid-container\">
        <div class=\"page-header\">
            <h2 class=\"heading color-blue\">Media</h2>
            <h4 class=\"subheader\"></h4>
        </div>
    </div>

    {% set impacts = craft.entries.section('media') %}

    <div class=\"grid-container\">

        {% for impact in impacts %}
            <a href=\"{{ impact.url }}\" title=\"{{ impact.title }}\">
                <div class=\"featured bg-light-gray margin-bottom-2\" style=\"width: 100%; display: inline-block;\">
                    <div class=\"featured__image\">

                        {% set heroImage = impact.heroImage.one() %}
                        <div>
                            {{ imageHelper.srcset(heroImage.url, heroImage.title) }}
                        </div>
                    </div>
                    <div class=\"featured__content\">
                        <h4 class=\"strong color-crimson\">{{ impact.title }}</h4>
                        <h5>{{ impact.subHeader }}</h5>
                    </div>
                </div>
            </a>
        {% endfor %}
    </div>
{% endblock %}", "media", "/app/templates/media/index.twig");
    }
}

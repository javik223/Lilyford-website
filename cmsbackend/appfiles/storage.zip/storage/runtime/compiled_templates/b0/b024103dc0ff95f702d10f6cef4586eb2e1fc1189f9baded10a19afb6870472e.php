<?php

/* super-table/fields */
class __TwigTemplate_e4b901160e8e301a1208ab0f594454d265d4fe7a4bae22572be17b678783db80 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        try {
            $this->loadTemplate((("super-table/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 1, $this->source); })()), "fieldLayout", array())) . "/fields"), "super-table/fields", 1)->display($context);
        } catch (Twig_Error_Loader $e) {
            // ignore missing template
        }

    }

    public function getTemplateName()
    {
        return "super-table/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include 'super-table/' ~ settings.fieldLayout ~ '/fields' ignore missing %}
", "super-table/fields", "/app/vendor/verbb/super-table/src/templates/fields.html");
    }
}

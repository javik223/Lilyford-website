<?php

/* __string_template__305a76e91f754587abd03983138712e9a14b6082f4ac2b31f561b487b62bb8d0 */
class __TwigTemplate_aae861d48a3196aa8f75a3b1fc8a154ed91c2577b900c636ee5679c1fccc87cb extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "entries/takeAction/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "id", array())));
        echo "-";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", array())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["object"] ?? null), "slug", array())));
    }

    public function getTemplateName()
    {
        return "__string_template__305a76e91f754587abd03983138712e9a14b6082f4ac2b31f561b487b62bb8d0";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("entries/takeAction/{{ (_variables.id ?? object.id)|raw }}-{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__305a76e91f754587abd03983138712e9a14b6082f4ac2b31f561b487b62bb8d0", "");
    }
}

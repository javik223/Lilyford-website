<?php

/* macros/page-builder */
class __TwigTemplate_5776a90fa315c2ee04554e293119322b24d8ff6a15c07949acedfbae3fe9b561 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 4
        echo "
";
        // line 42
        echo "
";
    }

    // line 1
    public function macro_text($__item__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "item" => $__item__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "    <div class=\"grid-x margin-bottom-2 small-11 small-centered medium-10 large-8\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 2, $this->source); })()), "text", array()), "html", null, true);
            echo "</div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 5
    public function macro_carousel($__items__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "items" => $__items__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 6
            echo "    ";
            $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "macros/page-builder", 6);
            // line 7
            echo "    <div class=\"grid-x padding-bottom-2\">
        <div class=\"gallery\">
            ";
            // line 9
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 9, $this->source); })()), "title", array())) {
                // line 10
                echo "                <h3 class=\"gallery__title\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 10, $this->source); })()), "title", array()), "html", null, true);
                echo "</h3>
            ";
            }
            // line 12
            echo "
            <div class=\"gallery__main js-gallery-main\">
                ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 14, $this->source); })()), "images", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["carouselImage"]) {
                // line 15
                echo "                    <div>

                        ";
                // line 17
                echo $context["imageHelper"]->macro_srcset($context["carouselImage"], craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "title", array()));
                echo "
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['carouselImage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 20
            echo "            </div>
            <div class=\"gallery__thumbs js-gallery-thumb\">
                ";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new Twig_Error_Runtime('Variable "items" does not exist.', 22, $this->source); })()), "images", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["carouselImage"]) {
                // line 23
                echo "                    <div>
                        ";
                // line 24
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["carouselImage"], "title", array()), 300, 200);
                echo "
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['carouselImage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo "            </div>

            <div class=\"gallery__navigation medium-6 medium-centered text-center\">
                <span class=\"prev\">
                    <div class=\"icon icon-arrow-left\"></div>
                </span>
                <span>&nbsp;</span>
                <span class=\"next\">
                    <div class=\"icon icon-arrow-right\"></div>
                </span>
            </div>
        </div>

    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 43
    public function macro_stripCarousel($__images__ = null, $__index__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "images" => $__images__,
            "index" => $__index__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 44
            echo "  ";
            $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "macros/page-builder", 44);
            // line 45
            echo "  <div class=\"grid-x\">
    <div class=\"js-slick cell\" data-slick='{\"slidesToShow\": 1, \"centerMode\": true, \"centerPadding\": \"60px\", \"prevArrow\": \".strip-carousel-";
            // line 46
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 46, $this->source); })()), "html", null, true);
            echo "-prev\", \"nextArrow\": \".strip-carousel-";
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 46, $this->source); })()), "html", null, true);
            echo "-next\", \"responsive\": [
      {
        \"breakpoint\": 480,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 2,
          \"centerPadding\": \"10px\"
        }
      },
      {
        \"breakpoint\": 800,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 1,
          \"centerPadding\": \"20px\"
        }
      },
    ]}'>
        ";
            // line 66
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["images"]) || array_key_exists("images", $context) ? $context["images"] : (function () { throw new Twig_Error_Runtime('Variable "images" does not exist.', 66, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 67
                echo "            <div class=\"cell\">";
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["image"], "title", array()), 1000);
                echo "</div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 69
            echo "    </div>
    <div class=\"text-center cell strip-carousel-";
            // line 70
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 70, $this->source); })()), "html", null, true);
            echo "\">
        <span class=\"prev strip-carousel-";
            // line 71
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 71, $this->source); })()), "html", null, true);
            echo "-prev\">
            <div class=\"icon icon-arrow-left\"></div>
        </span>

        <span class=\"next strip-carousel-";
            // line 75
            echo twig_escape_filter($this->env, (isset($context["index"]) || array_key_exists("index", $context) ? $context["index"] : (function () { throw new Twig_Error_Runtime('Variable "index" does not exist.', 75, $this->source); })()), "html", null, true);
            echo "-next\">
            <div class=\"icon icon-arrow-right\"></div>
        </span>

    </div>
</div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "macros/page-builder";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 75,  210 => 71,  206 => 70,  203 => 69,  194 => 67,  190 => 66,  165 => 46,  162 => 45,  159 => 44,  146 => 43,  123 => 27,  114 => 24,  111 => 23,  107 => 22,  103 => 20,  94 => 17,  90 => 15,  86 => 14,  82 => 12,  76 => 10,  74 => 9,  70 => 7,  67 => 6,  55 => 5,  43 => 2,  31 => 1,  26 => 42,  23 => 4,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro text(item) %}
    <div class=\"grid-x margin-bottom-2 small-11 small-centered medium-10 large-8\">{{ item.text }}</div>
{% endmacro %}

{% macro carousel(items) %}
    {% import 'macros/image-helper' as imageHelper %}
    <div class=\"grid-x padding-bottom-2\">
        <div class=\"gallery\">
            {% if items.title %}
                <h3 class=\"gallery__title\">{{ items.title }}</h3>
            {% endif %}

            <div class=\"gallery__main js-gallery-main\">
                {% for carouselImage in items.images.all() %}
                    <div>

                        {{ imageHelper.srcset(carouselImage, carouselImage.title) }}
                    </div>
                {% endfor %}
            </div>
            <div class=\"gallery__thumbs js-gallery-thumb\">
                {% for carouselImage in items.images.all() %}
                    <div>
                        {{ imageHelper.transform(carouselImage.url, carouselImage.title, 300, 200) }}
                    </div>
                {% endfor %}
            </div>

            <div class=\"gallery__navigation medium-6 medium-centered text-center\">
                <span class=\"prev\">
                    <div class=\"icon icon-arrow-left\"></div>
                </span>
                <span>&nbsp;</span>
                <span class=\"next\">
                    <div class=\"icon icon-arrow-right\"></div>
                </span>
            </div>
        </div>

    </div>
{% endmacro %}

{% macro stripCarousel(images, index) %}
  {% import 'macros/image-helper' as imageHelper %}
  <div class=\"grid-x\">
    <div class=\"js-slick cell\" data-slick='{\"slidesToShow\": 1, \"centerMode\": true, \"centerPadding\": \"60px\", \"prevArrow\": \".strip-carousel-{{ index }}-prev\", \"nextArrow\": \".strip-carousel-{{ index }}-next\", \"responsive\": [
      {
        \"breakpoint\": 480,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 2,
          \"centerPadding\": \"10px\"
        }
      },
      {
        \"breakpoint\": 800,
        \"settings\": {
          \"arrows\": false,
          \"centerMode\": true,
          \"slidesToShow\": 1,
          \"centerPadding\": \"20px\"
        }
      },
    ]}'>
        {% for image in images %}
            <div class=\"cell\">{{ imageHelper.transform(image.url, image.title, 1000) }}</div>
        {% endfor %}
    </div>
    <div class=\"text-center cell strip-carousel-{{ index }}\">
        <span class=\"prev strip-carousel-{{ index }}-prev\">
            <div class=\"icon icon-arrow-left\"></div>
        </span>

        <span class=\"next strip-carousel-{{ index }}-next\">
            <div class=\"icon icon-arrow-right\"></div>
        </span>

    </div>
</div>
{% endmacro %}", "macros/page-builder", "/app/templates/macros/page-builder.twig");
    }
}

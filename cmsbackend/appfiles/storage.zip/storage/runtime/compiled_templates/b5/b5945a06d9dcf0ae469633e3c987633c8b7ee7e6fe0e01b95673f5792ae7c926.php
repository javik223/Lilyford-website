<?php

/* media/_entry */
class __TwigTemplate_1ab2b26d7ebf29a50791b828855b227ccbf04d3147decc9d7b8108b6d8e956fb extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "media/_entry", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["build"] = $this->loadTemplate("macros/with-page-builder", "media/_entry", 2);
        // line 3
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "media/_entry", 3);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_main($context, array $blocks = array())
    {
        // line 5
        echo "
    <div class=\"grid-container margin-bottom-3 margin-top-1\">
        <div class=\"grid-x padding-2 bg-light-gray\">
            <div class=\"cell medium-10 large-6 medium-centered text-center\">
                <h6 class=\"subheader\">
                    <a class=\"subheader\" href=\"/media/";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 10, $this->source); })()), "type", array()), "html", null, true);
        echo "\" title=\"Programmes\">";
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 10, $this->source); })()), "type", array())), "html", null, true);
        echo "</a>
                </h6>
                <h2 class=\"color-blue strong\">";
        // line 12
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 12, $this->source); })()), "title", array()), "html", null, true);
        echo "</h2>
                <h4 class=\"subheader\">";
        // line 13
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 13, $this->source); })()), "subHeader", array()), "html", null, true);
        echo "</h4>
            </div>
        </div>

        <div>
            ";
        // line 18
        if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 18, $this->source); })()), "heroImage", array()))) {
            // line 19
            echo "                ";
            $context["heroImage"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 19, $this->source); })()), "heroImage", array()), "one", array(), "method");
            // line 20
            echo "                ";
            echo $context["imageHelper"]->macro_srcset(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["heroImage"]) || array_key_exists("heroImage", $context) ? $context["heroImage"] : (function () { throw new Twig_Error_Runtime('Variable "heroImage" does not exist.', 20, $this->source); })()), "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["heroImage"]) || array_key_exists("heroImage", $context) ? $context["heroImage"] : (function () { throw new Twig_Error_Runtime('Variable "heroImage" does not exist.', 20, $this->source); })()), "title", array()));
            echo "
            ";
        }
        // line 22
        echo "
        </div>
    </div>

    <div class=\"grid-container\">
        ";
        // line 27
        echo $context["build"]->macro_withPageBuilder(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 27, $this->source); })()), "pageBuilder", array()));
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "media/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 27,  77 => 22,  71 => 20,  68 => 19,  66 => 18,  58 => 13,  54 => 12,  47 => 10,  40 => 5,  37 => 4,  33 => 1,  31 => 3,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% import 'macros/with-page-builder' as build %}
{% import 'macros/image-helper' as imageHelper %}
{% block main %}

    <div class=\"grid-container margin-bottom-3 margin-top-1\">
        <div class=\"grid-x padding-2 bg-light-gray\">
            <div class=\"cell medium-10 large-6 medium-centered text-center\">
                <h6 class=\"subheader\">
                    <a class=\"subheader\" href=\"/media/{{ entry.type }}\" title=\"Programmes\">{{ entry.type|upper }}</a>
                </h6>
                <h2 class=\"color-blue strong\">{{ entry.title }}</h2>
                <h4 class=\"subheader\">{{ entry.subHeader }}</h4>
            </div>
        </div>

        <div>
            {% if entry.heroImage | length %}
                {% set heroImage = entry.heroImage.one() %}
                {{ imageHelper.srcset(heroImage.url, heroImage.title) }}
            {% endif %}

        </div>
    </div>

    <div class=\"grid-container\">
        {{ build.withPageBuilder(entry.pageBuilder) }}
    </div>
{% endblock %}", "media/_entry", "/app/templates/media/_entry.twig");
    }
}

<?php

/* ./partials/_seo.twig */
class __TwigTemplate_06a89e67a9ed61c144157ed613bc40268ab8ea17db3e5c9665eb7044d23ad88b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "./partials/_seo.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "./partials/_seo.twig", "/app/templates/partials/_seo.twig");
    }
}

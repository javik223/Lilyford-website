<?php

/* embeddedassets/_preview */
class __TwigTemplate_c34e4700ded60b8997618a4808e23601118eaa3dce68904b22012f58db5d89d6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html>
<head>
\t<meta charset=\"utf-8\">
\t<title>";
        // line 5
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 5, $this->source); })()), "title", array()), "html", null, true);
        echo "</title>
\t";
        // line 6
        $context["previewJs"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 6, $this->source); })()), "getAssetManager", array(), "method"), "getPublishedUrl", array(0 => "@benf/embeddedassets/resources/preview.js", 1 => true), "method");
        // line 7
        echo "\t<script src=\"";
        echo twig_escape_filter($this->env, (isset($context["previewJs"]) || array_key_exists("previewJs", $context) ? $context["previewJs"] : (function () { throw new Twig_Error_Runtime('Variable "previewJs" does not exist.', 7, $this->source); })()), "html", null, true);
        echo "\"></script>
\t";
        // line 8
        if (((isset($context["callback"]) || array_key_exists("callback", $context)) && (isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new Twig_Error_Runtime('Variable "callback" does not exist.', 8, $this->source); })()))) {
            // line 9
            echo "\t\t<script>EmbeddedAssetsPreview.addCallback('";
            echo twig_escape_filter($this->env, twig_escape_filter($this->env, (isset($context["callback"]) || array_key_exists("callback", $context) ? $context["callback"] : (function () { throw new Twig_Error_Runtime('Variable "callback" does not exist.', 9, $this->source); })()), "js"), "html", null, true);
            echo "')</script>
\t";
        }
        // line 11
        echo "</head>
<body class=\"embedded-assets_preview\">
\t";
        // line 13
        $context["showCode"] = (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 13, $this->source); })()), "code", array()) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 13, $this->source); })()), "isSafe", array(), "method"));
        // line 14
        echo "\t";
        if ((isset($context["showCode"]) || array_key_exists("showCode", $context) ? $context["showCode"] : (function () { throw new Twig_Error_Runtime('Variable "showCode" does not exist.', 14, $this->source); })())) {
            // line 15
            echo "
\t\t<div id=\"code\" class=\"embedded-assets_preview_code\">
\t\t\t";
            // line 17
            echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 17, $this->source); })()), "code", array());
            echo "
\t\t</div>

\t";
        } elseif (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 20
(isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 20, $this->source); })()), "type", array()) != "link") && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 20, $this->source); })()), "image", array()))) {
            // line 21
            echo "
\t\t<div class=\"embedded-assets_preview_image\">
\t\t\t<img src=\"";
            // line 23
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 23, $this->source); })()), "image", array()), "html", null, true);
            echo "\" width=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 23, $this->source); })()), "imageWidth", array()), "html", null, true);
            echo "\" height=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 23, $this->source); })()), "imageHeight", array()), "html", null, true);
            echo "\">
\t\t</div>

\t";
        }
        // line 27
        echo "
\t<div class=\"embedded-assets_preview_content\">
\t\t<h1>";
        // line 29
        echo twig_escape_filter($this->env, ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["embeddedAsset"] ?? null), "title", array(), "any", true, true)) ? (_twig_default_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["embeddedAsset"] ?? null), "title", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 29, $this->source); })()), "url", array()))) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 29, $this->source); })()), "url", array()))), "html", null, true);
        echo "</h1>
\t\t";
        // line 30
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 30, $this->source); })()), "description", array())) {
            // line 31
            echo "\t\t\t<p>";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 31, $this->source); })()), "description", array()), "html", null, true);
            echo "</p>
\t\t";
        }
        // line 33
        echo "\t\t<ul>
\t\t\t";
        // line 34
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 34, $this->source); })()), "providerName", array())) {
            // line 35
            echo "\t\t\t\t<li>
\t\t\t\t\t";
            // line 36
            $context["providerIcon"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 36, $this->source); })()), "getProviderIconToSize", array(0 => 32), "method");
            // line 37
            echo "\t\t\t\t\t";
            if ((isset($context["providerIcon"]) || array_key_exists("providerIcon", $context) ? $context["providerIcon"] : (function () { throw new Twig_Error_Runtime('Variable "providerIcon" does not exist.', 37, $this->source); })())) {
                // line 38
                echo "\t\t\t\t\t\t<img src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["providerIcon"]) || array_key_exists("providerIcon", $context) ? $context["providerIcon"] : (function () { throw new Twig_Error_Runtime('Variable "providerIcon" does not exist.', 38, $this->source); })()), "url", array()), "html", null, true);
                echo "\" width=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["providerIcon"]) || array_key_exists("providerIcon", $context) ? $context["providerIcon"] : (function () { throw new Twig_Error_Runtime('Variable "providerIcon" does not exist.', 38, $this->source); })()), "width", array()), "html", null, true);
                echo "\" height=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["providerIcon"]) || array_key_exists("providerIcon", $context) ? $context["providerIcon"] : (function () { throw new Twig_Error_Runtime('Variable "providerIcon" does not exist.', 38, $this->source); })()), "height", array()), "html", null, true);
                echo "\">
\t\t\t\t\t";
            }
            // line 40
            echo "\t\t\t\t\t";
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 40, $this->source); })()), "providerUrl", array())) {
                // line 41
                echo "\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 41, $this->source); })()), "providerUrl", array()), "html", null, true);
                echo "\" target=\"_blank\" rel=\"noopener\">
\t\t\t\t\t\t\t";
                // line 42
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 42, $this->source); })()), "providerName", array()), "html", null, true);
                echo "
\t\t\t\t\t\t</a>
\t\t\t\t\t";
            } else {
                // line 45
                echo "\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 45, $this->source); })()), "providerName", array()), "html", null, true);
                echo "
\t\t\t\t\t";
            }
            // line 47
            echo "\t\t\t\t</li>
\t\t\t";
        }
        // line 49
        echo "\t\t\t";
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 49, $this->source); })()), "type", array())) {
            // line 50
            echo "\t\t\t\t<li>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->ucfirstFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["embeddedAsset"]) || array_key_exists("embeddedAsset", $context) ? $context["embeddedAsset"] : (function () { throw new Twig_Error_Runtime('Variable "embeddedAsset" does not exist.', 50, $this->source); })()), "type", array())), "html", null, true);
            echo "</li>
\t\t\t";
        }
        // line 52
        echo "\t\t</ul>
\t</div>

\t";
        // line 55
        if ((isset($context["showCode"]) || array_key_exists("showCode", $context) ? $context["showCode"] : (function () { throw new Twig_Error_Runtime('Variable "showCode" does not exist.', 55, $this->source); })())) {
            // line 56
            echo "\t\t<script>EmbeddedAssetsPreview.applyRatio(document.getElementById('code'))</script>
\t";
        }
        // line 58
        echo "</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "embeddedassets/_preview";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 58,  163 => 56,  161 => 55,  156 => 52,  150 => 50,  147 => 49,  143 => 47,  137 => 45,  131 => 42,  126 => 41,  123 => 40,  113 => 38,  110 => 37,  108 => 36,  105 => 35,  103 => 34,  100 => 33,  94 => 31,  92 => 30,  88 => 29,  84 => 27,  73 => 23,  69 => 21,  67 => 20,  61 => 17,  57 => 15,  54 => 14,  52 => 13,  48 => 11,  42 => 9,  40 => 8,  35 => 7,  33 => 6,  29 => 5,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!doctype html>
<html>
<head>
\t<meta charset=\"utf-8\">
\t<title>{{ embeddedAsset.title }}</title>
\t{% set previewJs = view.getAssetManager().getPublishedUrl('@benf/embeddedassets/resources/preview.js', true) %}
\t<script src=\"{{ previewJs }}\"></script>
\t{% if callback is defined and callback %}
\t\t<script>EmbeddedAssetsPreview.addCallback('{{ callback|e('js') }}')</script>
\t{% endif %}
</head>
<body class=\"embedded-assets_preview\">
\t{% set showCode = embeddedAsset.code and embeddedAsset.isSafe() %}
\t{% if showCode %}

\t\t<div id=\"code\" class=\"embedded-assets_preview_code\">
\t\t\t{{ embeddedAsset.code|raw }}
\t\t</div>

\t{% elseif embeddedAsset.type != 'link' and embeddedAsset.image %}

\t\t<div class=\"embedded-assets_preview_image\">
\t\t\t<img src=\"{{ embeddedAsset.image }}\" width=\"{{ embeddedAsset.imageWidth }}\" height=\"{{ embeddedAsset.imageHeight }}\">
\t\t</div>

\t{% endif %}

\t<div class=\"embedded-assets_preview_content\">
\t\t<h1>{{ embeddedAsset.title|default(embeddedAsset.url) }}</h1>
\t\t{% if embeddedAsset.description %}
\t\t\t<p>{{ embeddedAsset.description }}</p>
\t\t{% endif %}
\t\t<ul>
\t\t\t{% if embeddedAsset.providerName %}
\t\t\t\t<li>
\t\t\t\t\t{% set providerIcon = embeddedAsset.getProviderIconToSize(32) %}
\t\t\t\t\t{% if providerIcon %}
\t\t\t\t\t\t<img src=\"{{ providerIcon.url }}\" width=\"{{ providerIcon.width }}\" height=\"{{ providerIcon.height }}\">
\t\t\t\t\t{% endif %}
\t\t\t\t\t{% if embeddedAsset.providerUrl %}
\t\t\t\t\t\t<a href=\"{{ embeddedAsset.providerUrl }}\" target=\"_blank\" rel=\"noopener\">
\t\t\t\t\t\t\t{{ embeddedAsset.providerName }}
\t\t\t\t\t\t</a>
\t\t\t\t\t{% else %}
\t\t\t\t\t\t{{ embeddedAsset.providerName }}
\t\t\t\t\t{% endif %}
\t\t\t\t</li>
\t\t\t{% endif %}
\t\t\t{% if embeddedAsset.type %}
\t\t\t\t<li>{{ embeddedAsset.type|ucfirst }}</li>
\t\t\t{% endif %}
\t\t</ul>
\t</div>

\t{% if showCode %}
\t\t<script>EmbeddedAssetsPreview.applyRatio(document.getElementById('code'))</script>
\t{% endif %}
</body>
</html>
", "embeddedassets/_preview", "/app/vendor/benjamminf/craft-embedded-assets/src/templates/_preview.twig");
    }
}

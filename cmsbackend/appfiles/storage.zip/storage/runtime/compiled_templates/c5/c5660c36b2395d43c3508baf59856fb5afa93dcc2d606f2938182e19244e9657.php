<?php

/* our-programmes/_entry */
class __TwigTemplate_b5d0b784a4b9a81f01eb63d48ac8d993b4d9d0f92a6243f66928ce66ae831433 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "our-programmes/_entry", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_main($context, array $blocks = array())
    {
        // line 3
        echo "    ";
        // line 4
        echo "
    <div class=\"grid-container\">
        <div class=\"page-nav\">
            <div class=\"page-nav__title\">Our Programmes</div>
            <div class=\"page-nav__links__container\">
                <ul class=\"page-nav__links\">
                    ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 10, $this->source); })()), "entries", array()), "section", array(0 => "ourProgrammes"), "method"), "limit", array(0 => 10), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["programme"]) {
            // line 15
            echo "                        <li>
                            <a href=\"";
            // line 16
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "url", array()), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "title", array()), "html", null, true);
            echo "\">
                                <span ";
            // line 17
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "url", array()) == craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 17, $this->source); })()), "url", array()))) {
                echo " class=\"color-crimson\" ";
            }
            echo ">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["programme"], "title", array()), "html", null, true);
            echo "</span></a>
                        </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['programme'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "                </ul>
            </div>
        </div>
    </div>
    ";
        // line 25
        echo "
    ";
        // line 27
        echo "    <div class=\"grid-container\">
        <div class=\"grid-x padding-2 bg-light-gray\">
            <div class=\"cell medium-10 large-6 medium-centered text-center\">
                <h6 class=\"subheader\">
                    <a class=\"subheader\" href=\"/programmes\" title=\"Programmes\">PROGRAMMES</a>
                </h6>
                <h2 class=\"heading color-blue\">";
        // line 33
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 33, $this->source); })()), "title", array()), "html", null, true);
        echo "</h2>
                <div class=\"cell\"><img class=\"padding-1\" src=\"";
        // line 34
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 34, $this->source); })()), "icon", array()), "one", array(), "method"), "url", array()), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 34, $this->source); })()), "title", array()), "html", null, true);
        echo "\"></div>
                <h4>";
        // line 35
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 35, $this->source); })()), "subHeader", array()), "html", null, true);
        echo "</h4>
            </div>
        </div>
        <div class=\"grid-x position-relative margin-top-3\">
            <div class=\"cell medium-7\">
                <h3 class=\"color-purple padding-top-1 strong\">THE CHALLENGE</h3>
                ";
        // line 41
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 41, $this->source); })()), "theChallenge", array()), "html", null, true);
        echo "
            </div>
            <div class=\"cell medium-4 large-3 medium-detach-to-right-position-absolute bg-white padding-3 box-shadow\">
                <div class=\"h4 color-crimson strong uppercase\">Quick Facts
                    <hr>
                </div>

                ";
        // line 48
        $context["quickFacts"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 48, $this->source); })()), "quickFacts", array()), "all", array(), "method");
        // line 49
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["quickFacts"]) || array_key_exists("quickFacts", $context) ? $context["quickFacts"] : (function () { throw new Twig_Error_Runtime('Variable "quickFacts" does not exist.', 49, $this->source); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["quickFact"]) {
            // line 50
            echo "                    <h3 class=\"strong uppercase color-purple\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["quickFact"], "quickFactsStatistics", array()), "html", null, true);
            echo "</h3>
                    <p>";
            // line 51
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["quickFact"], "quickFactsSummary", array()), "html", null, true);
            echo "</p>
                    ";
            // line 52
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index", array()) != twig_length_filter($this->env, (isset($context["quickFacts"]) || array_key_exists("quickFacts", $context) ? $context["quickFacts"] : (function () { throw new Twig_Error_Runtime('Variable "quickFacts" does not exist.', 52, $this->source); })())))) {
                // line 53
                echo "                        <hr>
                    ";
            }
            // line 55
            echo "
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quickFact'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "
            </div>

            <div class=\"cell medium-8 margin-top-2 margin-bottom-3\">
                <h3 class=\"color-purple padding-top-1 strong\">WHAT WE ARE DOING</h3>
                ";
        // line 62
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 62, $this->source); })()), "whatWeAreDoing", array()), "html", null, true);
        echo "
            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "our-programmes/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 62,  167 => 57,  152 => 55,  148 => 53,  146 => 52,  142 => 51,  137 => 50,  119 => 49,  117 => 48,  107 => 41,  98 => 35,  92 => 34,  88 => 33,  80 => 27,  77 => 25,  71 => 20,  58 => 17,  52 => 16,  49 => 15,  45 => 10,  37 => 4,  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% block main %}
    {# Page navigation #}

    <div class=\"grid-container\">
        <div class=\"page-nav\">
            <div class=\"page-nav__title\">Our Programmes</div>
            <div class=\"page-nav__links__container\">
                <ul class=\"page-nav__links\">
                    {% for programme in craft
                        .entries
                        .section('ourProgrammes')
                        .limit(10)
 %}
                        <li>
                            <a href=\"{{ programme.url }}\" title=\"{{ programme.title }}\">
                                <span {% if programme.url == entry.url %} class=\"color-crimson\" {% endif %}>{{ programme.title }}</span></a>
                        </li>
                    {% endfor %}
                </ul>
            </div>
        </div>
    </div>
    {# /Page Navigation #}

    {# Header #}
    <div class=\"grid-container\">
        <div class=\"grid-x padding-2 bg-light-gray\">
            <div class=\"cell medium-10 large-6 medium-centered text-center\">
                <h6 class=\"subheader\">
                    <a class=\"subheader\" href=\"/programmes\" title=\"Programmes\">PROGRAMMES</a>
                </h6>
                <h2 class=\"heading color-blue\">{{ entry.title }}</h2>
                <div class=\"cell\"><img class=\"padding-1\" src=\"{{ entry.icon.one().url }}\" alt=\"{{ entry.title }}\"></div>
                <h4>{{ entry.subHeader }}</h4>
            </div>
        </div>
        <div class=\"grid-x position-relative margin-top-3\">
            <div class=\"cell medium-7\">
                <h3 class=\"color-purple padding-top-1 strong\">THE CHALLENGE</h3>
                {{ entry.theChallenge }}
            </div>
            <div class=\"cell medium-4 large-3 medium-detach-to-right-position-absolute bg-white padding-3 box-shadow\">
                <div class=\"h4 color-crimson strong uppercase\">Quick Facts
                    <hr>
                </div>

                {% set quickFacts = entry.quickFacts.all() %}
                {% for quickFact in quickFacts %}
                    <h3 class=\"strong uppercase color-purple\">{{ quickFact.quickFactsStatistics }}</h3>
                    <p>{{ quickFact.quickFactsSummary }}</p>
                    {% if loop.index != quickFacts | length %}
                        <hr>
                    {% endif %}

                {% endfor %}

            </div>

            <div class=\"cell medium-8 margin-top-2 margin-bottom-3\">
                <h3 class=\"color-purple padding-top-1 strong\">WHAT WE ARE DOING</h3>
                {{ entry.whatWeAreDoing }}
            </div>
        </div>
    </div>

{% endblock %}", "our-programmes/_entry", "/app/templates/our-programmes/_entry.twig");
    }
}

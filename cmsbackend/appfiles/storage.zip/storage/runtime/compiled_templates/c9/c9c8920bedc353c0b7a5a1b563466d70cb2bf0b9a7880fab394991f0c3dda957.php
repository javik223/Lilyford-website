<?php

/* media/impacts */
class __TwigTemplate_54f85ca2290cb83ef11fcbce5c8b4e34f2990aaaf385f0d71b7f339f154de308 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "media/impacts", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "media/impacts", 2);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"grid-container\">
        <div class=\"page-header\">
            <h2 class=\"heading color-blue\">Impact</h2>
            <h4 class=\"subheader\">
                Summary of Lilyford's programmes &amp; events
            </h4>
        </div>
    </div>

    ";
        // line 13
        $context["impacts"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 13, $this->source); })()), "entries", array()), "section", array(0 => "media"), "method"), "type", array(0 => "impact"), "method");
        // line 14
        echo "
    <div class=\"grid-container\">

        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["impacts"]) || array_key_exists("impacts", $context) ? $context["impacts"] : (function () { throw new Twig_Error_Runtime('Variable "impacts" does not exist.', 17, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["impact"]) {
            // line 18
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "url", array()), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "title", array()), "html", null, true);
            echo "\">
                <div class=\"featured bg-light-gray\" style=\"width: 100%; display: inline-block;\">
                    <div class=\"featured__image\">

                        ";
            // line 22
            $context["heroImage"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "heroImage", array()), "one", array(), "method");
            // line 23
            echo "                        <div>
                            ";
            // line 24
            echo $context["imageHelper"]->macro_srcset(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["heroImage"]) || array_key_exists("heroImage", $context) ? $context["heroImage"] : (function () { throw new Twig_Error_Runtime('Variable "heroImage" does not exist.', 24, $this->source); })()), "url", array()), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["heroImage"]) || array_key_exists("heroImage", $context) ? $context["heroImage"] : (function () { throw new Twig_Error_Runtime('Variable "heroImage" does not exist.', 24, $this->source); })()), "title", array()));
            echo "
                        </div>
                    </div>
                    <div class=\"featured__content\">
                        <h4 class=\"strong color-crimson\">";
            // line 28
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "title", array()), "html", null, true);
            echo "</h4>
                        <h5>";
            // line 29
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["impact"], "subHeader", array()), "html", null, true);
            echo "</h5>
                    </div>
                </div>
            </a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['impact'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "media/impacts";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 34,  86 => 29,  82 => 28,  75 => 24,  72 => 23,  70 => 22,  60 => 18,  56 => 17,  51 => 14,  49 => 13,  38 => 4,  35 => 3,  31 => 1,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% import 'macros/image-helper' as imageHelper %}
{% block main %}
    <div class=\"grid-container\">
        <div class=\"page-header\">
            <h2 class=\"heading color-blue\">Impact</h2>
            <h4 class=\"subheader\">
                Summary of Lilyford's programmes &amp; events
            </h4>
        </div>
    </div>

    {% set impacts = craft.entries.section('media').type('impact') %}

    <div class=\"grid-container\">

        {% for impact in impacts %}
            <a href=\"{{ impact.url }}\" title=\"{{ impact.title }}\">
                <div class=\"featured bg-light-gray\" style=\"width: 100%; display: inline-block;\">
                    <div class=\"featured__image\">

                        {% set heroImage = impact.heroImage.one() %}
                        <div>
                            {{ imageHelper.srcset(heroImage.url, heroImage.title) }}
                        </div>
                    </div>
                    <div class=\"featured__content\">
                        <h4 class=\"strong color-crimson\">{{ impact.title }}</h4>
                        <h5>{{ impact.subHeader }}</h5>
                    </div>
                </div>
            </a>
        {% endfor %}
    </div>
{% endblock %}", "media/impacts", "/app/templates/media/impacts.twig");
    }
}

<?php

/* super-table/table/fields */
class __TwigTemplate_833c4094e70cc27ada4bcd6d88bd4a58cf3cd436b173964d38d1627b048036c5 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ( !(isset($context["element"]) || array_key_exists("element", $context))) {
            $context["element"] = null;
        }
        // line 2
        if ( !(isset($context["namespace"]) || array_key_exists("namespace", $context))) {
            $context["namespace"] = "fields";
        }
        // line 3
        echo "
";
        // line 4
        $_namespace = (isset($context["namespace"]) || array_key_exists("namespace", $context) ? $context["namespace"] : (function () { throw new Twig_Error_Runtime('Variable "namespace" does not exist.', 4, $this->source); })());
        if ($_namespace) {
            $_originalNamespace = Craft::$app->getView()->getNamespace();
            Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
            ob_start();
            try {
                // line 5
                echo "    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 5, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                    // line 6
                    echo "        <td>
            ";
                    // line 7
                    $this->loadTemplate("super-table/field", "super-table/table/fields", 7)->display(array("field" =>                     // line 8
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 9
$context["field"], "required", array()), "element" =>                     // line 10
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new Twig_Error_Runtime('Variable "element" does not exist.', 10, $this->source); })()), "static" => ((                    // line 11
(isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 11, $this->source); })())) : (null))));
                    // line 13
                    echo "        </td>
    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
            } catch (Exception $e) {
                ob_end_clean();

                throw $e;
            }
            echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
            Craft::$app->getView()->setNamespace($_originalNamespace);
        } else {
            // line 5
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 5, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 6
                echo "        <td>
            ";
                // line 7
                $this->loadTemplate("super-table/field", "super-table/table/fields", 7)->display(array("field" =>                 // line 8
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 9
$context["field"], "required", array()), "element" =>                 // line 10
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new Twig_Error_Runtime('Variable "element" does not exist.', 10, $this->source); })()), "static" => ((                // line 11
(isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 11, $this->source); })())) : (null))));
                // line 13
                echo "        </td>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        unset($_originalNamespace, $_namespace);
    }

    public function getTemplateName()
    {
        return "super-table/table/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 13,  82 => 11,  81 => 10,  80 => 9,  79 => 8,  78 => 7,  75 => 6,  70 => 5,  55 => 13,  53 => 11,  52 => 10,  51 => 9,  50 => 8,  49 => 7,  46 => 6,  41 => 5,  34 => 4,  31 => 3,  27 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if element is not defined %}{% set element = null %}{% endif %}
{% if namespace is not defined %}{% set namespace = 'fields' %}{% endif %}

{% namespace namespace %}
    {% for field in fields %}
        <td>
            {% include \"super-table/field\" with {
                field:    field,
                required: field.required,
                element:  element,
                static:   (static is defined ? static : null)
            } only %}
        </td>
    {% endfor %}
{% endnamespace %}", "super-table/table/fields", "/app/vendor/verbb/super-table/src/templates/table/fields.html");
    }
}

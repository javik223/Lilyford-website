<?php

/* super-table/input */
class __TwigTemplate_e6a32373046c13e9f961ce45d860a78f70847bacafb3a49f75b65dbb19c4a1a6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<input type=\"hidden\" name=\"";
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 1, $this->source); })()), "html", null, true);
        echo "\" value=\"\">

";
        // line 3
        $this->loadTemplate((("super-table/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 3, $this->source); })()), "fieldLayout", array())) . "/input"), "super-table/input", 3)->display($context);
    }

    public function getTemplateName()
    {
        return "super-table/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"hidden\" name=\"{{ name }}\" value=\"\">

{% include 'super-table/' ~ supertableField.fieldLayout ~ '/input' %}
", "super-table/input", "/app/vendor/verbb/super-table/src/templates/input.html");
    }
}

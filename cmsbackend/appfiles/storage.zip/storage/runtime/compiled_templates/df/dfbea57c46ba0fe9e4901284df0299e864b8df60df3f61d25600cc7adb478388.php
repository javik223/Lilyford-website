<?php

/* about/board-of-directors/ */
class __TwigTemplate_15d78c246315b46f6c4388196f5018a7afc88e97688c0560b10d64a7f02cdbdd extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout.twig", "about/board-of-directors/", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper.twig", "about/board-of-directors/", 2);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">Board of Directors</h2>
        <h4 class=\"subheader\">";
        // line 6
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 6, $this->source); })()), "text", array()), "html", null, true);
        echo "</h4>
    </div>
    ";
        // line 8
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache1 = ($request->getIsLivePreview() || $request->getToken());
        if (!$ignoreCache1) {
            $cacheKey1 = "lwVHGC6c3YCFSMk4hA0WNn4SGEdzIHTOLRyz";
            $cacheBody1 = $cacheService->getTemplateCache($cacheKey1, false);
        } else {
            $cacheBody1 = null;
        }
        if ($cacheBody1 === null) {
            if (!$ignoreCache1) {
                $cacheService->startTemplateCache($cacheKey1);
            }
            ob_start();
            // line 9
            echo "    <div class=\"grid-container padding-bottom-3\">
        <div class=\"grid-x grid-margin-x grid-margin-y medium-up-2 large-up-3 text-center\">
            ";
            // line 11
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 11, $this->source); })()), "entries", array()), "section", array(0 => "boardOfDirectors"), "method"), "all", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                // line 15
                echo "                <div class=\"cell box-shadow padding-2\">
                    <a class=\"avatar box-shadow w80\" href=\"";
                // line 16
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "url", array()), "html", null, true);
                echo "\" title=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "title", array()), "html", null, true);
                echo "\">
                        ";
                // line 17
                echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "profileThumbnail", array()), "one", array(), "method"), ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "title", array()) . " ") . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "profileDesignation", array())), 320, 320);
                echo "
                    </a>
                    <a href=\"";
                // line 19
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "url", array()), "html", null, true);
                echo "\" title=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "title", array()), "html", null, true);
                echo "\">
                        <h3 class=\"color-purple padding-top-1\">";
                // line 20
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "title", array()), "html", null, true);
                echo "</h3>
                        <h5 class=\"color-black\">";
                // line 21
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["entry"], "profileDesignation", array()), "html", null, true);
                echo "</h5>
                    </a>
                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "        </div>
    </div>
    ";
            $cacheBody1 = ob_get_clean();
            if (!$ignoreCache1) {
                $cacheService->endTemplateCache($cacheKey1, false, null, null, $cacheBody1);
            }
        }
        echo $cacheBody1;
        // line 28
        echo "
";
    }

    public function getTemplateName()
    {
        return "about/board-of-directors/";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 28,  104 => 25,  94 => 21,  90 => 20,  84 => 19,  79 => 17,  73 => 16,  70 => 15,  66 => 11,  62 => 9,  47 => 8,  42 => 6,  38 => 4,  35 => 3,  31 => 1,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout.twig' %}
{% import 'macros/image-helper.twig' as imageHelper %}
{% block main %}
    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">Board of Directors</h2>
        <h4 class=\"subheader\">{{ entry.text }}</h4>
    </div>
    {% cache %}
    <div class=\"grid-container padding-bottom-3\">
        <div class=\"grid-x grid-margin-x grid-margin-y medium-up-2 large-up-3 text-center\">
            {% for entry in craft
                .entries
                .section('boardOfDirectors')
                .all() %}
                <div class=\"cell box-shadow padding-2\">
                    <a class=\"avatar box-shadow w80\" href=\"{{ entry.url }}\" title=\"{{ entry.title }}\">
                        {{ imageHelper.transform(entry.profileThumbnail.one(), entry.title ~ ' ' ~ entry.profileDesignation, 320, 320) }}
                    </a>
                    <a href=\"{{ entry.url }}\" title=\"{{ entry.title }}\">
                        <h3 class=\"color-purple padding-top-1\">{{ entry.title }}</h3>
                        <h5 class=\"color-black\">{{ entry.profileDesignation }}</h5>
                    </a>
                </div>
            {% endfor %}
        </div>
    </div>
    {% endcache %}

{% endblock %}", "about/board-of-directors/", "/app/templates/about/board-of-directors/index.twig");
    }
}

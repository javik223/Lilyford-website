<?php

/* take-action/ */
class __TwigTemplate_0f6422544f05c56495acc5dee37282cfdd825a80b02cea57881ac7dafc12e0e6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "take-action/", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_main($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"page-header\">
        <h2 class=\"header colore-blue\">Take Action</h2>
        <h5 class=\"subheader\">";
        // line 5
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "introText", array()), "html", null, true);
        echo "</h5>
    </div>
    }

    <div class=\"row margin-bottom-2\">
        <div class=\"hero-card hero-card-dark\">
            <div class=\"hero-card__image\"><img src=\"/assets/img/donate-img.jpg\" alt=\"\"></div>
            <div class=\"hero-card__content padding-3\">
                <h2>Volunteer</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc pretium turpis sed libero sagittis faucibus. Donec magna justo, egestas sed ligula et, pharetra maximus ex</p>
                <button class=\"button uppercase strong dark margin-top-2\">Become a partner</button>
            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "take-action/";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 5,  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% block main %}
    <div class=\"page-header\">
        <h2 class=\"header colore-blue\">Take Action</h2>
        <h5 class=\"subheader\">{{ entry.introText }}</h5>
    </div>
    }

    <div class=\"row margin-bottom-2\">
        <div class=\"hero-card hero-card-dark\">
            <div class=\"hero-card__image\"><img src=\"/assets/img/donate-img.jpg\" alt=\"\"></div>
            <div class=\"hero-card__content padding-3\">
                <h2>Volunteer</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc pretium turpis sed libero sagittis faucibus. Donec magna justo, egestas sed ligula et, pharetra maximus ex</p>
                <button class=\"button uppercase strong dark margin-top-2\">Become a partner</button>
            </div>
        </div>
    </div>

{% endblock %}", "take-action/", "/app/templates/take-action/index.twig");
    }
}

<?php

/* super-table/row/input */
class __TwigTemplate_3f020cc2452bcb1ddb6367e0aaa62d8b5fc83d6d5dd67ff6f22abdb10f13753f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 1, $this->source); })()), "html", null, true);
        echo "\" class=\"superTableContainer rowLayout\">
    <div class=\"rowLayoutContainer\">
        ";
        // line 3
        $context["totalNewBlocks"] = 0;
        // line 4
        echo "
        ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new Twig_Error_Runtime('Variable "blocks" does not exist.', 5, $this->source); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
            // line 6
            echo "            ";
            $context["blockId"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "id", array());
            // line 7
            echo "
            ";
            // line 8
            if ( !(isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 8, $this->source); })())) {
                // line 9
                echo "                ";
                $context["totalNewBlocks"] = ((isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 9, $this->source); })()) + 1);
                // line 10
                echo "                ";
                $context["blockId"] = ("new" . (isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 10, $this->source); })()));
                // line 11
                echo "            ";
            }
            // line 12
            echo "
            <div class=\"superTableRow\" data-id=\"";
            // line 13
            echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 13, $this->source); })()), "html", null, true);
            echo "\">
                <input type=\"hidden\" name=\"";
            // line 14
            echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 14, $this->source); })()), "html", null, true);
            echo "[";
            echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 14, $this->source); })()), "html", null, true);
            echo "][type]\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "getType", array(), "method"), "html", null, true);
            echo "\">

                <table class=\"superTable-table superTable-layout-row\">
                    <tbody>
                        ";
            // line 18
            $this->loadTemplate("super-table/row/fields", "super-table/row/input", 18)->display(array_merge($context, array("namespace" => (((            // line 19
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 19, $this->source); })()) . "[") . (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 19, $this->source); })())) . "][fields]"), "element" =>             // line 20
$context["block"], "fields" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 21
$context["block"], "getType", array(), "method"), "getFieldLayout", array(), "method"), "getFields", array(), "method"), "settings" =>             // line 22
(isset($context["supertableField"]) || array_key_exists("supertableField", $context) ? $context["supertableField"] : (function () { throw new Twig_Error_Runtime('Variable "supertableField" does not exist.', 22, $this->source); })()))));
            // line 24
            echo "                    </tbody>

                    ";
            // line 26
            if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 26, $this->source); })())) {
                // line 27
                echo "                        <tfoot>
                            <tr>
                                <td class=\"floating reorder\"><a class=\"move icon\" title=\"";
                // line 29
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "site"), "html", null, true);
                echo "\"></a></td>
                                <td class=\"floating delete\"><a class=\"delete icon\" title=\"";
                // line 30
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "site"), "html", null, true);
                echo "\"></a></td>
                            </tr>
                        </tfoot>
                    ";
            }
            // line 34
            echo "                </table>
            </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "    </div>

    ";
        // line 39
        if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 39, $this->source); })())) {
            // line 40
            echo "        <div class=\"superTableAddRow btn add icon\">
            ";
            // line 41
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "selectionLabel", array(), "any", true, true)) ? (_twig_default_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["supertableField"] ?? null), "selectionLabel", array()), "Add a row")) : ("Add a row")), "site"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 44
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "super-table/row/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 44,  138 => 41,  135 => 40,  133 => 39,  129 => 37,  113 => 34,  106 => 30,  102 => 29,  98 => 27,  96 => 26,  92 => 24,  90 => 22,  89 => 21,  88 => 20,  87 => 19,  86 => 18,  75 => 14,  71 => 13,  68 => 12,  65 => 11,  62 => 10,  59 => 9,  57 => 8,  54 => 7,  51 => 6,  34 => 5,  31 => 4,  29 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"{{ id }}\" class=\"superTableContainer rowLayout\">
    <div class=\"rowLayoutContainer\">
        {% set totalNewBlocks = 0 %}

        {% for block in blocks %}
            {% set blockId = block.id %}

            {% if not blockId %}
                {% set totalNewBlocks = totalNewBlocks + 1 %}
                {% set blockId = 'new' ~ totalNewBlocks %}
            {% endif %}

            <div class=\"superTableRow\" data-id=\"{{ blockId }}\">
                <input type=\"hidden\" name=\"{{ name }}[{{ blockId }}][type]\" value=\"{{ block.getType() }}\">

                <table class=\"superTable-table superTable-layout-row\">
                    <tbody>
                        {% include \"super-table/row/fields\" with {
                            namespace: name ~ '[' ~ blockId ~ '][fields]',
                            element: block,
                            fields: block.getType().getFieldLayout().getFields(),
                            settings: supertableField,
                        } %}
                    </tbody>

                    {% if not staticBlocks %}
                        <tfoot>
                            <tr>
                                <td class=\"floating reorder\"><a class=\"move icon\" title=\"{{ 'Reorder' | t('site') }}\"></a></td>
                                <td class=\"floating delete\"><a class=\"delete icon\" title=\"{{ 'Delete' | t('site') }}\"></a></td>
                            </tr>
                        </tfoot>
                    {% endif %}
                </table>
            </div>
        {% endfor %}
    </div>

    {% if not staticBlocks %}
        <div class=\"superTableAddRow btn add icon\">
            {{ supertableField.selectionLabel | default(\"Add a row\") | t('site') }}
        </div>
    {% endif %}
</div>
", "super-table/row/input", "/app/vendor/verbb/super-table/src/templates/row/input.html");
    }
}

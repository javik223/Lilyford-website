<?php

/* wheelform/_emails/general.twig */
class __TwigTemplate_a7dc1b3d722e907ba7f4f13661b56e2ab698ccc3acae6c934d575631ea2b54c0 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<body>
    <ul>
    ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 4, $this->source); })()));
        foreach ($context['_seq'] as $context["name"] => $context["field"]) {
            // line 5
            echo "        <li>
            <strong>";
            // line 6
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "label", array()), "html", null, true);
            echo ":</strong><br>
            ";
            // line 7
            switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "type", array())) {
                case "file":
                {
                    // line 10
                    echo "                    ";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "value", array()), "name", array()), "html", null, true);
                    echo "

                ";
                    break;
                }
                case "checkbox":
                {
                    // line 13
                    echo "                    ";
                    echo twig_escape_filter($this->env, twig_join_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "value", array()), ","), "html", null, true);
                    echo "

                ";
                    break;
                }
                default:
                {
                    // line 16
                    echo "                ";
                    // line 17
                    echo "                ";
                    echo nl2br(twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "value", array()), "html", null, true));
                    echo "

            ";
                }
            }
            // line 20
            echo "            <br>&nbsp;
        </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['name'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </ul>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "wheelform/_emails/general.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 23,  73 => 20,  65 => 17,  63 => 16,  53 => 13,  43 => 10,  39 => 7,  35 => 6,  32 => 5,  28 => 4,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html>
<body>
    <ul>
    {% for name, field in fields %}
        <li>
            <strong>{{ field.label }}:</strong><br>
            {% switch field.type %}

                {% case \"file\" %}
                    {{ field.value.name }}

                {% case \"checkbox\" %}
                    {{ field.value | join(',')}}

                {% default %}
                {# Text based items #}
                {{ field.value|nl2br }}

            {% endswitch %}
            <br>&nbsp;
        </li>
    {% endfor %}
    </ul>
</body>
</html>
", "wheelform/_emails/general.twig", "/app/vendor/xpertbot/craft-wheelform/src/templates/_emails/general.twig");
    }
}

<?php

/* ./partials/_seo.twig */
class __TwigTemplate_47265ee4885ac7bacbf4df6417ee9562a0efab2d558bb81872c270d06fa8c238 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "./partials/_seo.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "./partials/_seo.twig", "/app/templates/partials/_seo.twig");
    }
}

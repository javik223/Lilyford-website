<?php

/* contact/ */
class __TwigTemplate_4888dd836d57b38f1da61b738aa8a9b67db6d2a4285514c9c3c4c5ab50712bf9 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout.twig", "contact/", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper.twig", "contact/", 2);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_main($context, array $blocks = array())
    {
        // line 5
        echo "    <div class=\"grid-container\">
        <div class=\"grid-x padding-1\">
            <div class=\"cell padding-bottom-2\">
                <h1 class=\"page-title\">Contact Us</h1>
                <h3 class=\"subheader\">";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 9, $this->source); })()), "subHeader", array()), "html", null, true);
        echo "</h3>
            </div>
            <div class=\"cell medium-6 padding-top-2 small-order-2 medium-order-1\">
                <div class=\"grid-y grid-margin-y\">
                    <div class=\"cell\">
                        <h4 class=\"strong color-crimson\">Volunteering &amp; Partnerships</h4>
                        ";
        // line 15
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 15, $this->source); })()), "volunteeringPartnerships", array()), "html", null, true);
        echo "
                    </div>
                    <div class=\"cell\">
                        <h4 class=\"strong color-crimson\">Correspondence</h4>
                        ";
        // line 19
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 19, $this->source); })()), "correspondence", array()), "html", null, true);
        echo "
                    </div>
                    <div class=\"cell padding-top-3 padding-bottom-3\">
                        <div class=\"flex-container align-justify large-8\">
                            ";
        // line 23
        $this->loadTemplate("partials/socialicons-2x.twig", "contact/", 23)->display($context);
        // line 24
        echo "                        </div>
                    </div>
                    <div class=\"cell\">
                        <h3 class=\"color-crimson\">Signup for updates
                            <div class=\"grid-x padding-top-1\">
                                <div class=\"cell small-8 medium-9 text-right\">
                                    <input name=\"Email Address\" type=\"text\" placeholder=\"Email Address\">
                                </div>
                                <div class=\"cell small-4 medium-3\">
                                    <input class=\"button button no-radius\" type=\"button\" value=\"SIGN UP\">
                                </div>
                            </div>
                        </h3>
                    </div>
                </div>
            </div>
            <div class=\"cell medium-6 small-order-1\">
                <div class=\"grid-y grid-margin-y circular-background\">
                    <div class=\"cell\">
                        ";
        // line 43
        echo $context["imageHelper"]->macro_transform(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 43, $this->source); })()), "heroImage", array()), "one", array(), "method"), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 43, $this->source); })()), "title", array()));
        echo "
                    </div>
                </div>
            </div>
            <div class=\"margin-bottom-3 padding-bottom-3\"></div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "contact/";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 43,  69 => 24,  67 => 23,  60 => 19,  53 => 15,  44 => 9,  38 => 5,  35 => 4,  31 => 1,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout.twig' %}
{% import 'macros/image-helper.twig' as imageHelper %}

{% block main %}
    <div class=\"grid-container\">
        <div class=\"grid-x padding-1\">
            <div class=\"cell padding-bottom-2\">
                <h1 class=\"page-title\">Contact Us</h1>
                <h3 class=\"subheader\">{{ entry.subHeader }}</h3>
            </div>
            <div class=\"cell medium-6 padding-top-2 small-order-2 medium-order-1\">
                <div class=\"grid-y grid-margin-y\">
                    <div class=\"cell\">
                        <h4 class=\"strong color-crimson\">Volunteering &amp; Partnerships</h4>
                        {{ entry.volunteeringPartnerships }}
                    </div>
                    <div class=\"cell\">
                        <h4 class=\"strong color-crimson\">Correspondence</h4>
                        {{ entry.correspondence }}
                    </div>
                    <div class=\"cell padding-top-3 padding-bottom-3\">
                        <div class=\"flex-container align-justify large-8\">
                            {% include 'partials/socialicons-2x.twig' %}
                        </div>
                    </div>
                    <div class=\"cell\">
                        <h3 class=\"color-crimson\">Signup for updates
                            <div class=\"grid-x padding-top-1\">
                                <div class=\"cell small-8 medium-9 text-right\">
                                    <input name=\"Email Address\" type=\"text\" placeholder=\"Email Address\">
                                </div>
                                <div class=\"cell small-4 medium-3\">
                                    <input class=\"button button no-radius\" type=\"button\" value=\"SIGN UP\">
                                </div>
                            </div>
                        </h3>
                    </div>
                </div>
            </div>
            <div class=\"cell medium-6 small-order-1\">
                <div class=\"grid-y grid-margin-y circular-background\">
                    <div class=\"cell\">
                        {{ imageHelper.transform(entry.heroImage.one(), entry.title) }}
                    </div>
                </div>
            </div>
            <div class=\"margin-bottom-3 padding-bottom-3\"></div>
        </div>
    </div>
{% endblock %}", "contact/", "/app/templates/contact/index.twig");
    }
}

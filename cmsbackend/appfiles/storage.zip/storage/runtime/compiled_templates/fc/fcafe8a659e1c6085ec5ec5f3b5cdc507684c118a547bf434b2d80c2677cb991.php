<?php

/* take-action/_entry */
class __TwigTemplate_b1b6fe3858b82e4c72ed437cae6e18b8149889dfef7b95e49b33dff45fccfbec extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layout", "take-action/_entry", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["imageHelper"] = $this->loadTemplate("macros/image-helper", "take-action/_entry", 2);
        // line 3
        $context["build"] = $this->loadTemplate("macros/with-page-builder", "take-action/_entry", 3);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_main($context, array $blocks = array())
    {
        // line 5
        echo "    ";
        // line 6
        echo "    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 7, $this->source); })()), "title", array()), "html", null, true);
        echo "</h2>
        <h4 class=\"subheader\">";
        // line 8
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 8, $this->source); })()), "introText", array()), "html", null, true);
        echo "</h4>
    </div>
    <div class=\"grid-container full text-center\">
        ";
        // line 11
        echo $context["build"]->macro_withPageBuilder(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new Twig_Error_Runtime('Variable "entry" does not exist.', 11, $this->source); })()), "pageBuilder", array()));
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "take-action/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 11,  49 => 8,  45 => 7,  42 => 6,  40 => 5,  37 => 4,  33 => 1,  31 => 3,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '_layout' %}
{% import 'macros/image-helper' as imageHelper %}
{% import 'macros/with-page-builder' as build %}
{% block main %}
    {#<img src=\"{{ entry.heroImage.one().url }}\" alt=\"{{ entry.heroImage.title }}\">#}
    <div class=\"page-header\">
        <h2 class=\"heading color-blue\">{{ entry.title }}</h2>
        <h4 class=\"subheader\">{{ entry.introText }}</h4>
    </div>
    <div class=\"grid-container full text-center\">
        {{ build.withPageBuilder(entry.pageBuilder) }}
    </div>
{% endblock %}", "take-action/_entry", "/app/templates/take-action/_entry.twig");
    }
}

/**
 * Navigation plugin for Craft CMS
 *
 * Index Field JS
 *
 * @author    Fatfish
 * @copyright Copyright (c) 2018 Fatfish
 * @link      https://fatfish.com.au
 * @package   Navigation
 * @since     1.0.0
 */
